package exerelin.utilities.rectanglepacker;

import java.awt.*;
import java.util.List;

class PackerBL<T extends Rectangle> extends Packer<T> {

    public PackerBL(int stripWidth, List<T> rectangles) {
        super(stripWidth, rectangles);
    }

    @Override
    public List<T> pack() {
        // TODO Auto-generated method stub
        return null;
    }

}
