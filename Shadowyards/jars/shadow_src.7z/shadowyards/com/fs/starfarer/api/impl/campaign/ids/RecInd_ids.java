//courtesy of Sir Hartley
//kept in the original state for reference purposes
package com.fs.starfarer.api.impl.campaign.ids;

import com.fs.starfarer.api.Global;

public class RecInd_ids {
    
    //Items
    public static final String ITEM_1 = "item_1";
    public static final String ITEM_2 = "item_2";
    public static final String ITEM_3 = "item_3";

    //Industries
    public static final String BASE_IND = "baseReconfigurableIndustry";
    public static final String UPGRADE_1 = "upgrade1";
    public static final String UPGRADE_2 = "upgrade2";
    public static final String UPGRADE_3 = "upgrade3";
    
}
