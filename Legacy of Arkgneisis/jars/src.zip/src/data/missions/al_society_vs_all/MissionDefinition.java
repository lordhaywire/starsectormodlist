package data.missions.al_society_vs_all;

import com.fs.starfarer.api.mission.MissionDefinitionAPI;
import data.missions.BaseRandomloaMissionDefinition;

public class MissionDefinition extends BaseRandomloaMissionDefinition
{
    @Override
    public void defineMission(MissionDefinitionAPI api)
    {
        chooseFactions("al_ars", null);
        super.defineMission(api);
    }
}
