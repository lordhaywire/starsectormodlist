package data.missions.loa_testmission;

import com.fs.starfarer.api.fleet.FleetGoal;
import com.fs.starfarer.api.fleet.FleetMemberType;
import com.fs.starfarer.api.impl.campaign.ids.StarTypes;
import com.fs.starfarer.api.mission.FleetSide;
import com.fs.starfarer.api.mission.MissionDefinitionAPI;
import com.fs.starfarer.api.mission.MissionDefinitionPlugin;

public class MissionDefinition implements MissionDefinitionPlugin {

	public void defineMission(MissionDefinitionAPI api) {

		// Set up the fleets so we can add ships and fighter wings to them.
		// In this scenario, the fleets are attacking each other, but
		// in other scenarios, a fleet may be defending or trying to escape
		api.initFleet(FleetSide.PLAYER, "ISS", FleetGoal.ATTACK, false);
		api.initFleet(FleetSide.ENEMY, "ISS", FleetGoal.ATTACK, true);

//		api.getDefaultCommander(FleetSide.PLAYER).getStats().setSkillLevel(Skills.COORDINATED_MANEUVERS, 3);
//		api.getDefaultCommander(FleetSide.PLAYER).getStats().setSkillLevel(Skills.ELECTRONIC_WARFARE, 3);
		
		// Set a small blurb for each fleet that shows up on the mission detail and
		// mission results screens to identify each side.
		api.setFleetTagline(FleetSide.PLAYER, "Vessels to be tested");
		api.setFleetTagline(FleetSide.ENEMY, "Placeholder");
		
		// These show up as items in the bulleted list under 
		// "Tactical Objectives" on the mission detail screen
                //api.addBriefingItem("Note: Test using vanilla weapons and wings only, weapons not properly implimented yet.");
		
		// Set up the player's fleet.  Variant names come from the
		// files in data/variants and data/variants/fighters
                 //api.addToFleet(FleetSide.PLAYER, "loaht_champion1_blank", FleetMemberType.SHIP, "Lancer", false);
                //api.addToFleet(FleetSide.PLAYER, "loaht_savior_blank", FleetMemberType.SHIP, "Savior", false);
                
                //api.addToFleet(FleetSide.PLAYER, "al_wtp_blank", FleetMemberType.SHIP, "Test", false);
                api.addToFleet(FleetSide.PLAYER, "loalt_oogik_blank", FleetMemberType.SHIP, "Oogik", false);
                api.addToFleet(FleetSide.PLAYER, "loalt_taath_blank", FleetMemberType.SHIP, "Taath", false);
                api.addToFleet(FleetSide.PLAYER, "loalt_nicke_blank", FleetMemberType.SHIP, "Nicke", false);
                api.addToFleet(FleetSide.PLAYER, "loalt_eylamn_blank", FleetMemberType.SHIP, "Eylamn", false);
                api.addToFleet(FleetSide.PLAYER, "loalt_alanqil_blank", FleetMemberType.SHIP, "Alanqil", false);
                api.addToFleet(FleetSide.PLAYER, "loalt_thlos_blank", FleetMemberType.SHIP, "Thlos", false);

//                api.addToFleet(FleetSide.PLAYER, "loamtp_macnamara_boss_blank", FleetMemberType.SHIP, "Big Mac", false);
                //api.addToFleet(FleetSide.PLAYER, "loa_arscapitol_core_variant", FleetMemberType.SHIP, "Capitol", false);
                //api.addToFleet(FleetSide.PLAYER, "loa_arsstation_core_1_blank", FleetMemberType.SHIP, "Orbital Station", false);
               // api.addToFleet(FleetSide.PLAYER, "loa_arsstation_core_2_blank", FleetMemberType.SHIP, "Battles Sation", false);
                //api.addToFleet(FleetSide.PLAYER, "loa_arsstation_core_3_blank", FleetMemberType.SHIP, "Star Fortress", false);
                //api.addToFleet(FleetSide.PLAYER, "loamt_fox_blank", FleetMemberType.SHIP, "Fox", false);
                //api.addToFleet(FleetSide.PLAYER, "loamtg_fox_blank", FleetMemberType.SHIP, "Fox", false);
                //api.addToFleet(FleetSide.PLAYER, "loamtp_fox_blank", FleetMemberType.SHIP, "Fox", false);
                //api.addToFleet(FleetSide.PLAYER, "loamt_edith_blank", FleetMemberType.SHIP, "Edith", false);
                //api.addToFleet(FleetSide.PLAYER, "loamt_walsh_blank", FleetMemberType.SHIP, "Walsh", false);
                //api.addToFleet(FleetSide.PLAYER, "loamtg_walsh_blank", FleetMemberType.SHIP, "Walsh", false);
		//api.addToFleet(FleetSide.PLAYER, "loamt_sherman_blank", FleetMemberType.SHIP, "Sherman", false);
                //api.addToFleet(FleetSide.PLAYER, "loa_ike_blank", FleetMemberType.SHIP, "Ike", false);
		//api.addToFleet(FleetSide.PLAYER, "loamt_reid_blank", FleetMemberType.SHIP, "Reid", false);
                //api.addToFleet(FleetSide.PLAYER, "loamt_thatcher_blank", FleetMemberType.SHIP, "Thatcher", false);
                //api.addToFleet(FleetSide.PLAYER, "loamtg_thatcher_blank", FleetMemberType.SHIP, "Thatcher", false);
                //api.addToFleet(FleetSide.PLAYER, "loamtp_thatcher_blank", FleetMemberType.SHIP, "Thatcher", false);
                //api.addToFleet(FleetSide.PLAYER, "loamt_norwood_blank", FleetMemberType.SHIP, "Norwood", false);
                //api.addToFleet(FleetSide.PLAYER, "loamt_burke_blank", FleetMemberType.SHIP, "Burke", false);
                //api.addToFleet(FleetSide.PLAYER, "loamtp_burke_blank", FleetMemberType.SHIP, "Burke (P)", false);
		//api.addToFleet(FleetSide.PLAYER, "loamt_victoria_blank", FleetMemberType.SHIP, "Victoria", false);	
                //api.addToFleet(FleetSide.PLAYER, "loamt_caswell_blank", FleetMemberType.SHIP, "Caswell", false);
                //api.addToFleet(FleetSide.PLAYER, "loamt_osmond_blank", FleetMemberType.SHIP, "Osmond", false);
                //api.addToFleet(FleetSide.PLAYER, "loamt_jameson_blank", FleetMemberType.SHIP, "Jameson", false);
                //api.addToFleet(FleetSide.PLAYER, "loamt_hawke_blank", FleetMemberType.SHIP, "Hawke", false);
                //api.addToFleet(FleetSide.PLAYER, "loamtg_hawke_blank", FleetMemberType.SHIP, "Hawke", false);
                //api.addToFleet(FleetSide.PLAYER, "loamtp_hawke_blank", FleetMemberType.SHIP, "Hawke", false);
                //api.addToFleet(FleetSide.PLAYER, "loamt_king_blank", FleetMemberType.SHIP, "King", false);
		//api.addToFleet(FleetSide.PLAYER, "loamt_lyons_blank", FleetMemberType.SHIP, "Lyons", false);
                //api.addToFleet(FleetSide.PLAYER, "loamt_macnamara_blank", FleetMemberType.SHIP, "Macnamara", false);
                //api.addToFleet(FleetSide.PLAYER, "loamt_donovan_blank", FleetMemberType.SHIP, "Donovan", false);
                //api.addToFleet(FleetSide.PLAYER, "loamt_alastair_blank", FleetMemberType.SHIP, "Alastair", false);
                //api.addToFleet(FleetSide.PLAYER, "loamt_gaillard_blank", FleetMemberType.SHIP, "Gaillard", false);
                //api.addToFleet(FleetSide.PLAYER, "al_gregory_g_blank", FleetMemberType.SHIP, "Gregory", false);
                //api.addToFleet(FleetSide.PLAYER, "al_gregory_p_blank", FleetMemberType.SHIP, "Gregory", false);
                //api.addToFleet(FleetSide.PLAYER, "al_walsh_g_blank", FleetMemberType.SHIP, "Walsh", false);
                //api.addToFleet(FleetSide.PLAYER, "al_thatcher_g_blank", FleetMemberType.SHIP, "Thatcher", false);
                //api.addToFleet(FleetSide.PLAYER, "al_thatcher_p_blank", FleetMemberType.SHIP, "Thatcher", false);
                //api.addToFleet(FleetSide.PLAYER, "loa_hawke_g_blank", FleetMemberType.SHIP, "Hawke", false);
                //api.addToFleet(FleetSide.PLAYER, "loa_hawke_p_blank", FleetMemberType.SHIP, "Hawke", false);
		
		// Set up the enemy fleet.
		api.addToFleet(FleetSide.ENEMY, "mule_d_pirates_Smuggler", FleetMemberType.SHIP, "Cherenkov Bloom", false);
		
		api.defeatOnShipLoss("Stranger II");
		
		// Set up the map.
		float width = 12000f;
		float height = 12000f;
		api.initMap((float)-width/2f, (float)width/2f, (float)-height/2f, (float)height/2f);
		
		float minX = -width/2;
		float minY = -height/2;
		
		// Add an asteroid field
		api.addAsteroidField(minX, minY + height / 2, 0, 8000f,
							 20f, 70f, 100);
		
		api.addPlanet(0, 0, 50f, StarTypes.RED_GIANT, 250f, true);
		
	}

}
