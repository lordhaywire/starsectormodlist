package data.missions.al_all_vs_society;

import com.fs.starfarer.api.mission.MissionDefinitionAPI;
import data.missions.BaseRandomloaMissionDefinition;

public class MissionDefinition extends BaseRandomloaMissionDefinition
{
    @Override
    public void defineMission(MissionDefinitionAPI api)
    {
        chooseFactions(null, "al_ars");
        super.defineMission(api);
    }
}
