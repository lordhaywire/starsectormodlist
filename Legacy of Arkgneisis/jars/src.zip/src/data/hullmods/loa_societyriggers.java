package data.hullmods;

//import java.util.HashMap;
//import java.util.Map;
import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
//import com.fs.starfarer.api.impl.campaign.ids.Stats;
import com.fs.starfarer.api.util.Misc;

public class loa_societyriggers extends BaseHullMod {

    public static final float REPAIR_BONUS = 25f;
    public static final float MALFUNCTION_MOD = 25f;
    
     @Override
    public void applyEffectsBeforeShipCreation(HullSize hullSize, MutableShipStatsAPI stats, String id) {
        stats.getCriticalMalfunctionChance().modifyMult(id, 1f - MALFUNCTION_MOD / 100f);
        stats.getWeaponMalfunctionChance().modifyMult(id, 1f - MALFUNCTION_MOD / 100f);
        stats.getEngineMalfunctionChance().modifyMult(id, 1f - MALFUNCTION_MOD / 100f);
        stats.getCombatEngineRepairTimeMult().modifyMult(id, 1f - REPAIR_BONUS * 0.01f);
        stats.getCombatWeaponRepairTimeMult().modifyMult(id, 1f - REPAIR_BONUS * 0.01f);
        
    }
    
          @Override
	public String getDescriptionParam(int index, HullSize hullSize) {
		if (index == 0) return "" + (int) MALFUNCTION_MOD + "%";
                if (index == 1) return "" + (int) REPAIR_BONUS + "%";
		return null;
	}
    
    @Override //All you need is this to be honest. The framework will do everything on its own.
    public void applyEffectsAfterShipCreation(ShipAPI ship, String id) {
                if (ship.getVariant().hasHullMod("CHM_commission")) {
                    ship.getVariant().removeMod("CHM_commission");
                }
				// This is to remove the unnecessary dummy hull mod. Unless the player want it... but nah!
    }
}
