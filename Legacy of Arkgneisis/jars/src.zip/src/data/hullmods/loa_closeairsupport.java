package data.hullmods;

import com.fs.starfarer.api.GameState;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CampaignUIAPI;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipVariantAPI;
import com.fs.starfarer.api.loading.FighterWingSpecAPI;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;
import data.scripts.campaign.loa_closeairsupportmanager;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class loa_closeairsupport extends BaseHullMod {

    //IDs, displayed names and ground support bonuses of the fighters that gives bonuses.
    private static final List<CASData> CAS_DATA = new ArrayList<>();
    static {
        CAS_DATA.add(new CASData("ace_wing", "Ace Wing", 10));
        CAS_DATA.add(new CASData("baron_wing", "Baron Wing", 15));
        CAS_DATA.add(new CASData("duke_wing", "Duke Wing", 25));
    }

    @Override
    public void applyEffectsAfterShipCreation(ShipAPI ship, String id) {
        if (getSupportBonus(ship.getVariant()) <= 0) {
            ship.getVariant().removeMod(loa_closeairsupportmanager.HULLMOD_ID);
        }
    }

    //Actually applies the ground support bonus
    @Override
    public void applyEffectsBeforeShipCreation(ShipAPI.HullSize hullSize, MutableShipStatsAPI stats, String id) {
        stats.getDynamic().getMod("ground_support").modifyFlat(id, getSupportBonus(stats.getVariant()));
    }

    @Override
    public void addPostDescriptionSection(TooltipMakerAPI tooltip, ShipAPI.HullSize hullSize, ShipAPI ship, float width, boolean isForModSpec) {
        float pad = 3f;
        float opad = 10f;
        Color h = Misc.getHighlightColor();
        Color bad = Misc.getNegativeHighlightColor();

        if (isForModSpec || ship == null) return;
        if (Global.getSettings().getCurrentState() == GameState.TITLE) return;

        boolean mothballed = false;
        if (ship.getFleetMember() != null) {
            mothballed = ship.getFleetMember().isMothballed();
        }
        if (mothballed) {
            tooltip.addPara("Due to being mothballed, this ship provides %s to planetary raids.", opad, bad, "no bonus");
        } else {
            tooltip.addPara("Increases the effective strength of planetary raids by %s, up to the total number of marines in this fleet.", opad, h,
                    "" + getSupportBonus(ship.getVariant()));
        }
    }

    //Prevents the hullmod from being manually added or removed
    public boolean canBeAddedOrRemovedNow(ShipAPI ship, MarketAPI marketOrNull, CampaignUIAPI.CoreUITradeMode mode) {
        return false;
    }

    public String getCanNotBeInstalledNowReason(ShipAPI ship, MarketAPI marketOrNull, CampaignUIAPI.CoreUITradeMode mode) {
        boolean has = ship.getVariant().hasHullMod(spec.getId());
        String verb = "installed";
        if (has) verb = "removed or modified";
        return "Can never be " + verb + " manually";
    }

    //Gets the support bonus this ship offers to the fleet
    public static int getSupportBonus(ShipVariantAPI variant) {
        int result = 0;
        for (int i = 0; i < variant.getWings().size(); i++) {
            FighterWingSpecAPI wing = variant.getWing(i);
            if (wing != null) {
                result += getWingSupportBonus(wing.getId());
            }
        }

        return result;
    }

    //Gets the support bonus of a given wing
    private static int getWingSupportBonus(String wingID) {
        for (CASData data : CAS_DATA) {
            if (data.id.equals(wingID)) {
                return data.bonus;
            }
        }
        return 0;
    }

    //Simply check if a given wing has any support bonus
    public static boolean wingHasSupportBonus(String wingID) {
        for (CASData data : CAS_DATA) {
            if (data.id.equals(wingID)) {
                return true;
            }
        }
        return false;
    }

    //Utility class
    private static class CASData {
        String id;
        String name;
        int bonus;
        CASData(String id, String name, int bonus) {
            this.id = id;
            this.name = name;
            this.bonus = bonus;
        }
    }
}
