package data.hullmods;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.*;
import com.fs.starfarer.api.util.IntervalUtil;
import com.fs.starfarer.api.util.WeightedRandomPicker;

import java.awt.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * "Groups" missile weapons into groups where only one can fire at once, and switches among which weapon can fire depending on a set of rules
 * Note: Never put this on a player-pilotable ship! It'll be a mess and a half!
 *
 * @author Nicke535
 */
public class loa_fakemissiletubes extends BaseHullMod {
    //Name of the slot IDs we are to look for: all weapons that contain this ID string will be affected.
    //      For simplicity: we now only allow one weapon per ship (that seems to be the setup anyhow)
    private static final String WEAPON_SLOT_ID = "LOA_SWITCH";

    //Determines how often the AI of this script checks for conditions to change, thus forcing a different weapon option
    //  Should ideally be lower than 1 second, since that's the "lock" duration used in the script
    private static final float MIN_AI_TIMER_TIME = 0.15f;
    private static final float MAX_AI_TIMER_TIME = 0.2f;

    //Names of the four weapons to switch between, and the ammo type they represent [these should maybe be built-in
    // unique variants with infinite ammo or something?]:
    private static final String ROD_ID = "loa_rod_cap";
    private static final String CONE_ID = "loa_can_launcher_cap";
    private static final String STRING_ID = "loa_string_cap";
    private static final String MOSAIC_ID = "loa_mosaic_torpedo_cap";

    @Override
    public void advanceInCombat(ShipAPI ship, float amount) {
        CombatEngineAPI engine = Global.getCombatEngine();
        if (engine == null || engine.isPaused()) {
            return;
        }
        if (ship == null || !ship.isAlive()) {
            return;
        }

        //Ensure we have our private ship data
        InfoManager data;
        if (Global.getCombatEngine().getCustomData().get(this.getClass().getName() + "InfoManagerKey" + ship.getId()) instanceof InfoManager) {
            data = (InfoManager) Global.getCombatEngine().getCustomData().get(this.getClass().getName() + "InfoManagerKey" + ship.getId());
        } else {
            data = new InfoManager();
            Global.getCombatEngine().getCustomData().put(this.getClass().getName() + "InfoManagerKey" + ship.getId(), data);
        }
        List<WeaponAPI> weapons = data.weapons;
        IntervalUtil timer = data.timer;

        //If our weapon groups aren't populated, populate them
        if (weapons.isEmpty()) {
            for (WeaponAPI wep : ship.getAllWeapons()) {
                if (wep.getSlot().getId().contains(WEAPON_SLOT_ID)) {
                    weapons.add(wep);
                    //While we populate the list, we also put our weapons on cooldown, as our "initial" cooldown
                    wep.setRemainingCooldownTo(1f);
                }
            }
        }

        //If the population was succesful, we move on to the main part of the script
        if (!weapons.isEmpty()) {
            //Don't run this unless our timer has passed
            timer.advance(amount);
            if (timer.intervalElapsed()) {
                //First, check which preferred weapon we want to use this moment
                String preferredWeapon = pickPreferredWeapon(ship);

                //Then, check if any weapon is currently firing/has fired recently: if that's the case, we lock every other weapon to that thing's cooldown
                //If we already have a "locking" weapon, only look at that one to see if it's done locking us
                if (data.currentLockWeapon != null) {
                    if (data.currentLockWeapon.getAmmo() >= data.currentLockWeapon.getMaxAmmo()
                        && data.currentLockWeapon.getCooldownRemaining() < 1f) {
                        data.currentLockWeapon = null;
                    }
                } else {
                    for (WeaponAPI wep : weapons) {
                        //A weapon with non-full ammo means it is locking us: add it as our locking weapon
                        if (wep.getAmmo() < wep.getMaxAmmo()) {
                            data.currentLockWeapon = wep;
                            break;
                        }
                    }
                }

                //If we had a locking weapon, then everything except the locking weapon goes on cooldown
                if (data.currentLockWeapon != null) {
                    for (WeaponAPI wep : weapons) {
                        if (wep != data.currentLockWeapon) {
                            wep.setRemainingCooldownTo(1f);
                        }
                    }
                }

                //Lastly, if we don't have a lock weapon, ensure our preferred weapon is available and nothing else
                else {
                    for (WeaponAPI wep : weapons) {
                        if (wep.getSpec().getWeaponId().equals(preferredWeapon)) { //Stopgap
                            wep.setRemainingCooldownTo(0f);
                        } else {
                            wep.setRemainingCooldownTo(1f);
                        }
                    }
                }
            }
        }
    }

    private String pickPreferredWeapon(ShipAPI ship) {
        WeightedRandomPicker<String> picker = new WeightedRandomPicker<>();
        if (ship.getShipTarget() == null) {
            picker.add(ROD_ID);
            picker.add(CONE_ID);
            picker.add(STRING_ID);
        } else {
            ShipAPI target = ship.getShipTarget();
            if (target.getShield() == null
                    || target.getShield().getType().equals(ShieldAPI.ShieldType.NONE)
                    || target.getShield().getType().equals(ShieldAPI.ShieldType.PHASE)
                    || target.getFluxLevel() > 0.85f) {
                return MOSAIC_ID;
            }
            if (target.getFluxLevel() <= 0.5f) {
                picker.add(CONE_ID);
            }
            if (target.getMaxSpeed() > 50f && target.getEngineController().getFlameoutFraction() <= 0f) {
                picker.add(STRING_ID);
            }
            picker.add(ROD_ID);
        }

        return picker.pick();
    }

    @Override
    public String getUnapplicableReason(ShipAPI ship) {
        return "Built-in Exclusive: you should not be seeing this";
    }

    @Override
    public boolean isApplicableToShip(ShipAPI ship) {
        // Built-in exclusive
        return false;
    }

    //Class for managing the data each ship needs to individually save
    private class InfoManager {
        //Our weapon "group" on the ship: populated once per combat
        private List<WeaponAPI> weapons;

        private IntervalUtil timer;

        private WeaponAPI currentLockWeapon = null;

        InfoManager() {
            weapons = new ArrayList<>();
            timer = new IntervalUtil(MIN_AI_TIMER_TIME, MAX_AI_TIMER_TIME);
        }
    }
}
