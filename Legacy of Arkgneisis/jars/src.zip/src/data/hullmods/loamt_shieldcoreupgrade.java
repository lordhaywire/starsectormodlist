package data.hullmods;

import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class loamt_shieldcoreupgrade extends BaseHullMod {

    public static final float EFFICIENCY_BONUS = -0.2f;
    public static final float UPKEEP = 0.25f;
    
    @Override
    public void applyEffectsBeforeShipCreation(HullSize hullSize, MutableShipStatsAPI stats, String id) {
        stats.getShieldDamageTakenMult().modifyFlat(id, EFFICIENCY_BONUS);
        stats.getShieldUpkeepMult().modifyFlat(id, UPKEEP);
    }

    @Override
    public String getDescriptionParam(int index, HullSize hullSize) {
        if (index == 0) {
            return "0.2";
        }
        if (index == 1) {
            return "25" + "%";
        }
        return null;
    }

    @Override
    public String getUnapplicableReason(ShipAPI ship) {
        return "Only compatible with Exodus Initiative hulls.";
    }

    @Override
    public boolean isApplicableToShip(ShipAPI ship) {
        // Allows any ship with a loamt hull id
        return ship.getHullSpec().getHullId().startsWith("loamt_");
    }
}
