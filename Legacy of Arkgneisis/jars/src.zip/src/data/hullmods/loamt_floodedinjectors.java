package data.hullmods;

import java.awt.Color;
import java.util.HashMap;
import java.util.Map;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.*;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.impl.campaign.ids.HullMods;
import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.api.util.WeightedRandomPicker;
import java.util.HashSet;
import java.util.Set;
import org.lazywizard.lazylib.MathUtils;

public class loamt_floodedinjectors extends BaseHullMod {

	//Maximum chance for engine malfunctions: reached at 100% CR, so this will pretty much never be reached.
	//Scales linearly to no extra chance at 0% CR
        private final String ERROR = "al_errormod";
	private static final float MAX_ENGINE_MALFUNCTION_CHANCE = 0.075f;
	private static final float PEAK_MULT = -25f;

	//Color of the EMP arcs that spawns on guaranteed flameout
	public static Color LIGHTNING_COLOR = new Color(100, 170, 255);

	//Percentage (on the 1f-0f scale) of engines on the ship that will spawn an EMP arc. Rounded up, at least one arc always spawns
	public static final float ENGINE_ARC_AMOUNT = 1f;

                   private static final Set<String> BLOCKED_HULLMODS = new HashSet<>();
    static
    {
        // These hullmods will automatically be removed
        // This prevents unexplained hullmod blocking
        BLOCKED_HULLMODS.add("safetyoverrides");
    }
        
        @Override
    public void applyEffectsAfterShipCreation(ShipAPI ship, String id){
        
        for (String tmp : BLOCKED_HULLMODS) {
            if (ship.getVariant().getHullMods().contains(tmp)) {                
                ship.getVariant().removeMod(tmp);      
                ship.getVariant().addMod(ERROR);
            }
        }
    }
        
	//Sounds to play on guaranteed flameout. Allows customization between hullsizes, if desired
	private static Map<HullSize, String> SPECIAL_FLAMEOUT_SOUNDS = new HashMap<>();
	static {
		SPECIAL_FLAMEOUT_SOUNDS.put(HullSize.FRIGATE, "loa_injector_blowout");
		SPECIAL_FLAMEOUT_SOUNDS.put(HullSize.DESTROYER, "loa_injector_blowout");
		SPECIAL_FLAMEOUT_SOUNDS.put(HullSize.CRUISER, "loa_injector_blowout");
		SPECIAL_FLAMEOUT_SOUNDS.put(HullSize.CAPITAL_SHIP, "loa_injector_blowout");
	}

	//Maximum and minimum waiting time until a flameout is forced
	private static final float MAX_FLAMEOUT_DELAY = 4f;
	private static final float MIN_FLAMEOUT_DELAY = 0f;

	//Speed bonuses depending on hullsize
	private static Map<HullSize, Float> speed = new HashMap<>();
	static {
		speed.put(HullSize.FRIGATE, 50f);
		speed.put(HullSize.DESTROYER, 30f);
		speed.put(HullSize.CRUISER, 20f);
		speed.put(HullSize.CAPITAL_SHIP, 10f);
	}
	
//	private static Map flux = new HashMap();
//	static {
//		flux.put(HullSize.FRIGATE, 100f);
//		flux.put(HullSize.DESTROYER, 150f);
//		flux.put(HullSize.CRUISER, 200f);
//		flux.put(HullSize.CAPITAL_SHIP, 300f);
//	}
	
	//private static final float PEAK_MULT = 0.3333f;
	//private static final float PEAK_MULT = 0.33f;
	//private static final float CR_DEG_MULT = 2f;
	//private static final float OVERLOAD_DUR = 50f;
	//private static final float FLUX_DISSIPATION_MULT = 2f;
	//private static final float FLUX_CAPACITY_MULT = 1f;
	
	private static final float RANGE_THRESHOLD = 600f;
	private static final float RANGE_MULT = 0.25f;
	
	//private static final float RECOIL_MULT = 2f;
	//private static final float MALFUNCTION_PROB = 0.05f;
	
	public void applyEffectsBeforeShipCreation(HullSize hullSize, MutableShipStatsAPI stats, String id) {
		stats.getPeakCRDuration().modifyPercent(id, PEAK_MULT);
		stats.getMaxSpeed().modifyFlat(id, (Float) speed.get(hullSize));
		stats.getAcceleration().modifyFlat(id, (Float) speed.get(hullSize) * 2f);
		stats.getDeceleration().modifyFlat(id, (Float) speed.get(hullSize) * 2f);
		stats.getZeroFluxMinimumFluxLevel().modifyFlat(id, 2f); // set to two, meaning boost is always on 
		
		//stats.getFluxDissipation().modifyMult(id, FLUX_DISSIPATION_MULT);
		
		//stats.getPeakCRDuration().modifyMult(id, PEAK_MULT);
		//stats.getCRLossPerSecondPercent().modifyMult(id, CR_DEG_MULT);
//		stats.getWeaponMalfunctionChance().modifyFlat(id, MALFUNCTION_PROB);
//		stats.getEngineMalfunctionChance().modifyFlat(id, MALFUNCTION_PROB);
		
		//stats.getOverloadTimeMod().modifyPercent(id, OVERLOAD_DUR);
		//stats.getVentRateMult().modifyMult(id, 0f);
		
		stats.getWeaponRangeThreshold().modifyFlat(id, RANGE_THRESHOLD);
		stats.getWeaponRangeMultPastThreshold().modifyMult(id, RANGE_MULT);
		
//		stats.getMaxRecoilMult().modifyMult(id, 1.5f);
//		stats.getRecoilPerShotMult().modifyMult(id, RECOIL_MULT);
	}
	
	public String getDescriptionParam(int index, HullSize hullSize) {
		if (index == 0) return "" + ((Float) speed.get(HullSize.FRIGATE)).intValue();
		if (index == 1) return "" + ((Float) speed.get(HullSize.DESTROYER)).intValue();
		if (index == 2) return "" + ((Float) speed.get(HullSize.CRUISER)).intValue();
		if (index == 3) return "" + ((Float) speed.get(HullSize.CAPITAL_SHIP)).intValue();
		if (index == 4) return Misc.getRoundedValue(RANGE_THRESHOLD);
		if (index == 5) return Misc.getRoundedValue(PEAK_MULT * -1)+ "%";
                if (index == 6) return "Safety Overrides";
		//if (index == 3) return (int)OVERLOAD_DUR + "%";
		
//		if (index == 0) return "" + ((Float) speed.get(hullSize)).intValue();
//		if (index == 1) return "" + (int)((FLUX_DISSIPATION_MULT - 1f) * 100f) + "%";
//		if (index == 2) return "" + (int)((1f - PEAK_MULT) * 100f) + "%";
		
//		if (index == 0) return "" + ((Float) speed.get(HullSize.FRIGATE)).intValue();
//		if (index == 1) return "" + ((Float) speed.get(HullSize.DESTROYER)).intValue();
//		if (index == 2) return "" + ((Float) speed.get(HullSize.CRUISER)).intValue();
//		if (index == 3) return "" + ((Float) speed.get(HullSize.CAPITAL_SHIP)).intValue();
//		
//		if (index == 4) return "" + (int)((FLUX_DISSIPATION_MULT - 1f) * 100f);
//		if (index == 5) return "" + (int)((1f - PEAK_MULT) * 100f);
		
		return null;
	}

	private Color color = new Color(50,255,255,255);
	@Override
	public void advanceInCombat(ShipAPI ship, float amount) {
		//ship.getFluxTracker().setHardFlux(ship.getFluxTracker().getCurrFlux());
//		if (ship.getEngineController().isAccelerating() || 
//				ship.getEngineController().isAcceleratingBackwards() ||
//				ship.getEngineController().isDecelerating() ||
//				ship.getEngineController().isTurningLeft() ||
//				ship.getEngineController().isTurningRight() ||
//				ship.getEngineController().isStrafingLeft() ||
//				ship.getEngineController().isStrafingRight()) {
			ship.getEngineController().fadeToOtherColor(this, color, null, 1f, 0.4f);
			ship.getEngineController().extendFlame(this, -0.5f, 2f, 0.25f);
//		}

		//Only triggers if we have less than starting CR in the combat (we're now loosing CR)
		if (ship.getCurrentCR() < ship.getCRAtDeployment()) {
			//If we have yet to spawn a flameout manager, do that
			if (!(Global.getCombatEngine().getCustomData().get(this.getClass().getName()+"FlameoutManagerKey"+ship.getId()) instanceof FlameoutManager)) {
				Global.getCombatEngine().getCustomData().put(this.getClass().getName()+"FlameoutManagerKey"+ship.getId(), new FlameoutManager());
			}
			//If we have a flameout manager, check if it's ready to force a flameout: if it is, force the flameout
			else {
				FlameoutManager manager = (FlameoutManager)Global.getCombatEngine().getCustomData().get(this.getClass().getName()+"FlameoutManagerKey"+ship.getId());
				manager.tick(amount);
				if (manager.shouldFlameout()) {
					manager.hasFlamedOut = true;
					ship.getEngineController().forceFlameout();

					//Also play a sound and spawn decorative EMP arcs
					Global.getSoundPlayer().playSound(SPECIAL_FLAMEOUT_SOUNDS.get(ship.getHullSize()), 1f, 1f, ship.getLocation(), Misc.ZERO);
					int numberOfArcs = (int)Math.ceil(ship.getEngineController().getShipEngines().size()*ENGINE_ARC_AMOUNT);
					WeightedRandomPicker<ShipEngineControllerAPI.ShipEngineAPI> picker = new WeightedRandomPicker<>();
					picker.addAll(ship.getEngineController().getShipEngines());
					for (int i = 0; i < numberOfArcs; i++) {
						ShipEngineControllerAPI.ShipEngineAPI engine = picker.pickAndRemove();
						Global.getCombatEngine().spawnEmpArcPierceShields(ship, engine.getLocation(), ship, ship, DamageType.ENERGY,
								0f, 0f, 99999f, null,
								MathUtils.getRandomNumberInRange(15f, 18f), LIGHTNING_COLOR, Color.white);
					}
				}


				//Don't modify flameout chance until after we've gotten the guaranteed flameout
				if (manager.hasFlamedOut) {
					//Modify flameot chance by a flat amount, depending on CR level
					float crLevel = ship.getCurrentCR();
                    ship.getMutableStats().getEngineMalfunctionChance().modifyFlat(
                            this.getClass().getName()+"MalfunctionKey",
                            MAX_ENGINE_MALFUNCTION_CHANCE*crLevel);
				}
			}
		}
	}

    @Override
    public String getUnapplicableReason(ShipAPI ship) {
        return "Only compatible with Exodus Initiative hulls.";
    }

    @Override
    public boolean isApplicableToShip(ShipAPI ship) {
        // Allows any ship with a loamt hull id
        return ship.getHullSpec().getHullId().startsWith("loamt_");
    }	

    //Class for managing the forced flameout the hullmod causes
    private class FlameoutManager {
		private float waitTime;
		boolean hasFlamedOut = false;
		private float counter = 0f;

		FlameoutManager() {
			waitTime = MathUtils.getRandomNumberInRange(MIN_FLAMEOUT_DELAY, MAX_FLAMEOUT_DELAY);
		}

		void tick(float amount) {
			counter += amount;
		}

		boolean shouldFlameout() {
			return (counter >= waitTime) && !hasFlamedOut;
		}
	}
}
