//By Nicke535, a simple hullmod that increases energy weapon ranges and increases beam OP costs
package data.hullmods;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.WeaponAPI;
import com.fs.starfarer.api.combat.listeners.WeaponRangeModifier;
import com.fs.starfarer.api.impl.campaign.ids.Stats;
import com.fs.starfarer.api.util.Misc;
import org.lazywizard.lazylib.MathUtils;

import java.util.EnumMap;

import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class loa_spatiallensing extends BaseHullMod {

    private final String ERROR = "al_errormod";
    public static final float SHIELD_BONUS_TURN = 100f;

    //This determines which non-energy hybrid weapon types the range bonus applies to
    private static final boolean AFFECTS_SYNERGY = false;
    private static final boolean AFFECTS_HYBRID = false;
    private static final boolean AFFECTS_UNIVERSAL = false;

    //A list of unique weapon IDs that ignore all other settings and always get the range bonus, regardless of weapon type
    //  They still care about the damage limitations, however
    public static final Set<String> ALWAYS_AFFECTED_WEAPONS = new HashSet<>();
    static {
        //ALWAYS_AFFECTED_WEAPONS.add("some_unique_id_that_doesnt_exist");
    }

    //The sound the ship plays occasionally in combat, and the "bonus" sound played sometimes at low hull
    private static final String PERIODIC_SOUND = "loa_hightech_thrum";
    private static final String PERIODIC_LOWHULL_SOUND = "loa_hightech_failure";

    //How often the sound plays at minimum and maximum flux, respectively. Linearly interpolates between the values for everything inbetween
    private static final float SOUND_PERIOD_MIN_FLUX = 30f;
    private static final float SOUND_PERIOD_MAX_FLUX = 5f;

    //Chance for the "bonus sound" to play at maximum and zero hull level, respectively. Linearly interpolates between the values for everything inbetween
    private static final float BONUS_SOUND_CHANCE_MAX_HULL = 0f;
    private static final float BONUS_SOUND_CHANCE_ZERO_HULL = 0.7f;

    //The damage/shot and beam DPS values at which energy weapons get their maximum range bonus
    private static final float DAMAGE_FOR_FULL_BONUS = 250f;
    private static final float DPS_FOR_FULL_BONUS = 500f;

    //The damage/shot and beam DPS values at which energy weapons have completely lost their range bonuses
    private static final float DAMAGE_FOR_NO_BONUS = 1000f;
    private static final float DPS_FOR_NO_BONUS = 1000f;

    //List of range bonuses by hull size
    //Note that this is the MAXIMUM possible bonus: depending on our Damage Limits and DPS limits specified above, the actual bonus varies linearly
    public static Map<ShipAPI.HullSize, Float> ENERGY_RANGE_BONUSES = new EnumMap<ShipAPI.HullSize, Float>(ShipAPI.HullSize.class);
    static {
        ENERGY_RANGE_BONUSES.put(ShipAPI.HullSize.FIGHTER, 0f);
        ENERGY_RANGE_BONUSES.put(ShipAPI.HullSize.FRIGATE, 0f);
        ENERGY_RANGE_BONUSES.put(ShipAPI.HullSize.DESTROYER, 200f);
        ENERGY_RANGE_BONUSES.put(ShipAPI.HullSize.CRUISER, 200f);
        ENERGY_RANGE_BONUSES.put(ShipAPI.HullSize.CAPITAL_SHIP, 200f);
    }

    //List of OP cost increases for beam weapons
    public static Map<WeaponAPI.WeaponSize, Integer> BEAM_COST_INCREASES = new EnumMap<WeaponAPI.WeaponSize, Integer>(WeaponAPI.WeaponSize.class);
    static {
        BEAM_COST_INCREASES.put(WeaponAPI.WeaponSize.SMALL, 0);
        BEAM_COST_INCREASES.put(WeaponAPI.WeaponSize.MEDIUM, 0);
        BEAM_COST_INCREASES.put(WeaponAPI.WeaponSize.LARGE, 0);
    }

    //Disallowed hullmods on this ship
    private static final Set<String> BLOCKED_HULLMODS = new HashSet<>();
    static
    {
        // These hullmods will automatically be removed
        // This prevents unexplained hullmod blocking
        BLOCKED_HULLMODS.add("advancedoptics");
    }

    //Applies the effects
    @Override
    public void applyEffectsBeforeShipCreation(ShipAPI.HullSize hullSize, MutableShipStatsAPI stats, String id) {
        stats.getShieldTurnRateMult().modifyPercent(id, SHIELD_BONUS_TURN);
        stats.getDynamic().getMod(Stats.SMALL_BEAM_MOD).modifyFlat(id, BEAM_COST_INCREASES.get(WeaponAPI.WeaponSize.SMALL));
        stats.getDynamic().getMod(Stats.MEDIUM_BEAM_MOD).modifyFlat(id, BEAM_COST_INCREASES.get(WeaponAPI.WeaponSize.MEDIUM));
        stats.getDynamic().getMod(Stats.LARGE_BEAM_MOD).modifyFlat(id, BEAM_COST_INCREASES.get(WeaponAPI.WeaponSize.LARGE));
    }


    //Handles hullmod blocking, and our new fancy-pancy listener
    @Override
    public void applyEffectsAfterShipCreation(ShipAPI ship, String id){
        for (String tmp : BLOCKED_HULLMODS) {
            if (ship.getVariant().getHullMods().contains(tmp)) {
                ship.getVariant().removeMod(tmp);
                ship.getVariant().addMod(ERROR);
            }
        }

        //The safety check shouldn't be needed, but it doesn't hurt since I'm not sure how vanilla handles it
        //TODO: if later testing reveals this isn't needed, remove the if-case
        if (!ship.hasListenerOfClass(SpatialLensingListener.class)) {
            ship.addListener(new SpatialLensingListener());
        }
    }

    //Applies sound effects that the system causes
    @Override
    public void advanceInCombat(ShipAPI ship, float amount) {
        //Sound playing is ignored if we're dead or have disappeared
        if (ship.isHulk() || !Global.getCombatEngine().isEntityInPlay(ship)) {
            return;
        }

        //Checks our timer, or initializes it if it doesn't already exist
        float timer = 0f;
        if (Global.getCombatEngine().getCustomData().get("loa_spatiallensing_" + ship.getId() + "_sound_timer") instanceof Float) {
            timer = (float)Global.getCombatEngine().getCustomData().get("loa_spatiallensing_" + ship.getId() + "_sound_timer");
        } else {
            timer = MathUtils.getRandomNumberInRange(0f, SOUND_PERIOD_MIN_FLUX);
        }

        //If our timer has passed the activation threshold, play a sound
        float activationTime = (SOUND_PERIOD_MIN_FLUX * (1f - ship.getFluxLevel())) + (SOUND_PERIOD_MAX_FLUX * ship.getFluxLevel());
        if (timer > activationTime) {
            timer = 0f;
            Global.getSoundPlayer().playSound(PERIODIC_SOUND, 1f, 1f, ship.getLocation(), ship.getVelocity());

            //Also test if a bonus sound should be played due to low hull
            float lowHullTriggerChance = (BONUS_SOUND_CHANCE_ZERO_HULL * (1f - ship.getHullLevel())) + (BONUS_SOUND_CHANCE_MAX_HULL * ship.getHullLevel());
            if (Math.random() < lowHullTriggerChance) {
                Global.getSoundPlayer().playSound(PERIODIC_LOWHULL_SOUND, 1f, 1f, ship.getLocation(), ship.getVelocity());
            }
        } else {
            timer += amount;
        }

        //Updates our timer for later frames
        Global.getCombatEngine().getCustomData().put("loa_spatiallensing_" + ship.getId() + "_sound_timer", timer);
    }
    
    //Never applicable: only comes built-in
    @Override
    public boolean isApplicableToShip(ShipAPI ship) {
        return false;
    }

    //Adds the description strings: as it's written, intended to have "energy weapon range increases by %s/%s/%s, depending on hullsize." and "beam weapon costs %s/%s/%s more OP than usual, depending on weapon size"
    //somewhere in the description (or equivalent sentences)
    public String getDescriptionParam(int index, ShipAPI.HullSize hullSize) {
        if (index == 0) return "" + (int)Math.floor(ENERGY_RANGE_BONUSES.get(ShipAPI.HullSize.CAPITAL_SHIP));
        //if (index == 1) return "" + (int)Math.floor(BEAM_COST_INCREASES.get(WeaponAPI.WeaponSize.SMALL));
        if (index == 1) return "Advanced Optics";
        return null;
    }

    //This hullmod affect OP costs
    @Override
    public boolean affectsOPCosts() {
        return true;
    }


    //Our new fancy-pancy range modifier listener!
    private class SpatialLensingListener implements WeaponRangeModifier{
        @Override
        public float getWeaponRangeFlatMod(ShipAPI ship, WeaponAPI weapon) {
            //Only energy weapons are affected by the increase
            if (!weapon.getType().equals(WeaponAPI.WeaponType.ENERGY)
                && (!AFFECTS_SYNERGY || !weapon.getType().equals(WeaponAPI.WeaponType.SYNERGY))
                && (!AFFECTS_HYBRID || !weapon.getType().equals(WeaponAPI.WeaponType.HYBRID))
                && (!AFFECTS_UNIVERSAL || !weapon.getType().equals(WeaponAPI.WeaponType.UNIVERSAL))
                && !ALWAYS_AFFECTED_WEAPONS.contains(weapon.getId())) {
                return 0f;
            }

            float effectLevel = 0f;
            float maxBonus = ENERGY_RANGE_BONUSES.get(ship.getHullSize());

            //This just saves minor performance: if our maximum bonus is literally zero, no need to do ANY calculations
            if (maxBonus == 0f) {
                return 0f;
            }

            //First: are we a beam weapon?
            if (weapon.isBeam()) {
                //What is our DPS? That affects the range we get
                float dps = weapon.getDerivedStats().getDps();
                //Burst beams have a different way of storing their DPS
                if (weapon.isBurstBeam()) {
                    dps = weapon.getDamage().getBaseDamage();
                }
                if (dps <= DPS_FOR_FULL_BONUS) {
                    effectLevel = 1f;
                } else if (dps >= DPS_FOR_NO_BONUS) {
                    effectLevel = 0f;
                } else {
                    effectLevel = 1f - ((dps - DPS_FOR_FULL_BONUS) / (DPS_FOR_NO_BONUS-DPS_FOR_FULL_BONUS));
                }
            } else {
                //What is our damage/shot? That affects the range
                float damage = weapon.getDerivedStats().getDamagePerShot();
                if (damage <= DAMAGE_FOR_FULL_BONUS) {
                    effectLevel = 1f;
                } else if (damage >= DAMAGE_FOR_NO_BONUS) {
                    effectLevel = 0f;
                } else {
                    effectLevel = 1f - ((damage - DAMAGE_FOR_FULL_BONUS) / (DAMAGE_FOR_NO_BONUS-DAMAGE_FOR_FULL_BONUS));
                }
            }

            //Also, we want to get the weapon's percentage increases to range, since this is supposed to be a "base" range increase
            //If this turns out too expensive, we can remove the listener manager part: it's frankly a bit overkill.
            //TODO: double-check that the performance is not horrible, and adjust thereafter
            float percentRangeIncreases = ship.getMutableStats().getEnergyWeaponRangeBonus().getPercentMod();
            if (ship.hasListenerOfClass(WeaponRangeModifier.class)) {
                for (WeaponRangeModifier listener : ship.getListeners(WeaponRangeModifier.class)) {
                    //Should not be needed, but good practice: no infinite loops allowed here, no
                    if (listener == this) {
                        continue;
                    }
                    percentRangeIncreases += listener.getWeaponRangePercentMod(ship, weapon);
                }
            }

            //Finally, return the bonus depending on our effect level and the percent range increases
            return (Misc.interpolate(0f, maxBonus, effectLevel)) * (1f + (percentRangeIncreases/100f));
        }

        //Non-flat increases are just zero
        @Override
        public float getWeaponRangeMultMod(ShipAPI ship, WeaponAPI weapon) {
            return 1f;
        }
        @Override
        public float getWeaponRangePercentMod(ShipAPI ship, WeaponAPI weapon) {
            return 0f;
        }
    }

}
