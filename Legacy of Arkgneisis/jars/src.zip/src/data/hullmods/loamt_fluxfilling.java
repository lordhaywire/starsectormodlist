package data.hullmods;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import org.lazywizard.lazylib.MathUtils;
import org.lwjgl.util.vector.Vector2f;

import java.util.*;

/**
 * Small hullmod that trades cargo for flux bonuses
 * Also has an additional overload chance when suffering a lot of flux in a short time
 * @author Nicke535
 */
public class loamt_fluxfilling extends BaseHullMod {
    //How long we "remember" flux increases for the purpose of triggering overloads
    private static final float FLUX_REMEMBER_TIME = 3f;

    //The percentage of our max flux we must suffer within the "overload check time" to get a chance to overload
    //      We also remove this much "remembered" flux if we succeed in not overloading, so you could for example roll
    //      overload chance twice if you take twice this amount of flux within the allotted time
    private static final float FLUX_FRACTION_FOR_OVERLOAD = 0.2f;

    //The chance any given overload "chance" triggers an actual overload
    private static final float OVERLOAD_CHANCE = 0.33f;

    //Duration of the overload if it triggers
    private static final float OVERLOAD_DURATION = 0.5f;

    //Stat maps for cargo loss, flux dissipation and flux capacity, based on hullsize
    private static final Map<HullSize, Integer> CARGO_LOSS = new HashMap<>();
    static {
        CARGO_LOSS.put(HullSize.FIGHTER, 0);
        CARGO_LOSS.put(HullSize.FRIGATE, 25);
        CARGO_LOSS.put(HullSize.DESTROYER, 50);
        CARGO_LOSS.put(HullSize.CRUISER, 75);
        CARGO_LOSS.put(HullSize.CAPITAL_SHIP, 100);
    }

    //Multiplier for how effective flux vents are on the ship
    private static final float FLUX_VENT_MULT = 1f;

    //Multiplier for how effective flux capacitors are on the ship
    private static final float FLUX_CAPACITOR_MULT = 1f;
    
    @Override
    public void applyEffectsBeforeShipCreation(HullSize hullSize, MutableShipStatsAPI stats, String id) {
        stats.getCargoMod().modifyFlat(id, -CARGO_LOSS.get(hullSize));
    }

    @Override
    public void applyEffectsAfterShipCreation(ShipAPI ship, String id) {
        ship.getMutableStats().getFluxCapacity().modifyFlat(id, ship.getVariant().getNumFluxCapacitors() * 200f * FLUX_CAPACITOR_MULT);
        ship.getMutableStats().getFluxDissipation().modifyFlat(id, ship.getVariant().getNumFluxVents() * 10f * FLUX_VENT_MULT);
    }

    @Override
    public String getDescriptionParam(int index, HullSize hullSize) {
        if (index == 0) {
            return "Doubles";
        }
        if (index == 1) {
            return "Overloads";
        }
        if (index == 2) {
            return ""+Math.round((FLUX_FRACTION_FOR_OVERLOAD)*100f)+"%";
        }
        if (index == 3) {
            return ""+CARGO_LOSS.get(HullSize.FRIGATE);
        }
        if (index == 4) {
            return ""+CARGO_LOSS.get(HullSize.DESTROYER);
        }
        if (index == 5) {
            return ""+CARGO_LOSS.get(HullSize.CRUISER);
        }
        if (index == 6) {
            return ""+CARGO_LOSS.get(HullSize.CAPITAL_SHIP);
        }
        return null;
    }

    @Override
    public String getUnapplicableReason(ShipAPI ship) {
        if (!ship.getHullSpec().getHullId().startsWith("loamt_")) {
            return "Only compatible with Exodus Initiative hulls.";
        }
        return "Needs "+Math.round(CARGO_LOSS.get(ship.getHullSize()))+" available cargo space";
    }

    @Override
    public boolean isApplicableToShip(ShipAPI ship) {
        // Allows any ship with a loamt hull id...
        if (!ship.getHullSpec().getHullId().startsWith("loamt_")) {
            return false;
        }
        // ...AS LONG AS their cargo capacity is enough
        return ship.getHullSpec().getCargo() >= CARGO_LOSS.get(ship.getHullSize());
    }

    @Override
    public void advanceInCombat(ShipAPI ship, float amount) {
        FluxDataQueue fluxData = null;
        Object gottenData = Global.getCombatEngine().getCustomData().get(this.getClass().getName() + "_FluxData_" + ship.getId());
        if (gottenData instanceof FluxDataQueue) {
            fluxData = (FluxDataQueue) gottenData;
        } else {
            fluxData = new FluxDataQueue();
        }

        //First, tick the times of all flux data
        for (FluxDataPoint point : fluxData) {
            point.lifetime -= amount;
        }

        //Then, remove all the data that has expired
        while (fluxData.peek() != null && fluxData.peek().lifetime <= 0) {
            fluxData.poll();
        }

        //After that, add our new flux data for this frame
        fluxData.push(new FluxDataPoint(ship.getFluxTracker().getCurrFlux()));

        //Lastly, check all the old flux data points: then, pick the lowest point and check our current flux
        // compared to it. If it's above the threshold, check for overload. If not, do nothing
        float lowestFlux = ship.getFluxTracker().getCurrFlux();
        for (FluxDataPoint point : fluxData) {
            lowestFlux = Math.min(lowestFlux, point.flux);
        }
        boolean checkedForOverload = false;
        float threshold = FLUX_FRACTION_FOR_OVERLOAD*ship.getMaxFlux();
        while ((ship.getFluxTracker().getCurrFlux()-lowestFlux) > threshold
                && !ship.getFluxTracker().isOverloaded()) { //Addition: we don't overload for a shorter duration if already overloading
            checkedForOverload = true;
            if (Math.random() < OVERLOAD_CHANCE) {
                ship.getFluxTracker().beginOverloadWithTotalBaseDuration(OVERLOAD_DURATION);
                break;
            } else {
                //We allow it to run multiple times if the flux we have is multiples higher than the threshold
                lowestFlux += threshold;
            }
        }
        if (checkedForOverload) {
            //Once we've overloaded or succeeded in not overloading, we clear all the flux data
            fluxData.clear();
        }
        Global.getCombatEngine().getCustomData().put(this.getClass().getName() + "_FluxData_" + ship.getId(), fluxData);
    }

    //Internal classes for managing the flux data. Mostly for type-safety reasons
    private static class FluxDataQueue extends LinkedList<FluxDataPoint> implements Queue<FluxDataPoint> {}
    private static class FluxDataPoint {
        public float lifetime = FLUX_REMEMBER_TIME;
        public float flux;

        private FluxDataPoint (float flux) {
            this.flux = flux;
        }
    }
}
