package data.hullmods;

import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;

public class loa_secondaryfield extends BaseHullMod {

	public static final float ENERGY_RANGE_BONUS = 200f;
	
	public void applyEffectsBeforeShipCreation(HullSize hullSize, MutableShipStatsAPI stats, String id) {
		stats.getEnergyWeaponRangeBonus().modifyFlat(id, ENERGY_RANGE_BONUS);
                stats.getBeamWeaponRangeBonus().modifyFlat(id, (ENERGY_RANGE_BONUS * -1f));
                stats.getNonBeamPDWeaponRangeBonus().modifyFlat(id, (ENERGY_RANGE_BONUS * -1f));
                
		
                
	}
	
	public String getDescriptionParam(int index, HullSize hullSize) {
		if (index == 0) return "" + (int) ENERGY_RANGE_BONUS;
		return null;
	}


}
