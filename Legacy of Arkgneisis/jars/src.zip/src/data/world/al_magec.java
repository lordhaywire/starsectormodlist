package data.world;

import com.fs.starfarer.api.campaign.SectorAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.impl.campaign.ids.Conditions;
import com.fs.starfarer.api.impl.campaign.ids.Industries;
import com.fs.starfarer.api.impl.campaign.ids.Submarkets;
import java.util.ArrayList;
import java.util.Arrays;

public class al_magec
{
    public void generate(SectorAPI sector)
    {
//        StarSystemAPI system = sector.getStarSystem("Magec");
//
//        SectorEntityToken al_merlin = system.addCustomEntity("al_merlin", "Merlin Outpost", "al_arsbase_3", "al_ars");
//        al_merlin.setCircularOrbit(system.getEntityById("Magec"), 270, 13000, 800);
//        al_merlin.setCustomDescriptionId("al_arsbase_3_merlin");
//        al_merlin.setInteractionImage("illustrations", "cargo_loading");
//
//        MarketAPI al_merlin_market = al_campaign_hax.addMarketplace("al_ars", al_merlin,
//                null,
//                "Merlin Outpost", 3,
//
//                new ArrayList<>(
//                        Arrays.asList(Conditions.POPULATION_3,Conditions.FREE_PORT, Conditions.FRONTIER, Conditions.OUTPOST, 
//                                Industries.POPULATION, Industries.SPACEPORT, Industries.WAYSTATION, 
//                                Industries.ORBITALSTATION, Industries.FUELPROD, Industries.HEAVYBATTERIES, Industries.PATROLHQ)),
//                new ArrayList<>(Arrays.asList(Submarkets.GENERIC_MILITARY, Submarkets.SUBMARKET_BLACK,
//                        Submarkets.SUBMARKET_OPEN, Submarkets.SUBMARKET_STORAGE)),
//                0.3f);
    }
}
