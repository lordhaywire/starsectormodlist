package data.world;

import com.fs.starfarer.api.campaign.FactionAPI;
import com.fs.starfarer.api.campaign.RepLevel;
import com.fs.starfarer.api.campaign.SectorAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.impl.campaign.ids.Conditions;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.ids.Industries;
import com.fs.starfarer.api.impl.campaign.ids.Submarkets;
import java.util.ArrayList;
import java.util.Arrays;

public class al_zagan
{
    public void generate(SectorAPI sector)
    {
        initFactionRelationships(sector);
    }

    // This is the location of the main starbase of the Society so we are calling rep levels here
    private static void initFactionRelationships(SectorAPI sector)
    {
        FactionAPI anarakisrepsociety = sector.getFaction("al_ars");

        // Vanilla factions that should be manually set
        anarakisrepsociety.setRelationship(Factions.INDEPENDENT, RepLevel.NEUTRAL); // Not exactly a polity in and of itself, conduct business on a per-case basis.
        anarakisrepsociety.setRelationship(Factions.PIRATES, RepLevel.SUSPICIOUS); // Undiciplined drifters, a lot like us really, but without clarity of purpose.
        anarakisrepsociety.setRelationship(Factions.PERSEAN, RepLevel.FAVORABLE); // Practically friends, if there ever was such a thing for the likes of us.
        anarakisrepsociety.setRelationship(Factions.TRITACHYON, RepLevel.SUSPICIOUS); // All that good will from the AI war went out the window when church started paying us to hunt down the rest of their toys...
        anarakisrepsociety.setRelationship(Factions.HEGEMONY, RepLevel.HOSTILE); // The Arkarans gave us freedom, the Domain will pay for what it tried to do to them...

        // These should be the same relationship
        anarakisrepsociety.setRelationship(Factions.LIONS_GUARD, RepLevel.NEUTRAL); // Elite hardline jingoist dictators...yaaaaaaay... just make sure they pay up.
        anarakisrepsociety.setRelationship(Factions.DIKTAT, RepLevel.NEUTRAL); // Hardline jingoist dictators...yaaaaaaay... just make sure they pay up.

        anarakisrepsociety.setRelationship(Factions.LUDDIC_CHURCH, RepLevel.SUSPICIOUS); // Business as usual, the odd monastery raid gets overlooked for help with the Remnants... and other troublemakers.
        anarakisrepsociety.setRelationship(Factions.LUDDIC_PATH, RepLevel.HOSTILE); // Fucking psychos, do not trust.
        anarakisrepsociety.setRelationship(Factions.REMNANTS, RepLevel.HOSTILE); // Don't change me

        // Mod factions
        anarakisrepsociety.setRelationship("interstellarimperium", RepLevel.FAVORABLE); //Liable repeat customers due to ongoing hostilities with the Hegemony.
        anarakisrepsociety.setRelationship("blackrock_driveyards", RepLevel.SUSPICIOUS); //Relatively reclusive corperate microstate, good money as clients or targets.
        anarakisrepsociety.setRelationship("tiandong", RepLevel.SUSPICIOUS); //Not so reclusive megacorperation, business as usual except potential conflict of interest in export shipbuilding.
        anarakisrepsociety.setRelationship("dassault_mikoyan", RepLevel.SUSPICIOUS); // Same as Tiandong, except sunglasses recommended when viewed on tactical overlays.
        anarakisrepsociety.setRelationship("blade_breakers", RepLevel.HOSTILE); // What?
        anarakisrepsociety.setRelationship("diableavionics", RepLevel.NEUTRAL); // They seem fairly ornery, but some of our pirate contacts scored us some smooth deals.
        anarakisrepsociety.setRelationship("fob", RepLevel.FAVORABLE); //I don't actually remember who these people are.
        anarakisrepsociety.setRelationship("metelson", RepLevel.SUSPICIOUS); //Their fleets make good raid targets, and also pay well for a good escort.
        anarakisrepsociety.setRelationship("ORA", RepLevel.SUSPICIOUS); //Goodie two shoes don't like us very much, but when they want to keep their hands clean...
        anarakisrepsociety.setRelationship("SCY", RepLevel.NEUTRAL); //Used to be kind of like us, but full of nerds. Now they're on the straight and narrow or...something.
        anarakisrepsociety.setRelationship("shadow_industry", RepLevel.FAVORABLE); //My pocketbook loves people who hate the Hegemony. Command says they were around in the old days...
        anarakisrepsociety.setRelationship("sylphon", RepLevel.NEUTRAL); //A bunch of hermits from what we can tell, so far inoffensive enough that nobody has put money on their heads.
        anarakisrepsociety.setRelationship("templars", RepLevel.HOSTILE); //I'm scared boss...
        anarakisrepsociety.setRelationship("cabal", RepLevel.SUSPICIOUS); //Like the pirates, but flamboyant and pretentious. Hold your tongue and they pay well enough.
        anarakisrepsociety.setRelationship("vic", RepLevel.SUSPICIOUS); //Domain supporting private organization, not to be trusted.
        
//        StarSystemAPI system = sector.getStarSystem("Zagan");
//        
//        SectorEntityToken al_parasol = system.addCustomEntity("al_parasol", "Parasol Station", "al_arsbase_6", "al_ars");
//        al_parasol.setCircularOrbit(system.getEntityById("Zagan"), 0, 3500, 225);
//        al_parasol.setCustomDescriptionId("al_arsbase_6_parasol");
//        al_parasol.setInteractionImage("illustrations", "hound_hangar");
//
//        MarketAPI al_parasol_market = al_campaign_hax.addMarketplace("al_ars", al_parasol,
//                null,
//                "Parasol Station", 6,
//
//                new ArrayList<>(
//                        Arrays.asList(Conditions.POPULATION_6, Conditions.OUTPOST, Conditions.FREE_PORT, Conditions.FRONTIER, Conditions.ORE_ABUNDANT, Conditions.RARE_ORE_MODERATE, 
//                                Industries.POPULATION, Industries.MEGAPORT, Industries.ORBITALWORKS, Industries.WAYSTATION, Industries.FUELPROD,
//                                Industries.MINING, Industries.HEAVYBATTERIES, Industries.STARFORTRESS, Industries.REFINING, Industries.HIGHCOMMAND)),
//                                
//                new ArrayList<>(Arrays.asList(Submarkets.GENERIC_MILITARY, Submarkets.SUBMARKET_BLACK,
//                        Submarkets.SUBMARKET_OPEN, Submarkets.SUBMARKET_STORAGE)),
//                0.3f);
    }
}
