package data.world;

import com.fs.starfarer.api.campaign.SectorAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.impl.campaign.ids.Conditions;
import com.fs.starfarer.api.impl.campaign.ids.Industries;
import com.fs.starfarer.api.impl.campaign.ids.Submarkets;
import java.util.ArrayList;
import java.util.Arrays;

public class al_mayasura
{
    public void generate(SectorAPI sector)
    {
//        StarSystemAPI system = sector.getStarSystem("Mayasura");
//
//        SectorEntityToken al_genocide = system.addCustomEntity("al_genocide", "Genocide Outpost", "al_arsbase_3", "al_ars");
//        al_genocide.setCircularOrbit(system.getEntityById("Mayasura"), 90, 7450, 400);
//        al_genocide.setCustomDescriptionId("al_arsbase_3_genocide");
//        al_genocide.setInteractionImage("illustrations", "abandoned_station2");
//
//        MarketAPI al_genocide_market = al_campaign_hax.addMarketplace("al_ars", al_genocide,
//                null,
//                "Genocide Outpost", 3,
//
//                new ArrayList<>(
//                        Arrays.asList(Conditions.POPULATION_3, Conditions.FREE_PORT, Conditions.FRONTIER, Conditions.OUTPOST, 
//                                Industries.POPULATION, Industries.SPACEPORT, Industries.ORBITALWORKS, 
//                                Industries.WAYSTATION, Industries.ORBITALSTATION)),
//                new ArrayList<>(
//                        Arrays.asList(Submarkets.SUBMARKET_BLACK,
//                        Submarkets.SUBMARKET_OPEN, Submarkets.SUBMARKET_STORAGE)),
//                0.3f);
    }
}
