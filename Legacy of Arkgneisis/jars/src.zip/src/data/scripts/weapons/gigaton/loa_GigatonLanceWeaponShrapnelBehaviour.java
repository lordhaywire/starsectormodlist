package data.scripts.weapons.gigaton;

import com.fs.starfarer.api.combat.*;
import com.fs.starfarer.api.input.InputEventAPI;
import com.fs.starfarer.api.util.Misc;
import org.lazywizard.lazylib.CollisionUtils;
import org.lazywizard.lazylib.MathUtils;
import org.lazywizard.lazylib.VectorUtils;
import org.lwjgl.util.vector.Vector2f;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Handles the shrapnel-related behaviour of the Gigaton Lance
 * @author Nicke535
 */
public class loa_GigatonLanceWeaponShrapnelBehaviour implements EveryFrameWeaponEffectPlugin {

    //The dispersal cone angle for shrapnel
    private static final float SPREAD_ANGLE = 20f;

    //Dispersal "formula" for the shrapnel. Higher values means more shrapnel condensed near the center. Sub-one values
    // mean more shrapnel appears near the "edge" of the cone of fire.
    //      EXAMPLES:   2f means 50% of shrapnel appears in the central 25% of the cone
    //                  3f means 50% of shrapnel appears in the central 12.5% of the cone
    private static final float SPREAD_FORMULA = 2.5f;

    //Velocity variation for projectiles: 0.3f means up to 30% less or more speed for a given projectile
    private static final float VELOCITY_VARIATION = 0.5f;

    //Maximum and minimum amount of shrapnel to spawn each time the gun fires
    private static final int SHRAPNEL_MIN_COUNT = 15;
    private static final int SHRAPNEL_MAX_COUNT = 15;

    //Offset for the barrel's position, where the shrapnel will be fired from
    private static final Vector2f FIRE_POINT_OFFSET = new Vector2f(90f, 0f);

    //ID list for the weapons to fire shrapnel from (selects one at random)
    private static final List<String> WEAPONS = new ArrayList<>();
    static {
        WEAPONS.add("loa_gigaton_shrapnel");
    }

    /* --- Particle stats --- */
    private static final float PARTICLES_PER_SECOND = 15f;
    private static final float PARTICLE_MIN_SPAWN_AREA = 0f; //Random radius around the fire point
    private static final float PARTICLE_MAX_SPAWN_AREA = 0f;
    private static final float PARTICLE_MIN_SPREADOUT_VELOCITY = 0f; //Velocity the particles "spread out" with
    private static final float PARTICLE_MAX_SPREADOUT_VELOCITY = 5f;
    private static final float PARTICLE_MIN_SIZE = 10f;
    private static final float PARTICLE_MAX_SIZE = 30f;
    private static final float PARTICLE_MIN_DURATION = 0.5f;
    private static final float PARTICLE_MAX_DURATION = 1.5f;
    private static final Color PARTICLE_COLOR_ONE = new Color(100, 100, 100); //Color is randomized between these two colors
    private static final Color PARTICLE_COLOR_TWO = new Color(185, 185, 185);
    private static final float PARTICLE_COOLING_TIME_MIN = 5f; //Time for an individual particle to "cool off" and stop emitting particles
    private static final float PARTICLE_COOLING_TIME_MAX = 10f; //randomized between min/max: the emitting slows down linearly over the entire duration
    private static final float SCREENSPACE_CULL_DISTANCE = 150f; //Culling distance to stop spawning particles. Set too low and you get minor artifacts when moving
                                                                 //the camera, too high and it eats memory/potential particle spawns


    //Tracks if we've fired yet or not
    private boolean hasFired = false;


    @Override
    public void advance(float amount, CombatEngineAPI engine, WeaponAPI weapon) {
        //Check if we're ready to fire: if we are, play a loop and reset hasFired
        if (weapon.getCooldownRemaining() <= 0f && !weapon.isFiring()) {
            hasFired = false;
        }

        //If we're currently firing, but haven't triggered our distortion yet, trigger the distortion!
        if (!hasFired && weapon.getChargeLevel() >= 1f) {
            hasFired = true;

            Vector2f barrelPos = Vector2f.add(weapon.getLocation(), VectorUtils.rotate(new Vector2f(FIRE_POINT_OFFSET),
                    weapon.getCurrAngle()), new Vector2f(0f, 0f));

            int shrapnelThisShot = MathUtils.getRandomNumberInRange(SHRAPNEL_MIN_COUNT, SHRAPNEL_MAX_COUNT);
            for (int i = 0; i < shrapnelThisShot; i++) {
                String shotThisTime = WEAPONS.get(MathUtils.getRandomNumberInRange(0, WEAPONS.size()-1));
                float angleOffset = (float)Math.pow(MathUtils.getRandomNumberInRange(0f, 1f), SPREAD_FORMULA) * SPREAD_ANGLE/2f;
                if (Math.random() < 0.5f) {
                    angleOffset *= -1f;
                }
                DamagingProjectileAPI proj = (DamagingProjectileAPI) engine.spawnProjectile(weapon.getShip(), null, shotThisTime, barrelPos,
                        weapon.getCurrAngle() + angleOffset, new Vector2f(0f, 0f));
                float velocityScale = 1f + MathUtils.getRandomNumberInRange(-1f, 1f)*VELOCITY_VARIATION;
                proj.getVelocity().x *= velocityScale;
                proj.getVelocity().y *= velocityScale;
                engine.addPlugin(new ParticleTracker(proj, engine));
            }
        }
    }

    private class ParticleTracker extends BaseEveryFrameCombatPlugin {
        DamagingProjectileAPI proj;
        CombatEngineAPI engine;
        float trackerLifetime;
        float coolingTime;

        ParticleTracker(DamagingProjectileAPI proj, CombatEngineAPI engine) {
            this.proj = proj;
            this.engine = engine;
            this.trackerLifetime = 0f;
            this.coolingTime = MathUtils.getRandomNumberInRange(PARTICLE_COOLING_TIME_MIN, PARTICLE_COOLING_TIME_MAX);
        }

        @Override
        public void advance(float amount, List<InputEventAPI> events) {
            if (engine.isPaused()) {
                return;
            }

            //We "cool down" and spawn less particles over time
            trackerLifetime += amount;

            //For already-collided projectiles, fading projectiles or those who have cooled down completely: remove our plugin
            if (proj.didDamage() || proj.isFading() || trackerLifetime >= coolingTime) {
                engine.removePlugin(this);
                return;
            }

            //Don't generate particles if we're too far offscreen
            if (!engine.getViewport().isNearViewport(proj.getLocation(), SCREENSPACE_CULL_DISTANCE)) {
                return;
            }

            //Loops depending on how many particles are spawned per second
            float counter = PARTICLES_PER_SECOND * amount * (1f - (trackerLifetime/coolingTime));
            while (Math.random() < counter) {
                counter--;

                //First, get a "fake" location, so we emulate spawning inbetweeen frames
                Vector2f fakeCenter = MathUtils.getRandomPointOnLine(proj.getLocation(), new Vector2f(proj.getLocation().x + (proj.getVelocity().x*amount), proj.getLocation().y + (proj.getVelocity().y*amount)));

                //Then, determine spawn point and velocity
                Vector2f spawnPoint = MathUtils.getPointOnCircumference(fakeCenter,
                        MathUtils.getRandomNumberInRange(PARTICLE_MIN_SPAWN_AREA, PARTICLE_MAX_SPAWN_AREA),
                        MathUtils.getRandomNumberInRange(0f, 360f));
                Vector2f velocity = MathUtils.getPointOnCircumference(new Vector2f(0f, 0f),
                        MathUtils.getRandomNumberInRange(PARTICLE_MIN_SPREADOUT_VELOCITY, PARTICLE_MAX_SPREADOUT_VELOCITY),
                        MathUtils.getRandomNumberInRange(0f, 360f));

                //And finally spawn the particles
                engine.addSmokeParticle(spawnPoint, velocity, MathUtils.getRandomNumberInRange(PARTICLE_MIN_SIZE, PARTICLE_MAX_SIZE),
                        1f, MathUtils.getRandomNumberInRange(PARTICLE_MIN_DURATION, PARTICLE_MAX_DURATION),
                        Misc.interpolateColor(PARTICLE_COLOR_ONE, PARTICLE_COLOR_TWO, MathUtils.getRandomNumberInRange(0f, 1f)));
            }
        }
    }
}
