package data.scripts.weapons.gigaton;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.SoundAPI;
import com.fs.starfarer.api.combat.BaseEveryFrameCombatPlugin;
import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.EveryFrameWeaponEffectPlugin;
import com.fs.starfarer.api.combat.WeaponAPI;
import com.fs.starfarer.api.input.InputEventAPI;
import com.fs.starfarer.api.util.Misc;
import org.dark.shaders.distortion.DistortionShader;
import org.dark.shaders.distortion.RippleDistortion;
import org.lazywizard.lazylib.MathUtils;
import org.lazywizard.lazylib.VectorUtils;
import org.lwjgl.util.vector.Vector2f;

import java.util.List;

/**
 * Handles extra audivisual flair for the Gigaton Lance I couldn't fit anywhere else, including
 * a distortion shockwave and sound effects
 *
 * @author Nicke535
 */
public class loa_GigatonLanceExtraFlairEffects implements EveryFrameWeaponEffectPlugin {
    //ADDITION 10/7 2020
    //Sound effects that plays when the weapon fires (oneshots: see the beam behaviour for loop sound)
    //  Using the FIRE_SOUND_RANGE and FIRE_SOUND_RANGE_CROSSOVER settings below, you can set how far away the player's
    //  sound listener has to be from the weapon for the "_FAR" sound to play, and can even give a neat crossfade
    //  between them so a player just out of the main range still hears it partially mixed with the "_FAR" variant
    //     --PS: oh, and don't use the vanilla fire sound since that'll definitely not match up with the weapon sounds
    //           the script plays accurately
    private static final String FIRE_SOUND = "loa_gigaton_fire_close";
    private static final String FIRE_SOUND_FAR = "loa_gigaton_fire_far";

    //Determines how far away the player's sound listener has to be to start hearing the "_FAR" sound
    private static final float FIRE_SOUND_RANGE = 1500f;

    //Determines for how many SU the "_FAR" and normal sounds are blended
    private static final float FIRE_SOUND_RANGE_CROSSOVER = 500f;

    // -- EXAMPLE :
    //      Setting FIRE_SOUND_RANGE to 1500 and FIRE_SOUND_RANGE_CROSSOVER to 1000 means that a player will hear, depending
    //      on distance from weapon to sound listener:
    //          <1500 SU: the main fire sound at 100% volume
    //          2000 SU: the main fire sound at 50% volume and the far fire sound at 50% volume
    //          2250 SU: the main fire sound at 25% volume and the far fire sound at 75% volume
    //          >2500 SU: the far fire sound at 100% volume
    //
    // You can also just set the crossover to 0 to have a hard cut
    //
    //      You can *also* set this variable to true and just use my older more boring implementation which checks
    //      the screen's position and nothing else (it's not really faster, just simpler to config since it ignores the
    //      range settings altogether). No promises this implementation is as bug-free though, it's pretty barebones
    private static final boolean LEGACY_SOUND_MODE = false;


    //Looping sound effect while the lance is ready to fire
    private static final String LOOP_SOUND = "loa_gigaton_ready";

    //Minimum volume for the loop
    private static final float LOOP_MIN_VOLUME = 0.2f;

    //Range at which the loop sound plays at minimum volume
    private static final float LOOP_MIN_VOLUME_RANGE = 3000f;

    //Various distortion stats (all except OFFSET are pretty clear: OFFSET is where the muzzle is located compared to
    // the sprite's center)
    private static final Vector2f DISTORTION_OFFSET = new Vector2f(90f, 0f);
    private static final float DISTORTION_DURATION = 1f;
    private static final float DISTORTION_INTENSITY = 100f;
    private static final float DISTORTION_MIN_SIZE = 0f;
    private static final float DISTORTION_MAX_SIZE = 750f;


    //Keeps track of if we're fired yet or not
    private boolean hasFired = false;

    @Override
    public void advance(float amount, CombatEngineAPI engine, WeaponAPI weapon) {
        //Don't do anything in refit
        if (engine == null || !engine.isEntityInPlay(weapon.getShip())) {
            return;
        }

        //Check if we're ready to fire: if we are, play a loop and reset hasFired
        //ADDITION 15/7 2020 - Also show a tooltip for the player, depending on if they're on the enemy or ally side
        if (weapon.getCooldownRemaining() <= 0f && !weapon.isFiring()) {
            hasFired = false;
            float distanceToSoundListener = MathUtils.getDistance(weapon.getLocation(), Global.getSoundPlayer().getListenerPos());
            float volumeFactor = MathUtils.clamp(LOOP_MIN_VOLUME + ((1f - LOOP_MIN_VOLUME) * (1f - (distanceToSoundListener/LOOP_MIN_VOLUME_RANGE))),LOOP_MIN_VOLUME, 1f);
            Global.getSoundPlayer().playLoop(LOOP_SOUND, weapon.getShip(), 1f, volumeFactor, Global.getSoundPlayer().getListenerPos(), Misc.ZERO);

            //Detect which side we're on compared to the player, and shows status display for them
            if (weapon.getShip().isAlly() || weapon.getShip().getOwner() == engine.getPlayerShip().getOwner()) {
                //Add friendly-side description here. Also set the correct icon here
                engine.maintainStatusForPlayerShip(this, "graphics/icons/missions/mission_marker2.png", "Alert",
                        "Allied strategic weapon: Armed", true);
            } else {
                //Add enemy-side description here. Also set the correct icon here
                engine.maintainStatusForPlayerShip(this, "graphics/icons/missions/mission_marker2.png", "Warning!",
                        "Hostile strategic weapon: Armed", true);

            }

            return;
        }

        //If we're currently firing, but haven't triggered our distortion yet, trigger the distortion!
        if (!hasFired && weapon.getChargeLevel() >= 1f) {
            hasFired = true;

            Vector2f barrelPos = Vector2f.add(weapon.getLocation(), VectorUtils.rotate(new Vector2f(DISTORTION_OFFSET),
                    weapon.getCurrAngle()), new Vector2f(0f, 0f));

            // Lets test the ripple instead of the wave
            //WaveDistortion distortion = new WaveDistortion(barrelPos, Misc.ZERO);
            RippleDistortion distortion = new RippleDistortion(barrelPos, Misc.ZERO);
            distortion.setAutoAnimateFrameRate(15 / DISTORTION_DURATION, 45);

            //Handles negative intensity
            float actualIntensity = DISTORTION_INTENSITY;
            if (actualIntensity < 0f) {
                actualIntensity *= -1f;
                distortion.flip(true);
            }
            distortion.setIntensity(actualIntensity);

            //Ensure the effect fades out properly
            distortion.setLifetime(DISTORTION_DURATION);
            distortion.fadeOutIntensity(DISTORTION_DURATION);

            //We want the size to work a bit wierdly, namely to fade in, but start at 25%. So we add that
            distortion.setSize(DISTORTION_MAX_SIZE - DISTORTION_MIN_SIZE);
            distortion.fadeInSize(DISTORTION_DURATION);
            distortion.setSize(DISTORTION_MIN_SIZE);

            //And finally ensure the distortion is tracked
            DistortionShader.addDistortion(distortion);

            //ADDITION 10/7 2020 - Also play a global fire sound
            if (LEGACY_SOUND_MODE) {
                if (engine.getViewport().isNearViewport(weapon.getLocation(), 0f)) {
                    Global.getSoundPlayer().playUISound(FIRE_SOUND, 1f, 1f);
                } else {
                    Global.getSoundPlayer().playUISound(FIRE_SOUND_FAR, 1f, 1f);
                }
            } else {
                engine.addPlugin(new CustomFireSound(weapon));
            }
        }
    }

    //Custom hacky class for a global sound that works decently I suppose
    private class CustomFireSound extends BaseEveryFrameCombatPlugin {
        SoundAPI sound;
        SoundAPI soundFar;
        WeaponAPI wep;

        float counter = 0f;

        CustomFireSound(WeaponAPI wep) {
            this.wep = wep;
            sound = Global.getSoundPlayer().playSound(FIRE_SOUND, 1f, 1f, Global.getSoundPlayer().getListenerPos(), Misc.ZERO);
            soundFar = Global.getSoundPlayer().playSound(FIRE_SOUND_FAR, 1f, 1f, Global.getSoundPlayer().getListenerPos(), Misc.ZERO);
        }

        @Override
        public void advance(float amount, List<InputEventAPI> events) {
            //Just for cleanup: if *really* long sounds clip, increase 20f to something higher
            counter += amount;
            if (counter > 20f) {
                sound.stop();
                soundFar.stop();
                Global.getCombatEngine().removePlugin(this);
                return;
            }

            //Calculates the mix between the sounds and adjusts location
            Vector2f listenPos = Global.getSoundPlayer().getListenerPos();
            float distanceToListener = MathUtils.getDistance(listenPos, wep.getLocation());
            float distanceFactor = (distanceToListener - FIRE_SOUND_RANGE) / FIRE_SOUND_RANGE_CROSSOVER;
            distanceFactor = MathUtils.clamp(distanceFactor, 0f, 1f);
            sound.setVolume(1f - distanceFactor);
            sound.setLocation(listenPos.x, listenPos.y);
            soundFar.setVolume(distanceFactor);
            soundFar.setLocation(listenPos.x, listenPos.y);
        }
    }
}
