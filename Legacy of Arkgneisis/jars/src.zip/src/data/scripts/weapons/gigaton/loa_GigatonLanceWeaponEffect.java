package data.scripts.weapons.gigaton;

import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.EveryFrameWeaponEffectPlugin;
import com.fs.starfarer.api.combat.WeaponAPI;
import data.scripts.plugins.MagicTrailPlugin;
import data.scripts.util.MagicRender;
import data.scripts.weapons.loa_poor_mans_beam_muzzleflash;

/**
 * A "grouping" script allowing the Gigaton Lance to have several weapon effect scripts applied to it at once, without a
 * massive file to configure
 * @author Nicke535
 */
public class loa_GigatonLanceWeaponEffect implements EveryFrameWeaponEffectPlugin {

    //Keeps an instance of our beam behaviour script so that we can call it
    private loa_GigatonLanceWeaponBeamBehaviour beamBehaviourScript = null;

    //Keeps an instance of our beam behaviour script so that we can call it
    private loa_GigatonLanceWeaponShrapnelBehaviour shrapnelBehaviourScript = null;

    //Keeps an instance of our muzzle flash script so that we can call it
    private loa_GigatonLanceWeaponMuzzleFlash muzzleflashScript = null;

    //Keeps an instance of our flair script so that we can call it
    private loa_GigatonLanceExtraFlairEffects flairScript = null;

    @Override
    public void advance(float amount, CombatEngineAPI engine, WeaponAPI weapon) {
        //Don't run if we are paused, or our if weapon is null
        if (engine.isPaused() || weapon == null) {
            return;
        }

        //Run our beam behaviour script!
        if (beamBehaviourScript == null) {
            beamBehaviourScript = new loa_GigatonLanceWeaponBeamBehaviour();
        }
        beamBehaviourScript.advance(amount, engine, weapon);

        //And our shrapnel behaviour script!
        if (shrapnelBehaviourScript == null) {
            shrapnelBehaviourScript = new loa_GigatonLanceWeaponShrapnelBehaviour();
        }
        shrapnelBehaviourScript.advance(amount, engine, weapon);

        //And all other flair!
        if (flairScript == null) {
            flairScript = new loa_GigatonLanceExtraFlairEffects();
        }
        flairScript.advance(amount, engine, weapon);

        //And finally, our muzzle flash!
        if (muzzleflashScript == null) {
            muzzleflashScript = new loa_GigatonLanceWeaponMuzzleFlash();
        }
        muzzleflashScript.advance(amount, engine, weapon);
    }
}
