package data.scripts.weapons.gigaton;

import com.fs.starfarer.api.combat.*;

/**
 * Deals a bajillion DPS to asteroids, so they don't get in the way
 * @author Nicke535
 */
public class loa_GigatonLanceAsteroidMelterEffect implements BeamEffectPlugin {

    @Override
    public void advance(float amount, CombatEngineAPI engine, BeamAPI beam) {
        // Don't bother with any unecessary checks
        if (beam.getWeapon().getShip() == null) {
            return;
        }

        //Only run if we have a damage target, and it's an asteroid
        if (beam.didDamageThisFrame() && beam.getDamageTarget() instanceof CombatAsteroidAPI) {
            //BOOM.
            ShipAPI ship = beam.getWeapon().getShip();
            engine.applyDamage(beam.getDamageTarget(), beam.getDamageTarget().getLocation(),
                    9000000000000000f, DamageType.HIGH_EXPLOSIVE, 0f, true,
                    false, ship, false);

        }
    }
}