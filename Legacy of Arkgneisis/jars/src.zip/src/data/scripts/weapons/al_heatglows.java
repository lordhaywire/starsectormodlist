package data.scripts.weapons;

import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.EveryFrameWeaponEffectPlugin;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.WeaponAPI;

public class al_heatglows implements EveryFrameWeaponEffectPlugin
{
    private float factor = 0f;

    @Override
    public void advance(float amount, CombatEngineAPI engine, WeaponAPI weapon)
    {
        if (engine.isPaused())
        {
            return;
        }

        ShipAPI ship = weapon.getShip();

        if (!ship.isAlive())
        {
            weapon.getAnimation().setAlphaMult(0f);
            weapon.getAnimation().setFrame(0);
            return;
        }

        float activateTime;
        float deactivateTime;
        float primaryFrequency;
        float secondaryFrequency;
        float primaryAmplitude; // Peak-to-peak
        float secondaryAmplitude; // Peak-to-peak
        float alpha;
        boolean on;
        switch (weapon.getId())
        {
            case "al_victoria_glow":
                activateTime = 3.0f;        // Adjust these parameters for visual feel
                deactivateTime = 5.0f;
                primaryFrequency = 0.25f;
                secondaryFrequency = 0.5f;
                primaryAmplitude = 0.15f;
                secondaryAmplitude = 0.3f;
                alpha = 1f;
                on = ship.isAlive() && !ship.getFluxTracker().isOverloaded() && ship.getSystem().isOn();
                break;
            case "al_sherman_glow":
                activateTime = 0.5f;        // Adjust these parameters for visual feel
                deactivateTime = 5.0f;
                primaryFrequency = 0.25f;
                secondaryFrequency = 0.5f;
                primaryAmplitude = 0.15f;
                secondaryAmplitude = 0.3f;
                alpha = 1f;
                on = ship.isAlive() && !ship.getFluxTracker().isOverloaded() && ship.getSystem().isOn();
                break;
            case "al_king_glow":
                activateTime = 0.5f;        // Adjust these parameters for visual feel
                deactivateTime = 5.0f;
                primaryFrequency = 0.25f;
                secondaryFrequency = 0.5f;
                primaryAmplitude = 0.15f;
                secondaryAmplitude = 0.3f;
                alpha = 1f;
                on = ship.isAlive() && !ship.getFluxTracker().isOverloaded() && ship.getSystem().isOn();
                break;
            case "loa_edith_glow":
                activateTime = 0.5f;        // Adjust these parameters for visual feel
                deactivateTime = 5.0f;
                primaryFrequency = 0.25f;
                secondaryFrequency = 0.5f;
                primaryAmplitude = 0.15f;
                secondaryAmplitude = 0.3f;
                alpha = 1f;
                on = ship.isAlive() && !ship.getFluxTracker().isOverloaded() && ship.getSystem().isOn();
                break;
            case "al_thatcher_glow":
                activateTime = 0.5f;        // Adjust these parameters for visual feel
                deactivateTime = 5.0f;
                primaryFrequency = 0.25f;
                secondaryFrequency = 0.5f;
                primaryAmplitude = 0.15f;
                secondaryAmplitude = 0.3f;
                alpha = 1f;
                on = ship.isAlive() && !ship.getFluxTracker().isOverloaded() && ship.getSystem().isOn();
                break;
            case "al_reid_glow":
                activateTime = 1.0f;        // Adjust these parameters for visual feel
                deactivateTime = 1.0f;
                primaryFrequency = 0.25f;
                secondaryFrequency = 0.5f;
                primaryAmplitude = 0.15f;
                secondaryAmplitude = 0.3f;
                alpha = 1f;
                on = ship.isAlive() && !ship.getFluxTracker().isOverloaded() && ship.getSystem().isOn();
                break;
            case "al_macnamara_glow":
                activateTime = 1.0f;        // Adjust these parameters for visual feel
                deactivateTime = 1.0f;
                primaryFrequency = 0.25f;
                secondaryFrequency = 0.5f;
                primaryAmplitude = 0.15f;
                secondaryAmplitude = 0.3f;
                alpha = 1f;
                on = ship.isAlive() && !ship.getFluxTracker().isOverloaded() && ship.getSystem().isOn();
                break;
            case "loa_deco_gaillard_glow":
                activateTime = 0.5f;        // Adjust these parameters for visual feel
                deactivateTime = 5.0f;
                primaryFrequency = 0.25f;
                secondaryFrequency = 0.5f;
                primaryAmplitude = 0.15f;
                secondaryAmplitude = 0.3f;
                alpha = 1f;
                on = ship.isAlive() && !ship.getFluxTracker().isOverloaded() && ship.getSystem().isOn();
                break;
            default:
                return;
        }

        if (factor <= 0f && !on)
        {
            weapon.getAnimation().setFrame(0);
            return;
        }

        float wave = primaryAmplitude * (float) Math.cos(engine.getTotalElapsedTime(false) * primaryFrequency * Math.PI);
        wave += secondaryAmplitude * (float) Math.cos(engine.getTotalElapsedTime(false) * secondaryFrequency * Math.PI);
        factor = Math.max(Math.min((factor + amount / (on ? activateTime : -deactivateTime)), 1f), 0f);
        float finalpha = Math.max(Math.min(alpha * (1f - (primaryAmplitude + secondaryAmplitude - wave) * 0.5f) * factor, 1f), 0f);

        weapon.getAnimation().setAlphaMult(finalpha);
        weapon.getSprite().setAdditiveBlend();
        weapon.getAnimation().setFrame(1);
    }
}