package data.scripts.weapons;

import java.awt.Color;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.listeners.ApplyDamageResultAPI;
import com.fs.starfarer.api.impl.campaign.ids.Stats;
import com.fs.starfarer.api.util.Misc;
import org.lwjgl.util.vector.Vector2f;

import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.CombatEntityAPI;
import com.fs.starfarer.api.combat.DamageType;
import com.fs.starfarer.api.combat.DamagingProjectileAPI;
import com.fs.starfarer.api.combat.OnHitEffectPlugin;
import com.fs.starfarer.api.combat.ShipAPI;

/**
 * It's just a better ion cannon onhit, really
 */
public class loa_pike_onhit implements OnHitEffectPlugin {

	private static final float ARC_CHANCE = 0.25f;
	private static final float MAX_SHIELD_PIERCE_CHANCE = 1f; //Scales linearly with shield flux, after hitting HIGH_FLUX_THRESHOLD
	private static final float HIGH_FLUX_THRESHOLD = 0.5f;

	private static final String SOUND_ID = "loa_pike_impact";


	@Override
	public void onHit(DamagingProjectileAPI projectile, CombatEntityAPI target, Vector2f point, boolean shieldHit,
					  ApplyDamageResultAPI damageResult, CombatEngineAPI engine) {
		Global.getSoundPlayer().playSound(SOUND_ID, 1f, 1f, point, Misc.ZERO);

		float triggerChance = ARC_CHANCE;

		//On shield hits, we have a chance to pierce depending on flux
		if (shieldHit && target instanceof ShipAPI) {
			float hardFluxLevel = ((ShipAPI) target).getFluxTracker().getHardFlux() / ((ShipAPI) target).getFluxTracker().getMaxFlux();
			float pierceChance = 0f;

			if (hardFluxLevel > HIGH_FLUX_THRESHOLD) {
				float fluxFactor = (hardFluxLevel - HIGH_FLUX_THRESHOLD) * (1f/(1f-HIGH_FLUX_THRESHOLD));
				pierceChance = fluxFactor * MAX_SHIELD_PIERCE_CHANCE;
			}

			if (projectile.getSource() != null) {
				pierceChance *= projectile.getSource().getMutableStats().getDynamic().getValue(Stats.SHIELD_PIERCED_MULT);
			}

			triggerChance *= pierceChance;
		}

		if ((float) Math.random() < triggerChance) {
			float emp = projectile.getEmpAmount();
			float dam = projectile.getDamageAmount();
			
			engine.spawnEmpArcPierceShields(projectile.getSource(), point, target, target,
							   DamageType.ENERGY, 
							   dam,
							   emp, // emp 
							   100000f, // max range 
							   "tachyon_lance_emp_impact",
							   20f, // thickness
							   new Color(25,100,155,255),
							   new Color(255,255,255,255)
							   );
		}
	}
}
