package data.scripts.weapons;

import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.EveryFrameWeaponEffectPlugin;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.WeaponAPI;
import org.lazywizard.lazylib.MathUtils;
import org.lazywizard.lazylib.VectorUtils;
import org.lwjgl.util.vector.Vector2f;

import java.awt.*;
import java.util.HashMap;
import java.util.Map;

/**
 * Gives a beam weapon an inaccurate firing solution past the first shot. Also calls loa_poor_mans_beam_muzzleflash so
 * that we can have custom muzzle flashes together with this effect without a configuration/code file 400 rows long.
 * @author Nicke535
 */
public class loa_poor_mans_beam_weaponeffect implements EveryFrameWeaponEffectPlugin {

    /**
     * How inaccurate the beam is after the first shot. Measured in degrees to each side
     */
    private static final float INACCURACY_ANGLE = 5f;

    /**
     * How heavily inaccuracy is weighted towards being close to the center. 1f means the entire cone is equally likely, 2f means
     * most shots will stay close to the center of the inaccuracy cone, 0.5f means a lot more shots will go towards the edges
     */
    private static final float INACCURACY_WEIGHTING_FACTOR = 1.5f;

    /**
     * How long the weapon has to spend not firing to get back its accuracy
     */
    private static final float RETARGET_TIME = 5f;

    //Keeps an instance of our muzzle flash script so that we can call it
    private loa_poor_mans_beam_muzzleflash muzzleflashScript = null;

    //Instantiates variables we will use later
    private float counter = 5f;
    private boolean runOnce = true;

    @Override
    public void advance(float amount, CombatEngineAPI engine, WeaponAPI weapon) {
        //Don't run if we are paused, or our if weapon is null
        if (engine.isPaused() || weapon == null) {
            return;
        }

        //Also run our muzzleflash!
        if (muzzleflashScript == null) {
            muzzleflashScript = new loa_poor_mans_beam_muzzleflash();
        }
        muzzleflashScript.advance(amount, engine, weapon);

        //When we are firing, reset our variables so we know we have started firing again
        float chargeLevel = weapon.getChargeLevel();
        if (chargeLevel > 0) {
            runOnce = true;
            counter = 0f;
        }

        //Once we stop firing, switch our beams around to a new inaccuracy (once)
        if (chargeLevel <= 0f && runOnce) {
            runOnce = false;

            //Here's where the magic happens: find all angle offsets, and randomize them!
            for (int i = 0; i < weapon.getSpec().getHardpointAngleOffsets().size(); i++) {
                weapon.ensureClonedSpec();
                weapon.getSpec().getHardpointAngleOffsets().set(i, getMissAngle());
            }
            for (int i = 0; i < weapon.getSpec().getTurretAngleOffsets().size(); i++) {
                weapon.ensureClonedSpec();
                weapon.getSpec().getTurretAngleOffsets().set(i, getMissAngle());
            }
            for (int i = 0; i < weapon.getSpec().getHiddenAngleOffsets().size(); i++) {
                weapon.ensureClonedSpec();
                weapon.getSpec().getHiddenAngleOffsets().set(i, getMissAngle());
            }
        }

        //Also while we're not firing, tick down our retarget time, and give back our accuracy if we're done ticking
        if (chargeLevel <= 0f) {
            counter += amount;
            if (counter > RETARGET_TIME) {
                for (int i = 0; i < weapon.getSpec().getHardpointAngleOffsets().size(); i++) {
                    weapon.ensureClonedSpec();
                    weapon.getSpec().getHardpointAngleOffsets().set(i, 0f);
                }
                for (int i = 0; i < weapon.getSpec().getTurretAngleOffsets().size(); i++) {
                    weapon.ensureClonedSpec();
                    weapon.getSpec().getTurretAngleOffsets().set(i, 0f);
                }
                for (int i = 0; i < weapon.getSpec().getHiddenAngleOffsets().size(); i++) {
                    weapon.ensureClonedSpec();
                    weapon.getSpec().getHiddenAngleOffsets().set(i, 0f);
                }
            }
        }
    }

    //Utility function for getting a new inaccurate aiming point
    private float getMissAngle() {
        float missFactor = (float)Math.pow(MathUtils.getRandomNumberInRange(0f, 1f), INACCURACY_WEIGHTING_FACTOR);
        if (Math.random() < 0.5f) {
            missFactor *= -1f;
        }

        return missFactor * INACCURACY_ANGLE;
    }
}
