package data.scripts.weapons;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.*;
import data.scripts.plugins.loa_hyperspace_tracker;
import org.lazywizard.lazylib.MathUtils;
import org.lwjgl.util.vector.Vector2f;

import java.awt.*;
import org.dark.shaders.util.ShaderLib;

public class loa_hyperbeam_behavior implements BeamEffectPlugin {
    //Mechanical tweaks
    private static final float MIN_EXPLOSION_DELAY = 0.1f; //Minimum delay between spawning two hyperspace holes
    private static final float MAX_EXPLOSION_DELAY = 0.3f; //Maximum delay between spawning two hyperspace holes
    private static final float HYPERHOLE_EXPLOSION_DELAY = 0f; //How long it takes for a spawned hyperspace-hole to detonate
    private static final float DAMAGE_MULT = 1.25f; //Percentage of damage/second dealt once the hole detonates (1f = 100%)

    //Visual tweaks
    private static final float PRE_BEAM_WIDTH_MULT = 0.2f; //Multiplier for how wide the pre-beam is in relation to the actual beam
    private static final Color PARTICLE_COLOR = new Color(150, 0, 255, 255);
    private static final float PARTICLE_SIZE_MIN = 5f;
    private static final float PARTICLE_SIZE_MAX = 12f;
    private static final float PARTICLE_DURATION_MIN = 0.4f;
    private static final float PARTICLE_DURATION_MAX = 0.9f;
    private static final float PARTICLE_INERTIA_MULT = 0.5f; //This is how much the particles retain their spawning ship's velocity; 0f means no retained velocity, 1f means full retained velocity.
    private static final float PARTICLE_DRIFT = 50f; //This is how much the particles "move" in a random direction when spawned, at most; their actual speed is between 0 and this value (plus any inertia, see above)
    private static final float PARTICLE_DENSITY = 0.2f; //Measured in particles per SU^2 (area unit) and second; lower means less particles. This is multiplied by charge level, too
    private static final float PARTICLE_SPAWN_WIDTH_MULT = 0.05f; //Multiplier for how wide the particles are allowed to spawn from the beam center; at 1f, it's equal to beam width, at 0f they only spawn in the center. Note that true beam width is usually much bigger than the visual beam width

    //Script-used, don't touch
    private boolean runOnce = false;
    private float beamWidth = -1f;
    private float counter = 0f;

    @Override
    public void advance(float amount, CombatEngineAPI engine, BeamAPI beam) {
        // Don't bother with any unecessary checks
        if (beam.getWeapon().getShip() == null) {
            return;
        }

        WeaponAPI weapon = beam.getWeapon();
        ShipAPI ship = weapon.getShip();

        //Reads how wide the beam is originally; only do this if we haven't already found out
        if (beamWidth == -1f) {
            beamWidth = beam.getWidth();
        }

        //We have not fired properly yet; change beam size and ignore particle spawning
        if (!runOnce) {
            beam.setWidth(beamWidth * PRE_BEAM_WIDTH_MULT);
        } else {
            beam.setWidth(beamWidth);
        }

        //If we are at maximum charge level, and did damage this frame, we can spawn hyperspace holes
        if (weapon.getChargeLevel() >= 1f) {
            //If it's our first time firing the weapon properly, instantly spawn a hyperspace hole and register that we have fired
            if (!runOnce) {
                runOnce = true;

                //Only spawn a hole if we have a damage target, and we didn't hit shields
                if (beam.didDamageThisFrame() && beam.getDamageTarget() instanceof ShipAPI) {
                    if (beam.getDamageTarget().getShield() == null || !beam.getDamageTarget().getShield().isWithinArc(beam.getTo())) {
                        loa_hyperspace_tracker.addHyperspaceHole(HYPERHOLE_EXPLOSION_DELAY, beam.getTo(), DAMAGE_MULT*beam.getDamage().computeDamageDealt(1f), (ShipAPI)beam.getDamageTarget());
                        counter = MathUtils.getRandomNumberInRange(MIN_EXPLOSION_DELAY, MAX_EXPLOSION_DELAY);
                    }
                }
            }

            //Otherwise, we wait for our delay before spawning a new hole
            else if (counter <= 0f) {
                //Only spawn a hole if we have a damage target, and we didn't hit shields
                if (beam.didDamageThisFrame() && beam.getDamageTarget() instanceof ShipAPI) {
                    if (beam.getDamageTarget().getShield() == null || !beam.getDamageTarget().getShield().isWithinArc(beam.getTo())) {
                        loa_hyperspace_tracker.addHyperspaceHole(HYPERHOLE_EXPLOSION_DELAY, beam.getTo(), DAMAGE_MULT*beam.getDamage().computeDamageDealt(1f), (ShipAPI)beam.getDamageTarget());
                        counter = MathUtils.getRandomNumberInRange(MIN_EXPLOSION_DELAY, MAX_EXPLOSION_DELAY);
                    }
                }
            } else {
                counter -= amount;
            }
        }


                    // Screenspace check, because everyone loves more FPS!
                    //if (ShaderLib.isOnScreen(loc, 100))
                    //{
        //If we have fired properly, we spawn particles along the length of the beam
        if (runOnce) {
            //Calculate how many particles should be spawned this frame
            float particleCount = beamWidth * PARTICLE_SPAWN_WIDTH_MULT * MathUtils.getDistance(beam.getTo(), beam.getFrom()) * amount * PARTICLE_DENSITY * weapon.getChargeLevel();

            //Generate the particles and assign them their random characteristics
            for (int i = 0; i < particleCount; i++) {
                //First, get a random point on the beam's line
                Vector2f spawnPoint = MathUtils.getRandomPointOnLine(beam.getFrom(), beam.getTo());

                //Then, we offset that depending on width
                spawnPoint = MathUtils.getRandomPointInCircle(spawnPoint, beamWidth * PARTICLE_SPAWN_WIDTH_MULT);

                //If this point is too far off-screen, we go on to the next particle instead
                if (!Global.getCombatEngine().getViewport().isNearViewport(spawnPoint, PARTICLE_SIZE_MAX * 3f)) {
                    continue;
                }

                //After that, we calculate our velocity
                Vector2f velocity = new Vector2f(ship.getVelocity().x*PARTICLE_INERTIA_MULT, ship.getVelocity().y*PARTICLE_INERTIA_MULT);
                velocity = MathUtils.getRandomPointInCircle(velocity, PARTICLE_DRIFT);

                //And finally spawn the particle
                engine.addSmoothParticle(spawnPoint, velocity, MathUtils.getRandomNumberInRange(PARTICLE_SIZE_MIN, PARTICLE_SIZE_MAX), weapon.getChargeLevel(),
                        MathUtils.getRandomNumberInRange(PARTICLE_DURATION_MIN, PARTICLE_DURATION_MAX), PARTICLE_COLOR);
            }
        }
                  //  }
        //Reset our variables if we aren't firing anymore
        if (!weapon.isFiring() || weapon.getChargeLevel() <= 0f) {
            runOnce = false;
            counter = 0f;
        }
    }
}