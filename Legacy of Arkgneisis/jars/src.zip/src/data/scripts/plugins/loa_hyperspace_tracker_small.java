//By Nicke535
//Tracks "Hyperholes" in relation to enemy ships, and handles their detonation. The holes themselves need to be spawned by some other script
package data.scripts.plugins;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.*;
import com.fs.starfarer.api.graphics.SpriteAPI;
import com.fs.starfarer.api.input.InputEventAPI;
import data.scripts.util.MagicRender;
import org.lazywizard.lazylib.CollisionUtils;
import org.lazywizard.lazylib.MathUtils;
import org.lazywizard.lazylib.VectorUtils;
import org.lazywizard.lazylib.combat.CombatUtils;
import org.lazywizard.lazylib.combat.entities.SimpleEntity;
import org.lwjgl.util.vector.Vector2f;

import java.awt.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class loa_hyperspace_tracker_small extends BaseEveryFrameCombatPlugin {

    //-------------------------Settings for hole explosions, lightning bolts and/or charge-up---------------------------
    //Size of the AoE damage area
    private static final float DAMAGE_RADIUS = 20f;

    //The color of any decorative lightning bolts
    private static final Color LIGHTNING_COLOR = new Color (100f/255f, 255f/255f, 255f/255f, 255f/255f);

    //How far away from the explosion a decorative lightning bolt can spawn
    private static final float MAX_LIGHTNING_RANGE = 35f;

    //How close to the explosion a decorative lightning bolt can spawn
    private static final float MIN_LIGHTNING_RANGE = 20f;

    //The color of the charge-up effect
    private static final Color CHARGE_UP_COLOR = new Color (100f/255f, 50f/255f, 255f/255f, 255f/255f);

    //The size of the charge-up effect (at maximum size, decreases to 0)
    private static final float CHARGE_UP_SIZE = 50f;

    //The color of the first "overlay" hit particle
    private static final Color HIT_COLOR_1 = new Color (100f/255f, 0f/255f, 255f/255f, 255f/255f);
//    //The color of the second "overlay" hit particle
//    private static final Color HIT_COLOR_2 = new Color (110f/255f, 0f/255f, 250f/255f, 255f/255f);
//
    //The size of the first "overlay" hit particle
    private static final float HIT_SIZE_1 = 50f;
//    //The size of the second "overlay" hit particle
//    private static final float HIT_SIZE_2 = 100f;
//
    //The duration of the first "overlay" hit particle
    private static final float HIT_DURATION_1 = 0.5f;
//    //The duration of the second "overlay" hit particle
//    private static final float HIT_DURATION_2 = 0.4f;

    //The sound the hole makes upon exploding
    private static final String SOUND_EFFECT = "loa_warprift_explode_small";

    //--------------Explosion visuals use maps; each extra entry means an additional explosion particle is layered on-top of the other ones. All maps must have equal amount of entries----------------
    //How big the explosions are initially
    private static final Map<Integer, Vector2f> EXPLOSION_SIZES_START = new HashMap<Integer, Vector2f>();
    static {
        EXPLOSION_SIZES_START.put(1, new Vector2f(15f, 15f));
        EXPLOSION_SIZES_START.put(2, new Vector2f(15f, 15f));
    }
    //How much the explosions grows in size
    private static final Map<Integer, Vector2f> EXPLOSION_SIZES_GROWTH = new HashMap<Integer, Vector2f>();
    static {
        EXPLOSION_SIZES_GROWTH.put(1, new Vector2f(300f, 300f));
        EXPLOSION_SIZES_GROWTH.put(2, new Vector2f(300f, 300f));
    }
    //The color of each explosion
    private static final Map<Integer, Color> EXPLOSION_COLORS = new HashMap<Integer, Color>();
    static {
        EXPLOSION_COLORS.put(1, new Color(255f/255f, 255f/255f, 255f/255f, 255f/255f));
        EXPLOSION_COLORS.put(2, new Color(255f/255f, 255f/255f, 255f/255f, 255f/255f));
    }
    //How much each explosion "spins" along its own axis (in degrees/second)
    private static final Map<Integer, Float> EXPLOSION_SPINNING = new HashMap<Integer, Float>();
    static {
        EXPLOSION_SPINNING.put(1, 0f);
        EXPLOSION_SPINNING.put(2, 0f);
    }
    //How long each explosion remains at maximum opacity
    private static final Map<Integer, Float> EXPLOSION_MAX_DURATIONS = new HashMap<Integer, Float>();
    static {
        EXPLOSION_MAX_DURATIONS.put(1, 0.05f);
        EXPLOSION_MAX_DURATIONS.put(2, 0.05f);
    }
    //How long it takes for each explosion to go from 100% to 0% opacity
    private static final Map<Integer, Float> EXPLOSION_FADE_DURATIONS = new HashMap<Integer, Float>();
    static {
        EXPLOSION_FADE_DURATIONS.put(1, 0.1f);
        EXPLOSION_FADE_DURATIONS.put(2, 0.1f);
    }


    //HYPERHOLES and SHIPS are the core of the script, storing all holes' different attributes and which ship each hole belongs to
    //A HYPERHOLES Map, when added, contains:
    //  t - time, how long it takes for the hole to detonate
    //  ot - original time, same as time when the hole is spawned, but doesn't tick down
    //  x - x-position (RELATIVE TO THE ENEMY SHIP)
    //  y - y-position (RELATIVE TO THE ENEMY SHIP)
    //  d - damage, pretty self-explanatory
    //  explodes - 1f if the hole explodes, 0f otherwise. If 0f, most of the other stats are pretty pointless
    //  SHIP - the ID of the ship it's currently linked to. *Not* added manually, tracked entirely in-script
    private static List<Map<String,Float>> HYPERHOLES = new ArrayList<Map<String,Float>>();
    private static Map<Float,ShipAPI> SHIPS = new HashMap<>();
    private static float CURRENT_ID = 0f;


    //Adds a new hyperspace hole to keep track of: this should probably be called in an on-hit script in most cases
    //Note that the position is absolute in this case, and not in relation to the ship
    public static void addHyperspaceHole(float timeUntilDetonation, Vector2f position, float damage, ShipAPI ship) {
        //Stores the data in a map so we can add it to the main HYPERHOLES map
        Map<String,Float> data = new HashMap<String, Float>();
        data.put("t", timeUntilDetonation);
        data.put("ot", timeUntilDetonation);

        //This is to get our point relative to the ship
        Vector2f relativePoint = VectorUtils.rotateAroundPivot(position, ship.getLocation(), -ship.getFacing(), new Vector2f(0f, 0f));
        relativePoint.x -= ship.getLocation().x;
        relativePoint.y -= ship.getLocation().y;
        data.put("x", relativePoint.x);
        data.put("y", relativePoint.y);

        //Stores our damage
        data.put("d", damage);

        //This hole explodes
        data.put("explodes", 1f);

        //Finally, add the map to the HYPERHOLES map
        addMemberDirectly(data, ship);
    }


    //Similar to the function above, but has no explosion
    public static void addHyperspaceHoleWithoutExplosion(float timeUntilDetonation, Vector2f position, ShipAPI ship) {
        //Stores the data in a map so we can add it to the main HYPERHOLES map
        Map<String,Float> data = new HashMap<String, Float>();
        data.put("t", timeUntilDetonation);
        data.put("ot", timeUntilDetonation);

        //This is to get our point relative to the ship
        Vector2f relativePoint = VectorUtils.rotateAroundPivot(position, ship.getLocation(), -ship.getFacing(), new Vector2f(0f, 0f));
        relativePoint.x -= ship.getLocation().x;
        relativePoint.y -= ship.getLocation().y;
        data.put("x", relativePoint.x);
        data.put("y", relativePoint.y);

        //Stores our (non-existant, we don't explode) damage
        data.put("d", 0f);

        //This hole explodes
        data.put("explodes", 1f);

        //Finally, add the map to the HYPERHOLES map
        addMemberDirectly(data, ship);
    }

    //Allows manually adding a member from another script; it's probably just easier to add via addHyperspaceHole()
    public static void addMemberDirectly(Map<String,Float> data, ShipAPI ship) {
        data.put("SHIP", CURRENT_ID);
        SHIPS.put(CURRENT_ID, ship);
        CURRENT_ID += 0.1f;
        HYPERHOLES.add(data);

        //This is so we don't run out of IDs after 20000 shots (if we happen to reach that amount)
        if (CURRENT_ID > 2000f) {
            CURRENT_ID = 0f;
        }
    }

    private List<Map<String,Float>> toRemove = new ArrayList<>();

    @Override
    public void init(CombatEngineAPI engine) {
        //reinitialize the data
        HYPERHOLES.clear();
        SHIPS.clear();
        CURRENT_ID = 0f;
    }

    @Override
    public void advance(float amount, List<InputEventAPI> events) {
        CombatEngineAPI engine = Global.getCombatEngine();
        if (engine == null){return;}

        if (!HYPERHOLES.isEmpty()){
            //Set "amount" to 0 if we are paused
            amount = (engine.isPaused() ? 0f : amount);

            //Dig through the HYPERHOLES
            for (Map< String,Float > entry : HYPERHOLES) {

                //Time calculation
                float time = entry.get("t");
                time -= amount;

                //Saves the ship to a variable to save some code later on
                ShipAPI ship = SHIPS.get(entry.get("SHIP"));

                //If we don't have a ship, remove the hole
                if (ship == null) {
                    toRemove.add(entry);
                    SHIPS.remove(entry.get("SHIP"));
                    continue;
                }

                //If our time is up OR our ship was just blown to pieces OR the ship started phasing, remove the hole
                if (time <= 0 || ship.isPiece() || ship.isPhased()){
                    toRemove.add(entry);
                    //If the hole is tagged to explode, explode it
                    if (entry.get("explodes") >= 1f) {
                        handleExplosion(entry, ship);
                    }
                    SHIPS.remove(entry.get("SHIP"));
                } else {
                    //Otherwise, we start drawing the visuals and tick down our time
                    //Spawn particles each frame which shrink over time (note that the particles have a very short duration, dependent on our framerate)

                    //This gets the correct location in relation to the ship in question
                    float posX = entry.get("x");
                    float posY = entry.get("y");
                    Vector2f particlePos = new Vector2f(posX, posY);
                    particlePos = VectorUtils.rotateAroundPivot(particlePos, new Vector2f(0f, 0f), ship.getFacing(), new Vector2f(0f, 0f));
                    particlePos.x += ship.getLocation().x;
                    particlePos.y += ship.getLocation().y;

                    //Then, simply spawn the particle with parameters depending on how long the hole has lasted and the other parameters we sent in (do not do this off-screen)
                    if (Global.getCombatEngine().getViewport().isNearViewport(particlePos, CHARGE_UP_SIZE * 5f)) {
                        engine.addSmoothParticle(particlePos, ship.getVelocity(), CHARGE_UP_SIZE * (time / entry.get("ot")), 1f, amount * 2f, CHARGE_UP_COLOR);
                    }

                    //Updates our time
                    entry.put("t", time);
                }
            }
            //Remove the holes that faded out
            //Can't be done from within the iterator or it will fail when members will be missing
            if (!toRemove.isEmpty()){
                for(Map< String,Float > w : toRemove ){
                    HYPERHOLES.remove(w);
                }
                toRemove.clear();
            }
        }
    }

    //Handles the explosion of the hyperholes. Should ALWAYS be called just before removing a hole (unless the ship it was attached to suddenly disappears, or we have tagged the hole as non-exploding)
    private void handleExplosion ( Map< String,Float > hole, ShipAPI ship){
        if (ship != null) {
            //This gets the correct location in relation to the ship in question
            float posX = hole.get("x");
            float posY = hole.get("y");
            Vector2f explosionPos = new Vector2f(posX, posY);
            explosionPos = VectorUtils.rotateAroundPivot(explosionPos, new Vector2f(0f, 0f), ship.getFacing(), new Vector2f(0f, 0f));
            explosionPos.x += ship.getLocation().x;
            explosionPos.y += ship.getLocation().y;

            //Only draw visuals when the explosion is near-enough to being on-screen; we could be more slightly more aggressive in this culling but since the explosions take time and are big, we want some wiggle-room
            if (Global.getCombatEngine().getViewport().isNearViewport(explosionPos, 500f)) {
                //Visuals: strange custom explosions
                for (int key : EXPLOSION_SIZES_START.keySet()) {
                    SpriteAPI spriteToUse = Global.getSettings().getSprite("loa_hyperspace_visuals","" + MathUtils.getRandomNumberInRange(1, 3));
                    MagicRender.battlespace(spriteToUse, explosionPos, new Vector2f(0f, 0f), EXPLOSION_SIZES_START.get(key), EXPLOSION_SIZES_GROWTH.get(key), MathUtils.getRandomNumberInRange(0f, 360f),
                            EXPLOSION_SPINNING.get(key), EXPLOSION_COLORS.get(key), true, 0f, EXPLOSION_MAX_DURATIONS.get(key), EXPLOSION_FADE_DURATIONS.get(key));
                }

                //Visuals; "overlay" hit particles
                Global.getCombatEngine().addHitParticle(explosionPos, new Vector2f(0f, 0f), HIT_SIZE_1, 1f, HIT_DURATION_1, HIT_COLOR_1);
                //Global.getCombatEngine().addHitParticle(explosionPos, new Vector2f(0f, 0f), HIT_SIZE_2, 1f, HIT_DURATION_2, HIT_COLOR_2);

                //Visuals: random EMP arcs
                for (int i = MathUtils.getRandomNumberInRange(1, 1); i > 0; i--) {
                    //Picks a random nearby point
                    Vector2f targetPoint = MathUtils.getPointOnCircumference(explosionPos, MathUtils.getRandomNumberInRange(MIN_LIGHTNING_RANGE, MAX_LIGHTNING_RANGE), MathUtils.getRandomNumberInRange(0f, 360f));

                    //Spawns a fake entity so we can target it with the bolt
                    CombatEntityAPI targetEntity = new SimpleEntity(targetPoint);

                    //And then spawns the bolt itself
                    Global.getCombatEngine().spawnEmpArc(ship, explosionPos, ship, targetEntity,
                            DamageType.ENERGY, //Damage type
                            0f, //Damage
                            0f, //Emp
                            100000f, //Max range
                            null, //Impact sound
                            MathUtils.getRandomNumberInRange(6f, 9f), // thickness of the lightning bolt
                            new Color(100, 0, 150), //Central color
                            LIGHTNING_COLOR); //Fringe Color
                }
            }

            //Deals damage to anything that is really close to the hole (our main ship is automatically close enough, of course)
            for (ShipAPI target : CombatUtils.getShipsWithinRange(explosionPos, DAMAGE_RADIUS)) {
                //Ignore anything phased
                if (target.isPhased() || target.getCollisionClass().equals(CollisionClass.NONE)) {
                    continue;
                }

                //If this is our main target, we already know where to apply the damage
                Vector2f damageLoc = new Vector2f(explosionPos.x, explosionPos.y);

                //Otherwise, we alter the damage location to be within the target's bounds
                if (target != ship) {
                    damageLoc = CollisionUtils.getCollisionPoint(explosionPos, target.getLocation(), target);
                }

                //If we *somehow* have a damageLoc which is null or outside of the bounds of the target, skip the damage instead of crashing
                if (damageLoc == null || !CollisionUtils.isPointWithinBounds(damageLoc, target)) {
                    continue;
                }

                //Finally, actually deal damage
                Global.getCombatEngine().applyDamage(target, damageLoc, hole.get("d"), DamageType.ENERGY, 0f, false, false, ship, true);
            }

            //Plays a sound when exploding
            Global.getSoundPlayer().playSound(SOUND_EFFECT, MathUtils.getRandomNumberInRange(0.98f, 1.02f), MathUtils.getRandomNumberInRange(0.98f, 1.02f), explosionPos, new Vector2f(0f, 0f));
        }
    }
}
