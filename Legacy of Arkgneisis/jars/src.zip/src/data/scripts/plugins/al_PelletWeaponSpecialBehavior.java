package data.scripts.plugins;

import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.DamagingProjectileAPI;
import com.fs.starfarer.api.combat.BaseEveryFrameCombatPlugin;
import com.fs.starfarer.api.combat.WeaponAPI;
import com.fs.starfarer.api.input.InputEventAPI;
import org.lwjgl.util.vector.Vector2f;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class al_PelletWeaponSpecialBehavior extends BaseEveryFrameCombatPlugin
{
    // Dummy projectile ID -> String array of weapon IDs that fire actual projectiles
    private static final Map DUMMY_PROJS = new HashMap();
    private CombatEngineAPI engine;

    static
    {
        DUMMY_PROJS.put("al_pellet_small_prime", new String[]
                {
                        "al_pelletdriver_1", "al_pelletdriver_2", "al_pelletdriver_3", "al_pelletdriver_4", "al_pelletdriver_5"
                });
        DUMMY_PROJS.put("al_pellet_medium_prime", new String[]
                {
                        "al_pelletgun_1", "al_pelletgun_2", "al_pelletgun_3", "al_pelletgun_4", "al_pelletgun_5", "al_pelletgun_6", "al_pelletgun_7"
                });
        DUMMY_PROJS.put("al_pellet_large_prime", new String[]
                {
                        "al_pelletcannon_1", "al_pelletcannon_2", "al_pelletcannon_3", "al_pelletcannon_4", "al_pelletcannon_5", "al_pelletcannon_6", "al_pelletcannon_7", "al_pelletcannon_8", "al_pelletcannon_9"
                });
    }

    // A list of velocities for the projectiles; used for determining how much velocity is kept from the firing ship
    private static final Map<String, Float> PROJ_SPEEDS = new HashMap<String, Float>();
    static
    {
        PROJ_SPEEDS.put("al_pellet_small_prime", 1000f);
        PROJ_SPEEDS.put("al_pelletdriver_1", 1200f);
        PROJ_SPEEDS.put("al_pelletdriver_2", 1100f);
        PROJ_SPEEDS.put("al_pelletdriver_3", 1000f);
        PROJ_SPEEDS.put("al_pelletdriver_4", 900f);
        PROJ_SPEEDS.put("al_pelletdriver_5", 800f);

        PROJ_SPEEDS.put("al_pellet_medium_prime", 1000f);
        PROJ_SPEEDS.put("al_pelletgun_1", 1300f);
        PROJ_SPEEDS.put("al_pelletgun_2", 1200f);
        PROJ_SPEEDS.put("al_pelletgun_3", 1100f);
        PROJ_SPEEDS.put("al_pelletgun_4", 1000f);
        PROJ_SPEEDS.put("al_pelletgun_5", 900f);
        PROJ_SPEEDS.put("al_pelletgun_6", 800f);
        PROJ_SPEEDS.put("al_pelletgun_7", 700f);

        PROJ_SPEEDS.put("al_pellet_large_prime", 1200f);
        PROJ_SPEEDS.put("al_pelletcannon_1", 1600f);
        PROJ_SPEEDS.put("al_pelletcannon_2", 1500f);
        PROJ_SPEEDS.put("al_pelletcannon_3", 1400f);
        PROJ_SPEEDS.put("al_pelletcannon_4", 1300f);
        PROJ_SPEEDS.put("al_pelletcannon_5", 1200f);
        PROJ_SPEEDS.put("al_pelletcannon_6", 1100f);
        PROJ_SPEEDS.put("al_pelletcannon_7", 1000f);
        PROJ_SPEEDS.put("al_pelletcannon_8", 900f);
        PROJ_SPEEDS.put("al_pelletcannon_9", 800f);
    }


    private void replace(DamagingProjectileAPI proj, String[] replaceWith)
    {
        for (String replaceWith1 : replaceWith)
        {
            //Handles the velocity added by the ship itself
            Vector2f sourceAddonVelocity = proj.getSource() == null ? null : new Vector2f(proj.getSource().getVelocity().x, proj.getSource().getVelocity().y);

            engine.spawnProjectile(proj.getSource(), proj.getWeapon(), replaceWith1, proj.getLocation(), proj.getFacing(), sourceAddonVelocity);
        }
        engine.removeEntity(proj);
    }

    @Override
    public void advance(float amount, List<InputEventAPI> events)
    {
        if (engine == null)
        {
            return;
        }
        if (engine.isPaused())
        {
            return;
        }
        DamagingProjectileAPI proj;
        String specId;
        WeaponAPI source;

        for (Iterator iter = engine.getProjectiles().iterator(); iter.hasNext();)
        {
            proj = (DamagingProjectileAPI) iter.next();
            specId = proj.getProjectileSpecId();
            source = proj.getWeapon();

            if (source == null || !DUMMY_PROJS.containsKey(specId))
            {
                continue;
            }

            String[] replaceWith = (String[]) DUMMY_PROJS.get(specId);
            replace(proj, replaceWith);
        }

    }

    @Override
    public void init(CombatEngineAPI engine)
    {
        this.engine = engine;
    }
}