//By Nicke535
//Similar to the trail-spawning plugin, this plugin spawns particles behind projectiles each frame
package data.scripts.plugins;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.*;
import com.fs.starfarer.api.graphics.SpriteAPI;
import com.fs.starfarer.api.input.InputEventAPI;
import org.lazywizard.lazylib.MathUtils;
import org.lwjgl.util.vector.Vector2f;

import java.awt.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.lwjgl.opengl.GL11.GL_ONE;
import static org.lwjgl.opengl.GL11.GL_ONE_MINUS_SRC_ALPHA;
import static org.lwjgl.opengl.GL11.GL_SRC_ALPHA;

public class loa_warpshotparticles extends BaseEveryFrameCombatPlugin {
    //--------------------------------------THESE ARE ALL MAPS FOR DIFFERENT VISUAL STATS FOR THE PARTICLES: THEIR NAMES ARE FAIRLY SELF-EXPLANATORY---------------------------------------------------
    //Valid types: SMOKE, BRIGHT, SMOOTH
    private static final Map<String, String> PARTICLE_TYPES = new HashMap<>();
    static {
        PARTICLE_TYPES.put("loa_warpshotproj", "SMOOTH");
    }
    private static final Map<String, Float> PARTICLES_PER_SECOND = new HashMap<>();
    static {
        PARTICLES_PER_SECOND.put("loa_warpshotproj", 30f);
    }
    private static final Map<String, Float> MIN_DURATIONS = new HashMap<>();
    static {
        MIN_DURATIONS.put("loa_warpshotproj", 0.2f);
    }
    private static final Map<String, Float> MAX_DURATIONS = new HashMap<>();
    static {
        MAX_DURATIONS.put("loa_warpshotproj", 0.8f);
    }
    private static final Map<String, Color> COLORS = new HashMap<>();
    static {
        COLORS.put("loa_warpshotproj", new Color(210,0,255, 255));
    }
    private static final Map<String, Float> MIN_SIZES = new HashMap<>();
    static {
        MIN_SIZES.put("loa_warpshotproj", 2f);
    }
    private static final Map<String, Float> MAX_SIZES = new HashMap<>();
    static {
        MAX_SIZES.put("loa_warpshotproj", 9f);
    }
    private static final Map<String, Float> MIN_SPREADOUT_VELOCITIES = new HashMap<>();
    static {
        MIN_SPREADOUT_VELOCITIES.put("loa_warpshotproj", 0f);
    }
    private static final Map<String, Float> MAX_SPREADOUT_VELOCITIES = new HashMap<>();
    static {
        MAX_SPREADOUT_VELOCITIES.put("loa_warpshotproj", 0f);
    }
    private static final Map<String, Float> MIN_SPAWN_AREAS = new HashMap<>();
    static {
        MIN_SPAWN_AREAS.put("loa_warpshotproj", 0f);
    }
    private static final Map<String, Float> MAX_SPAWN_AREAS = new HashMap<>();
    static {
        MAX_SPAWN_AREAS.put("loa_warpshotproj", 0f);
    }

    @Override
    public void advance (float amount, List<InputEventAPI> events) {
        if (Global.getCombatEngine() == null || Global.getCombatEngine().isPaused()) {
            return;
        }
        CombatEngineAPI engine = Global.getCombatEngine();

        //Runs once on each projectile that matches one of the IDs specified in our maps
        for (DamagingProjectileAPI proj : engine.getProjectiles()) {
            //Ignore already-collided projectiles, fading projectiles, and projectiles that don't match our IDs
            if (proj.getProjectileSpecId() == null || proj.didDamage() || proj.isFading()) {
                continue;
            }
            if (!PARTICLE_TYPES.keySet().contains(proj.getProjectileSpecId())) {
                continue;
            }

            //-------------------------------------------For visual effects---------------------------------------------
            String specID = proj.getProjectileSpecId();

            //Loops depending on how many particles are spawned per second
            float counter = PARTICLES_PER_SECOND.get(specID) * amount;
            while (Math.random() < counter) {
                counter--;

                //First, get a "fake" location, so we emulate spawning inbetweeen frames
                Vector2f fakeCenter = MathUtils.getRandomPointOnLine(proj.getLocation(), new Vector2f(proj.getLocation().x + (proj.getVelocity().x*amount), proj.getLocation().y + (proj.getVelocity().y*amount)));

                //Then, determine spawn point and velocity
                Vector2f spawnPoint = MathUtils.getPointOnCircumference(fakeCenter,
                        MathUtils.getRandomNumberInRange(MIN_SPAWN_AREAS.get(specID), MAX_SPAWN_AREAS.get(specID)),
                        MathUtils.getRandomNumberInRange(0f, 360f));
                Vector2f velocity = MathUtils.getPointOnCircumference(new Vector2f(0f, 0f),
                        MathUtils.getRandomNumberInRange(MIN_SPREADOUT_VELOCITIES.get(specID), MAX_SPREADOUT_VELOCITIES.get(specID)),
                        MathUtils.getRandomNumberInRange(0f, 360f));

                //And finally spawn the particles
                if (PARTICLE_TYPES.get(specID).contains("BRIGHT")) {
                    engine.addHitParticle(spawnPoint, velocity, MathUtils.getRandomNumberInRange(MIN_SIZES.get(specID), MAX_SIZES.get(specID)),
                            1f, MathUtils.getRandomNumberInRange(MIN_DURATIONS.get(specID), MAX_DURATIONS.get(specID)), COLORS.get(specID));
                } else if (PARTICLE_TYPES.get(specID).contains("SMOOTH")) {
                    engine.addSmoothParticle(spawnPoint, velocity, MathUtils.getRandomNumberInRange(MIN_SIZES.get(specID), MAX_SIZES.get(specID)),
                            1f, MathUtils.getRandomNumberInRange(MIN_DURATIONS.get(specID), MAX_DURATIONS.get(specID)), COLORS.get(specID));
                } else {
                    engine.addSmokeParticle(spawnPoint, velocity, MathUtils.getRandomNumberInRange(MIN_SIZES.get(specID), MAX_SIZES.get(specID)),
                            1f, MathUtils.getRandomNumberInRange(MIN_DURATIONS.get(specID), MAX_DURATIONS.get(specID)), COLORS.get(specID));
                }
            }
        }
    }
}