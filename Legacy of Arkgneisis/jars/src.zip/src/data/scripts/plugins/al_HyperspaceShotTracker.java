//By Nicke535
//Tracks "Hyperholes" in relation to enemy ships, and handles their detonation. The holes themselves need to be spawned by some other script
package data.scripts.plugins;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.*;
import com.fs.starfarer.api.input.InputEventAPI;
import org.lazywizard.lazylib.CollisionUtils;
import org.lazywizard.lazylib.MathUtils;
import org.lazywizard.lazylib.VectorUtils;
import org.lazywizard.lazylib.combat.CombatUtils;
import org.lazywizard.lazylib.combat.entities.SimpleEntity;
import org.lwjgl.util.vector.Vector2f;

import java.awt.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class al_HyperspaceShotTracker extends BaseEveryFrameCombatPlugin {

    //HYPERHOLES and SHIPS are the core of the script, storing all holes' different attributes and which ship each hole belongs to
    //A HYPERHOLES Map, when added, contains:
    //  t - time, how long it takes for the hole to detonate
    //  ot - original time, same as time when the hole is spawned, but doesn't tick down
    //  x - x-position (RELATIVE TO THE ENEMY SHIP)
    //  y - y-position (RELATIVE TO THE ENEMY SHIP)
    //  n - number of EMP arcs spawned when the hole detonates
    //  cer - red part of the explosion color in an RGB spectrum (from 0f-1f)
    //  ceg - green part of the explosion color in an RGB spectrum (from 0f-1f)
    //  ceb - blue part of the explosion color in an RGB spectrum (from 0f-1f)
    //  e - explosion size
    //  cpr - red part of color in an RGB spectrum (from 0f-1f)
    //  cpg - green part of color in an RGB spectrum (from 0f-1f)
    //  cpb - blue part of color in an RGB spectrum (from 0f-1f)
    //  p - particle size, both for before-explosion particles and after-explosion particles
    //  pd - particle duration
    //  lr - lightning maximum range
    //  lmr - lightning minimum range
    //  d - damage of each lightning bolt (is then also randomized by +-10% for appearance)
    //  emp - EMP of each lightning bolt (is then also randomized by +-10% for appearance)
    //  SHIP - the ID of the ship it's currently linked to. *Not* added manually, tracked entirely in-script
    private static List<Map<String,Float>> HYPERHOLES = new ArrayList<Map<String,Float>>();
    private static Map<Float,ShipAPI> SHIPS = new HashMap<>();
    private static float CURRENT_ID = 0f;


    //Adds a new hyperspace hole to keep track of: this should probably be called in an on-hit script in most cases
    //Note that the position is absolute in this case, and not in relation to the ship
    public static void addHyperspaceHole(float timeUntilDetonation, Vector2f position, int spawnedProjectiles, Color explosionColor, float explosionSize, Color particleColor, float particleSize, float particleDuration,
                                         float lightningMaximumRange, float lightningMinimumRange, float lightningDamage, float lightningEMP, ShipAPI ship) {
        //Stores the data in a map so we can add it to the main HYPERHOLES map
        Map<String,Float> data = new HashMap<String, Float>();
        data.put("t", timeUntilDetonation);
        data.put("ot", timeUntilDetonation);

        //This is to get our point relative to the ship
        Vector2f relativePoint = VectorUtils.rotateAroundPivot(position, ship.getLocation(), -ship.getFacing(), new Vector2f(0f, 0f));
        relativePoint.x -= ship.getLocation().x;
        relativePoint.y -= ship.getLocation().y;
        data.put("x", relativePoint.x);
        data.put("y", relativePoint.y);

        data.put("n", (float)spawnedProjectiles);

        //Explosion data
        data.put("cer", (float)explosionColor.getRed()/255f);
        data.put("ceg", (float)explosionColor.getGreen()/255f);
        data.put("ceb", (float)explosionColor.getBlue()/255f);
        data.put("e", explosionSize);

        //Particle data
        data.put("cpr", (float)particleColor.getRed()/255f);
        data.put("cpg", (float)particleColor.getGreen()/255f);
        data.put("cpb", (float)particleColor.getBlue()/255f);
        data.put("p", particleSize);
        data.put("pd", particleDuration);

        //Lightning bolt data
        data.put("lr", lightningMaximumRange);
        data.put("lmr", lightningMinimumRange);
        data.put("d", lightningDamage);
        data.put("emp", lightningEMP);

        //Finally, add the map to the HYPERHOLES map
        addMemberDirectly(data, ship);
    }

    //Allows manually adding a member from another script; it's probably just easier to add via addHyperspaceHole()
    public static void addMemberDirectly(Map<String,Float> data, ShipAPI ship) {
        data.put("SHIP", CURRENT_ID);
        SHIPS.put(CURRENT_ID, ship);
        CURRENT_ID += 0.1f;
        HYPERHOLES.add(data);

        //This is so we don't run out of IDs after 20000 shots (if we happen to reach that amount)
        if (CURRENT_ID > 2000f) {
            CURRENT_ID = 0f;
        }
    }

    private List<Map<String,Float>> toRemove = new ArrayList<>();

    @Override
    public void init(CombatEngineAPI engine) {
        //reinitialize the data
        HYPERHOLES.clear();
        SHIPS.clear();
        CURRENT_ID = 0f;
    }

    @Override
    public void advance(float amount, List<InputEventAPI> events) {
        CombatEngineAPI engine = Global.getCombatEngine();
        if (engine == null){return;}

        if (!HYPERHOLES.isEmpty()){
            //Set "amount" to 0 if we are paused
            amount = (engine.isPaused() ? 0f : amount);

            //Dig through the HYPERHOLES
            for (Map< String,Float > entry : HYPERHOLES) {

                //Time calculation
                float time = entry.get("t");
                time -= amount;

                //Saves the ship to a variable to save some code later on
                ShipAPI ship = SHIPS.get(entry.get("SHIP"));

                //If we don't have a ship, remove the hole
                if (ship == null) {
                    toRemove.add(entry);
                    SHIPS.remove(entry.get("SHIP"));
                    continue;
                }

                //If our time is up OR our ship was just blown to pieces OR the ship started phasing, detonate the hole and remove it
                if (time <= 0 || ship.isPiece() || ship.isPhased()){
                    handleExplosion(entry, ship);
                    toRemove.add(entry);
                    SHIPS.remove(entry.get("SHIP"));
                } else {
                    //Otherwise, we start drawing the visuals and tick down our time
                    //Spawn particles each frame which shrink over time (note that the particles have a very short duration, dependent on our framerate)

                    //This gets the correct location in relation to the ship in question
                    float posX = entry.get("x");
                    float posY = entry.get("y");
                    Vector2f particlePos = new Vector2f(posX, posY);
                    particlePos = VectorUtils.rotateAroundPivot(particlePos, new Vector2f(0f, 0f), ship.getFacing(), new Vector2f(0f, 0f));
                    particlePos.x += ship.getLocation().x;
                    particlePos.y += ship.getLocation().y;

                    //Then, simply spawn the particle with parameters depending on how long the hole has lasted and the other parameters we sent in
                    Color particleColor = new Color(entry.get("cpr"), entry.get("cpg"), entry.get("cpb"), 1f);
                    engine.addSmoothParticle(particlePos, ship.getVelocity(), entry.get("p") * (time / entry.get("ot")), 1f, amount*2f, particleColor);

                    //Updates our time
                    entry.put("t", time);
                }
            }
            //Remove the holes that faded out
            //Can't be done from within the iterator or it will fail when members will be missing
            if (!toRemove.isEmpty()){
                for(Map< String,Float > w : toRemove ){
                    HYPERHOLES.remove(w);
                }
                toRemove.clear();
            }
        }
    }

    //Handles the explosion of the hyperholes. Should ALWAYS be called just before removing a hole (unless the ship it was attached to suddenly disappears)
    private void handleExplosion ( Map< String,Float > hole, ShipAPI ship){
        if (ship != null) {
            //This gets the correct location in relation to the ship in question
            float posX = hole.get("x");
            float posY = hole.get("y");
            Vector2f explosionPos = new Vector2f(posX, posY);
            explosionPos = VectorUtils.rotateAroundPivot(explosionPos, new Vector2f(0f, 0f), ship.getFacing(), new Vector2f(0f, 0f));
            explosionPos.x += ship.getLocation().x;
            explosionPos.y += ship.getLocation().y;

            //Spawns a visual explosion and particle
            Global.getCombatEngine().spawnExplosion(explosionPos, new Vector2f(0f, 0f), new Color(hole.get("cer"), hole.get("ceg"), hole.get("ceb"), 1f) ,hole.get("e"), 0.35f);
            Global.getCombatEngine().addHitParticle(explosionPos, new Vector2f(0f, 0f), hole.get("p"), 1f, hole.get("pd"), new Color(hole.get("cpr"), hole.get("cpg"), hole.get("cpb"), 1f));

            //Spawns a whole bunch of EMP arcs at random points near the detonation point; if an arc doesn't hit within 20 SU of a target, it's considered a miss, and doesn't do anything except give visual flare
            for (int i = 0; i < hole.get("n"); i++) {
                //First, picks a random spot within max lightning range, but outside the minimum lightning range (pick in an entire circle, thus the 0-360 degrees)
                Vector2f hitLocation = MathUtils.getPointOnCircumference(explosionPos, MathUtils.getRandomNumberInRange(hole.get("lmr"), hole.get("lr")), MathUtils.getRandomNumberInRange(0f, 360f));

                //Then, get the closest ship or missile within 20f of that location; start by getting all entities
                CombatEntityAPI nearestTarget = null;
                for (CombatEntityAPI target : CombatUtils.getEntitiesWithinRange(hitLocation, 20f)) {
                    //Ignore anything that isn't a ship or a missile
                    if (target instanceof MissileAPI || target instanceof ShipAPI) {
                        //Also ignore things without collision, and things that are phased
                        if (target instanceof ShipAPI) {
                            if (((ShipAPI)target).isPhased()) {
                                continue;
                            }
                        }
                        if (target.getCollisionClass().equals(CollisionClass.NONE)) {
                            continue;
                        }

                        //Then, our nearest target is null, simply set this as the nearest target
                        if (nearestTarget == null) {
                            nearestTarget = target;
                            continue;
                        }

                        //Otherwise, we compare the distance to both this target and our current nearest target; if this one is nearer, we target this one
                        if (MathUtils.getDistance(target.getLocation(), hitLocation) < MathUtils.getDistance(nearestTarget.getLocation(), hitLocation)) {
                            nearestTarget = target;
                        }
                    }
                }

                //If we didn't find any applicable target, spawn a dummy in the location, so we can spawn an EMP arc anyhow
                if (nearestTarget == null) {
                    nearestTarget = new SimpleEntity(hitLocation);
                }

                //Then fire the EMP arc!
                Global.getCombatEngine().spawnEmpArc(ship, explosionPos, ship, nearestTarget,
                        DamageType.ENERGY, //Damage type
                        hole.get("d"), //Damage
                        hole.get("emp"), //Emp
                        100000f, //Max range
                        "tachyon_lance_emp_impact", //Impact sound
                        MathUtils.getRandomNumberInRange(12f, 16f), // thickness of the lightning bolt
                        new Color(255, 255, 255), //Central color
                        new Color(hole.get("cpr"), hole.get("cpg"), hole.get("cpb"), 1f) //Fringe Color
                );
            }

            //Un-comment and adjust ID if you want a sound on arc generation
            
            Global.getSoundPlayer().playSound("tachyon_lance_emp_impact", 1f, 1f, explosionPos, new Vector2f(0f, 0f));
            
        }
    }
}
