package data.scripts.plugins;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.*;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.input.InputEventAPI;
import com.fs.starfarer.api.loading.DamagingExplosionSpec;
import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.api.util.Pair;
import org.apache.log4j.Logger;
import org.lazywizard.lazylib.CollisionUtils;
import org.lazywizard.lazylib.MathUtils;
import org.lazywizard.lazylib.VectorUtils;
import org.lazywizard.lazylib.combat.CombatUtils;
import org.lazywizard.lazylib.combat.entities.SimpleEntity;
import org.lwjgl.util.vector.Vector2f;

import java.awt.*;
import java.util.*;
import java.util.List;

/**
 * Handles special explosion behaviour for Loa-Hightech ships
 * @author Nicke535
 */
public class loa_explosion_manager_plugin extends BaseEveryFrameCombatPlugin{
    private final static Logger LOGGER = Global.getLogger(loa_explosion_manager_plugin.class);

    // --- Premature/harmless explosion settings --- //

    //Maximum and minimum number of arcs spawned (...*per piece*, unfortunately) when a harmless/premature
    //explosion occurs
    private final static float HARMLESS_EXPLOSION_ARC_MAX = 10;
    private final static float HARMLESS_EXPLOSION_ARC_MIN = 5;

    //Maximum and minimum range of any harmless arc fired by the ship
    private final static float HARMLESS_ARC_MAX_RANGE = 750f;
    private final static float HARMLESS_ARC_MIN_RANGE = 200f;

    //Sounds for the premature explosion, by hullsize
    private final static HashMap<HullSize, String> HARMLESS_EXPLOSION_SOUNDS = new HashMap<>();
    static {
        HARMLESS_EXPLOSION_SOUNDS.put(HullSize.FRIGATE, "loa_explosionoverlay_1");
        HARMLESS_EXPLOSION_SOUNDS.put(HullSize.DESTROYER, "loa_explosionoverlay_1");
        HARMLESS_EXPLOSION_SOUNDS.put(HullSize.CRUISER, "loa_explosionoverlay_1");
        HARMLESS_EXPLOSION_SOUNDS.put(HullSize.CAPITAL_SHIP, "loa_explosionoverlay_1");
    }

    // --- Mini-explosion settings --- //

    //How many mini-explosions we expect per second... *sort of*
    //This is only a suggestion, the actual number is slightly randomized
    private final static float MINIEXPLOSION_AMOUNT_PER_SECOND = 10f;

    //How large and small mini-explosions are allowed to be
    private final static float MINIEXPLOSION_MAX_SIZE = 25f;
    private final static float MINIEXPLOSION_MIN_SIZE = 15f;

    //Minimum and maximum allowed time for a mini-explosion to last
    private final static float MINIEXPLOSION_MAX_DURATION = 1f;
    private final static float MINIEXPLOSION_MIN_DURATION = 0.2f;

    //Color of all mini-explosions
    private final static Color MINIEXPLOSION_COLOR = new Color(50, 100, 255, 255);

    //Sound stats for the mini-explosions
    private final static String MINIEXPLOSION_SOUND = "loa_high_death_micro";
    private final static float MINIEXPLOSION_SOUND_CHANCE = 1f;


    // --- Arc settings --- //

    //How many arcs we expect per second... *sort of*
    //This is only a suggestion, the actual number is slightly randomized
    private final static float ARC_AMOUNT_PER_SECOND = 10f;

    //List of the dummy weapons that the explosions can fire
    //Determines range, so nice naming scheme is adviced
    private final static List<String> ARC_WEAPONS = new ArrayList<>();
    static {
        ARC_WEAPONS.add(0, "loa_deatharc_1");
        ARC_WEAPONS.add(1, "loa_deatharc_2");
        ARC_WEAPONS.add(2, "loa_deatharc_3");
        ARC_WEAPONS.add(3, "loa_deatharc_4");
        ARC_WEAPONS.add(4, "loa_deatharc_5");
        ARC_WEAPONS.add(5, "loa_deatharc_6");
        ARC_WEAPONS.add(6, "loa_deatharc_7");
        ARC_WEAPONS.add(7, "loa_deatharc_8");
        ARC_WEAPONS.add(8, "loa_deatharc_9");
        ARC_WEAPONS.add(9, "loa_deatharc_10");
        
    }

    //The possible ranges of each hull size, as indexes in the weapon list above
    private final static HashMap<HullSize, Integer> ARC_MIN_RANGE_INDEX = new HashMap<>();
    private final static HashMap<HullSize, Integer> ARC_MAX_RANGE_INDEX = new HashMap<>();
    static {
        ARC_MIN_RANGE_INDEX.put(HullSize.FRIGATE, 0);
        ARC_MAX_RANGE_INDEX.put(HullSize.FRIGATE, 4);

        ARC_MIN_RANGE_INDEX.put(HullSize.DESTROYER, 0);
        ARC_MAX_RANGE_INDEX.put(HullSize.DESTROYER, 5);

        ARC_MIN_RANGE_INDEX.put(HullSize.CRUISER, 0);
        ARC_MAX_RANGE_INDEX.put(HullSize.CRUISER, 7);

        ARC_MIN_RANGE_INDEX.put(HullSize.CAPITAL_SHIP, 0);
        ARC_MAX_RANGE_INDEX.put(HullSize.CAPITAL_SHIP, 9);
    }

    //Maximum and minimum damage of arcs fired by the ship
    //Defined as a multiplier of the ship's death explosion damage: 0.1f = 10% of damage
    private final static float ARC_MAX_DAMAGE = 0.15f;
    private final static float ARC_MIN_DAMAGE = 0.05f;

    //Arc sizes and sound effects based on hullsize
    private final static HashMap<HullSize, Float> ARC_SIZES = new HashMap<>();
    private final static HashMap<HullSize, String> ARC_SOUNDS = new HashMap<>();
    static {
        ARC_SIZES.put(HullSize.FRIGATE, 9f);
        ARC_SOUNDS.put(HullSize.FRIGATE, "loa_high_death_arc");

        ARC_SIZES.put(HullSize.DESTROYER, 12f);
        ARC_SOUNDS.put(HullSize.DESTROYER, "loa_high_death_arc");

        ARC_SIZES.put(HullSize.CRUISER, 15f);
        ARC_SOUNDS.put(HullSize.CRUISER, "loa_high_death_arc");

        ARC_SIZES.put(HullSize.CAPITAL_SHIP, 18f);
        ARC_SOUNDS.put(HullSize.CAPITAL_SHIP, "loa_high_death_arc");
    }

    //Same as above, but for the final arc only. Also affects "effect particle" for final arc
    private final static HashMap<HullSize, Float> FINAL_ARC_SIZES = new HashMap<>();
    private final static HashMap<HullSize, String> FINAL_ARC_FIRE_SOUNDS = new HashMap<>();
    private final static HashMap<HullSize, String> FINAL_ARC_BOLT_SOUNDS = new HashMap<>();
    private final static HashMap<HullSize, Float> FINAL_ARC_PARTICLE_SIZE = new HashMap<>();
    private final static HashMap<HullSize, Float> FINAL_ARC_PARTICLE_DURATION = new HashMap<>();
    static {
        FINAL_ARC_SIZES.put(HullSize.FRIGATE, 100f);
        FINAL_ARC_FIRE_SOUNDS.put(HullSize.FRIGATE, "loa_high_death_arc_big_fire");
        FINAL_ARC_BOLT_SOUNDS.put(HullSize.FRIGATE, "loa_high_death_arc_big");
        FINAL_ARC_PARTICLE_SIZE.put(HullSize.FRIGATE, 70f);
        FINAL_ARC_PARTICLE_DURATION.put(HullSize.FRIGATE, 0.3f);

        FINAL_ARC_SIZES.put(HullSize.DESTROYER, 125f);
        FINAL_ARC_FIRE_SOUNDS.put(HullSize.DESTROYER, "loa_high_death_arc_big_fire");
        FINAL_ARC_BOLT_SOUNDS.put(HullSize.DESTROYER, "loa_high_death_arc_big");
        FINAL_ARC_PARTICLE_SIZE.put(HullSize.DESTROYER, 90f);
        FINAL_ARC_PARTICLE_DURATION.put(HullSize.DESTROYER, 0.4f);

        FINAL_ARC_SIZES.put(HullSize.CRUISER, 175f);
        FINAL_ARC_FIRE_SOUNDS.put(HullSize.CRUISER, "loa_high_death_arc_big_fire");
        FINAL_ARC_BOLT_SOUNDS.put(HullSize.CRUISER, "loa_high_death_arc_big");
        FINAL_ARC_PARTICLE_SIZE.put(HullSize.CRUISER, 110f);
        FINAL_ARC_PARTICLE_DURATION.put(HullSize.CRUISER, 0.5f);

        FINAL_ARC_SIZES.put(HullSize.CAPITAL_SHIP, 200f);
        FINAL_ARC_FIRE_SOUNDS.put(HullSize.CAPITAL_SHIP, "loa_high_death_arc_big_fire");
        FINAL_ARC_BOLT_SOUNDS.put(HullSize.CAPITAL_SHIP, "loa_high_death_arc_big");
        FINAL_ARC_PARTICLE_SIZE.put(HullSize.CAPITAL_SHIP, 130f);
        FINAL_ARC_PARTICLE_DURATION.put(HullSize.CAPITAL_SHIP, 0.6f);
    }

    //Color of all arcs (both core and fringe)
    private final static Color ARC_CORE_COLOR = new Color(150, 150, 255, 255);
    private final static Color ARC_FRINGE_COLOR = new Color(0, 50, 255, 255);

    //Color of the "effect particle" spawned to emphasize the last arc
    private final static Color FINAL_ARC_BLAST_COLOR = new Color(0, 50, 255, 255);


    // --- Other settings --- //

    //Chance for a ship to actually explode with this special effect
    private final static float EXPLOSION_CHANCE = 0.75f;

    //Prefix to look for when trying to find which ships are affected by this script
    private static final String PREFIX = "loaht_";

    //Blacklist of ship hull ids that will never trigger this effect
    private final static HashSet<String> BLACKLIST = new HashSet<>();
    static {
        BLACKLIST.add("DummyShipIDThatDoesNotExist");
    }

    //Duration configuration, based on hullsize, for the explosion delays/durations
    private final static HashMap<HullSize, Float> BASE_EXPLOSION_DELAYS = new HashMap<>();
    private final static HashMap<HullSize, Float> MAX_BONUS_EXPLOSION_DELAYS = new HashMap<>();
    private final static HashMap<HullSize, Float> BASE_EXPLOSION_DURATIONS = new HashMap<>();
    private final static HashMap<HullSize, Float> MAX_BONUS_EXPLOSION_DURATIONS = new HashMap<>();
    private final static HashMap<HullSize, Float> EXPLOSION_FADEOUT_DURATION = new HashMap<>();
    static {
        BASE_EXPLOSION_DELAYS.put(HullSize.FRIGATE, 6f);
        MAX_BONUS_EXPLOSION_DELAYS.put(HullSize.FRIGATE, 4f);
        BASE_EXPLOSION_DURATIONS.put(HullSize.FRIGATE, 5f);
        MAX_BONUS_EXPLOSION_DURATIONS.put(HullSize.FRIGATE, 2f);
        EXPLOSION_FADEOUT_DURATION.put(HullSize.FRIGATE, 0.5f);

        BASE_EXPLOSION_DELAYS.put(HullSize.DESTROYER, 8f);
        MAX_BONUS_EXPLOSION_DELAYS.put(HullSize.DESTROYER, 5f);
        BASE_EXPLOSION_DURATIONS.put(HullSize.DESTROYER, 6f);
        MAX_BONUS_EXPLOSION_DURATIONS.put(HullSize.DESTROYER, 3f);
        EXPLOSION_FADEOUT_DURATION.put(HullSize.DESTROYER, 0.5f);

        BASE_EXPLOSION_DELAYS.put(HullSize.CRUISER, 10f);
        MAX_BONUS_EXPLOSION_DELAYS.put(HullSize.CRUISER, 6f);
        BASE_EXPLOSION_DURATIONS.put(HullSize.CRUISER, 8f);
        MAX_BONUS_EXPLOSION_DURATIONS.put(HullSize.CRUISER, 3f);
        EXPLOSION_FADEOUT_DURATION.put(HullSize.CRUISER, 1f);

        BASE_EXPLOSION_DELAYS.put(HullSize.CAPITAL_SHIP, 12f);
        MAX_BONUS_EXPLOSION_DELAYS.put(HullSize.CAPITAL_SHIP, 7f);
        BASE_EXPLOSION_DURATIONS.put(HullSize.CAPITAL_SHIP, 10f);
        MAX_BONUS_EXPLOSION_DURATIONS.put(HullSize.CAPITAL_SHIP, 4f);
        EXPLOSION_FADEOUT_DURATION.put(HullSize.CAPITAL_SHIP, 1f);
    }

    //Degree of our general "parabolic function": at 2, for example, the curve is quadratic, while at 3 it's cubic.
    //1 is "linear" progression: lower means faster difference at low levels, higher means faster difference at high levels
    private static final float PARABOLA_DEGREE = 2f;

    //The loop sounds while charging up for an explosion, defined per hull size
    private final static HashMap<HullSize, String> CHARGEUP_LOOP_SOUNDS = new HashMap<>();
    static {
        CHARGEUP_LOOP_SOUNDS.put(HullSize.FRIGATE, "loa_high_death_charge");
        CHARGEUP_LOOP_SOUNDS.put(HullSize.DESTROYER, "loa_high_death_charge");
        CHARGEUP_LOOP_SOUNDS.put(HullSize.CRUISER, "loa_high_death_charge");
        CHARGEUP_LOOP_SOUNDS.put(HullSize.CAPITAL_SHIP, "loa_high_death_charge");
    }

    //Stats for the pitch and volume shift of the chargeup loop sounds
    //Defined as pairs with (start, end)
    private final static HashMap<HullSize, Pair<Float, Float>> CHARGEUP_PITCH_SHIFTS = new HashMap<>();
    private final static HashMap<HullSize, Pair<Float, Float>> CHARGEUP_VOLUME_SHIFTS = new HashMap<>();
    static {
        CHARGEUP_PITCH_SHIFTS.put(HullSize.FRIGATE, new Pair<>(0.7f, 1.3f));
        CHARGEUP_VOLUME_SHIFTS.put(HullSize.FRIGATE, new Pair<>(0f, 0.5f));

        CHARGEUP_PITCH_SHIFTS.put(HullSize.DESTROYER, new Pair<>(0.6f, 1.2f));
        CHARGEUP_VOLUME_SHIFTS.put(HullSize.DESTROYER, new Pair<>(0f, 0.6f));

        CHARGEUP_PITCH_SHIFTS.put(HullSize.CRUISER, new Pair<>(0.5f, 1.1f));
        CHARGEUP_VOLUME_SHIFTS.put(HullSize.CRUISER, new Pair<>(0f, 0.8f));

        CHARGEUP_PITCH_SHIFTS.put(HullSize.CAPITAL_SHIP, new Pair<>(0.4f, 1f));
        CHARGEUP_VOLUME_SHIFTS.put(HullSize.CAPITAL_SHIP, new Pair<>(0.2f, 1f));
    }

    //Prints various debug logs to the console when enabled
    private static final boolean DEBUG_MODE = true;


    // --- Internal variables : not config! --- //
    //Our current combat engine
    private CombatEngineAPI engine;

    //Our list of already-tracked ships
    private HashSet<String> alreadyTriggeredShips = new HashSet<>();

    @Override
    public void init(CombatEngineAPI engine) {
        if (engine == null) {
            return;
        }
        this.engine = engine;
    }
    
    //Main advance loop
    @Override
    public void advance(float amount, List<InputEventAPI> events) {
        //Never run without an engine instance or if we're paused
        if (engine == null || engine.isPaused()) {
            return;
        }

        //Check all ships: if they are a wreck, and not a piece, add our manager to them. If they *are* a piece, spawn harmless explosion
        //Ignore things with existing managers, an incorrect ID or anything that's a fighter. Also ignore stuff in our blacklist
        for (ShipAPI ship : engine.getShips()) {
            if (!ship.getHullSpec().getHullId().startsWith(PREFIX)) {
                continue;
            }
            if (ship.getHullSize().equals(HullSize.FIGHTER)) {
                continue;
            }
            if (alreadyTriggeredShips.contains(ship.getId())) {
                continue;
            }
            if (BLACKLIST.contains(ship.getHullSpec().getHullId())) {
                continue;
            }

            if (ship.isHulk()) {
                if (!ship.isPiece()) {
                    alreadyTriggeredShips.add(ship.getId());
                    if (Math.random() < EXPLOSION_CHANCE) {
                        new ExplodingShipTracker(ship, (float)Math.random(), (float)Math.random());
                        if (DEBUG_MODE) {
                            LOGGER.info("LoA Hightech ship " + ship.getName() + " rigged to explode");
                        }
                    } else {
                        if (DEBUG_MODE) {
                            LOGGER.info("LoA Hightech ship " + ship.getName() + " did not explode");
                        }
                    }
                } else {
                    alreadyTriggeredShips.add(ship.getId());
                    spawnHarmlessExplosion(ship);
                }
            }
        }
    }


    //Class for managing a single exploding ship
    private class ExplodingShipTracker extends BaseEveryFrameCombatPlugin {
        ShipAPI ship;
        DamagingExplosionSpec explodeSpec;
        float explodeDelayFactor;
        float explodeDurationFactor;
        boolean hasShotPrimaryLightning = false;

        float timer = 0f;
        int explosionStage = 1;

        private ExplodingShipTracker(ShipAPI ship, float explodeDelayFactor, float explodeDurationFactor) {
            this.ship = ship;
            this.explodeSpec = DamagingExplosionSpec.explosionSpecForShip(ship);
            ship.getMutableStats().getEnergyWeaponRangeBonus().unmodify(); //Needed to get correct ranges for lightning bolts later

            this.explodeDelayFactor = explodeDelayFactor;
            this.explodeDurationFactor = explodeDurationFactor;

            engine.addPlugin(this);
        }

        @Override
        public void advance(float amount, List<InputEventAPI> events) {
            if (engine.isPaused()) {
                return;
            }

            //If we've de-loaded from the engine or broken apart, stop all effects immediately and spawn a harmless explosion
            if (!engine.isEntityInPlay(ship) || ship.isPiece()) {
                spawnHarmlessExplosion(ship);
                engine.removePlugin(this);
                if (DEBUG_MODE) {
                    LOGGER.info("LoA Hightech ship " + ship.getName() + " disarmed prematurely");
                }
                return;
            }
            timer += amount;

            //First phase: dormant
            if (explosionStage == 1) {
                if (timer < BASE_EXPLOSION_DELAYS.get(ship.getHullSize()) + explodeDelayFactor*MAX_BONUS_EXPLOSION_DELAYS.get(ship.getHullSize())) {
                    return;
                } else {
                    explosionStage = 2;
                    timer = 0f;
                }
            }

            //Second phase: charging up for explosion
            if (explosionStage == 2) {
                if (timer < BASE_EXPLOSION_DURATIONS.get(ship.getHullSize()) + explodeDurationFactor*MAX_BONUS_EXPLOSION_DURATIONS.get(ship.getHullSize())) {
                    //Handle our particles and stuff based on progression of the phase
                    float progression = parabolize(timer / (BASE_EXPLOSION_DURATIONS.get(ship.getHullSize()) + explodeDurationFactor*MAX_BONUS_EXPLOSION_DURATIONS.get(ship.getHullSize())));
                    handleParticlesAndLightning(amount, progression);

                    //Also plays our loop sound
                    float pitch = Misc.interpolate(CHARGEUP_PITCH_SHIFTS.get(ship.getHullSize()).one,
                            CHARGEUP_PITCH_SHIFTS.get(ship.getHullSize()).two,
                            progression);
                    float volume = Misc.interpolate(CHARGEUP_VOLUME_SHIFTS.get(ship.getHullSize()).one,
                            CHARGEUP_VOLUME_SHIFTS.get(ship.getHullSize()).two,
                            progression);
                    Global.getSoundPlayer().playLoop(CHARGEUP_LOOP_SOUNDS.get(ship.getHullSize()), ship, pitch, volume,
                            new Vector2f(ship.getLocation()), ship.getVelocity());
                    return;
                } else {
                    explosionStage = 3;
                    timer = 0f;
                }
            }

            //Third phase: we're fading out our effect.
            if (explosionStage == 3) {
                if (timer < EXPLOSION_FADEOUT_DURATION.get(ship.getHullSize())) {
                    //If we haven't yet, trigger our "main" arc
                    if (!hasShotPrimaryLightning) {
                        hasShotPrimaryLightning = true;
                        Global.getSoundPlayer().playSound(FINAL_ARC_FIRE_SOUNDS.get(ship.getHullSize()), 1f, 1f,
                                ship.getLocation(), new Vector2f(0f, 0f));
                        if (DEBUG_MODE) {
                            LOGGER.info("LoA Hightech ship " + ship.getName() + " has shot its primary lightning");
                        }
                        spawnFinalThunderbolt(ship, explodeSpec.getMaxDamage());
                    }
                    if (DEBUG_MODE) {
                        LOGGER.info("LoA Hightech ship " + ship.getName() + " charging down");
                    }

                    //Handle our particles and stuff based on progression of the phase
                    float progression = parabolize(timer / EXPLOSION_FADEOUT_DURATION.get(ship.getHullSize()));
                    handleParticlesAndLightning(amount, progression);


                    //Also stop our loop sound: any desired sound is part of the final thunderbolt sound
                    //This is an ugly solution to bypass some vanilla sound mix behaviour
                    Global.getSoundPlayer().playLoop(CHARGEUP_LOOP_SOUNDS.get(ship.getHullSize()), ship, 1f,
                            0.00000001f, ship.getLocation(), ship.getVelocity());
                } else {
                    //We're done entirely: just remove ourselves
                    engine.removePlugin(this);
                    if (DEBUG_MODE) {
                        LOGGER.info("LoA Hightech ship " + ship.getName() + " has completed its detonation");
                    }
                }
            }
        }

        private void handleParticlesAndLightning(float amount, float progression) {
            //Spawns a random amount of particles somewhere on the ship
            float particlesExpectedThisFrame = amount * MINIEXPLOSION_AMOUNT_PER_SECOND * progression;
            while (Math.random() < particlesExpectedThisFrame) {
                particlesExpectedThisFrame--;

                //Creates a particle somewhere on the ship: tries five times to get a valid point, and gives up after that
                Vector2f spawnPos = MathUtils.getRandomPointInCircle(ship.getLocation(), ship.getCollisionRadius());
                int tries = 0;
                while (!CollisionUtils.isPointWithinBounds(spawnPos, ship) && tries < 5) {
                    tries++;
                    spawnPos = MathUtils.getRandomPointInCircle(ship.getLocation(), ship.getCollisionRadius());
                }
                if (CollisionUtils.isPointWithinBounds(spawnPos, ship)) {
                    engine.addHitParticle(spawnPos, ship.getVelocity(),
                            MathUtils.getRandomNumberInRange(MINIEXPLOSION_MIN_SIZE, MINIEXPLOSION_MAX_SIZE),
                            1f,MathUtils.getRandomNumberInRange(MINIEXPLOSION_MIN_DURATION, MINIEXPLOSION_MAX_DURATION),
                            MINIEXPLOSION_COLOR);
                    if (Math.random() < MINIEXPLOSION_SOUND_CHANCE) {
                        Global.getSoundPlayer().playSound(MINIEXPLOSION_SOUND, 1f, 1f, spawnPos, ship.getVelocity());
                    }
                }
            }

            //Spawns a random amount of arcs from the ship
            float arcsExpectedThisFrame = amount * ARC_AMOUNT_PER_SECOND * progression;
            while (Math.random() < arcsExpectedThisFrame) {
                arcsExpectedThisFrame--;
                spawnThunderbolt(ship, explodeSpec.getMaxDamage(), progression);
            }
        }
    }


    //Converts a 0-1 float interval according to our parabola formula
    private static float parabolize(float input) {
        return (float)Math.pow(input, PARABOLA_DEGREE);
    }

    //Spawns a "harmless" explosion on a ship
    private void spawnHarmlessExplosion(ShipAPI ship) {
        //Spawns a random amount of arcs from the ship
        float arcsExpected = MathUtils.getRandomNumberInRange(HARMLESS_EXPLOSION_ARC_MIN, HARMLESS_EXPLOSION_ARC_MAX);
        while (Math.random() < arcsExpected) {
            arcsExpected--;

            //Try to get a spawn point a couple of times: if it fails, discard this arc, it's not that important we have an exact number of them
            Vector2f originPoint = MathUtils.getRandomPointInCircle(ship.getLocation(), ship.getCollisionRadius());
            int tries = 0;
            while (!CollisionUtils.isPointWithinBounds(originPoint, ship) && tries < 5) {
                tries++;
                originPoint = MathUtils.getRandomPointInCircle(ship.getLocation(), ship.getCollisionRadius());
            }
            if (tries >= 5) {
                continue;
            }

            //Gets an angle to fire at
            Vector2f angularVector = VectorUtils.getDirectionalVector(ship.getLocation(), originPoint);
            angularVector.scale(MathUtils.getRandomNumberInRange(HARMLESS_ARC_MIN_RANGE, HARMLESS_ARC_MAX_RANGE));

            //And fire a harmless arc
            engine.spawnEmpArc(ship, originPoint, ship, new SimpleEntity(Vector2f.add(originPoint, angularVector, new Vector2f(0f,0f))),
                    DamageType.ENERGY,0f, 0f, 9999999f, null, ARC_SIZES.get(ship.getHullSize()),
                    ARC_FRINGE_COLOR, ARC_CORE_COLOR);
        }

        //...aaaaand play a sound
        Global.getSoundPlayer().playSound(HARMLESS_EXPLOSION_SOUNDS.get(ship.getHullSize()), 1f, 1f, ship.getLocation(), new Vector2f(0f, 0f));
    }

    //Spawns a single "thunderbolt" from a ship
    private void spawnThunderbolt(ShipAPI ship, float explosionDamage, float powerFactor) {
        //Try to get a spawn point a couple of times: if it fails, discard this shot
        Vector2f firePos = MathUtils.getRandomPointInCircle(ship.getLocation(), ship.getCollisionRadius());
        int tries = 0;
        while (!CollisionUtils.isPointWithinBounds(firePos, ship) && tries < 5) {
            tries++;
            firePos = MathUtils.getRandomPointInCircle(ship.getLocation(), ship.getCollisionRadius());
        }
        if (tries >= 5) {
            return;
        }

        //For range
        int weaponIndex = MathUtils.getRandomNumberInRange(ARC_MIN_RANGE_INDEX.get(ship.getHullSize()), ARC_MAX_RANGE_INDEX.get(ship.getHullSize()));

        //Gets an angle "away" from the ship's center
        float angle = VectorUtils.getAngle(ship.getLocation(), firePos);

        spawnThunderboltInternal(ship, Misc.interpolate(explosionDamage*ARC_MIN_DAMAGE, explosionDamage*ARC_MAX_DAMAGE, powerFactor),
                ARC_WEAPONS.get(weaponIndex), angle, firePos, ARC_SIZES.get(ship.getHullSize()), ARC_SOUNDS.get(ship.getHullSize()));
    }

    //Spawns the "final" thunderbolt from a ship
    private void spawnFinalThunderbolt(ShipAPI ship, float explosionDamage) {
        //Try to get a spawn point a couple of times: if it fails, spawn from our center
        Vector2f firePos = MathUtils.getRandomPointInCircle(ship.getLocation(), ship.getCollisionRadius());
        int tries = 0;
        while (!CollisionUtils.isPointWithinBounds(firePos, ship) && tries < 5) {
            tries++;
            firePos = MathUtils.getRandomPointInCircle(ship.getLocation(), ship.getCollisionRadius());
        }
        if (tries >= 5) {
            firePos = ship.getLocation();
        }

        //Gets the nearest ship to us (within a pretty respectable range) and gets an angle somewhat weighted towards it
        ShipAPI nearestTarget = null;
        for (ShipAPI other : CombatUtils.getShipsWithinRange(firePos, 2000f)) {
            if (nearestTarget == null
                    || MathUtils.getDistance(firePos, other.getLocation()) < MathUtils.getDistance(firePos, nearestTarget.getLocation())) {
                nearestTarget = other;
            }
        }

        //Get a random angle: if we had a nearest target, we use gaussian distribution towards it
        float angle = MathUtils.getRandomNumberInRange(0f, 360f);
        if (nearestTarget != null) {
            angle = VectorUtils.getAngle(firePos, nearestTarget.getLocation());
            Random rand = new Random();
            angle += 60f * rand.nextGaussian();
        }

        spawnThunderboltInternal(ship, explosionDamage, ARC_WEAPONS.get(ARC_MAX_RANGE_INDEX.get(ship.getHullSize())),
                angle, firePos, FINAL_ARC_SIZES.get(ship.getHullSize()), FINAL_ARC_BOLT_SOUNDS.get(ship.getHullSize()));

        //Addition: also spawn a neat little "effect particle" at our spawn point
        engine.addHitParticle(firePos, ship.getVelocity(), FINAL_ARC_PARTICLE_SIZE.get(ship.getHullSize()), 1f,
                FINAL_ARC_PARTICLE_DURATION.get(ship.getHullSize()), FINAL_ARC_BLAST_COLOR);
    }

    //Internal thunderbolt spawning implementation
    private void spawnThunderboltInternal(ShipAPI ship, float damage, String weaponID, float fireAngle, Vector2f firePos,
                                          float size, String soundId) {
        //Spawn our projectile, correct its damage, apply our tracker...
        DamagingProjectileAPI proj = (DamagingProjectileAPI) engine.spawnProjectile(ship, null, weaponID, firePos,
                                                                                    fireAngle, new Vector2f(0f, 0f));
        proj.setFromMissile(true); //AI shenanigans
        proj.setDamageAmount(damage);

        engine.addPlugin(new ThunderboltTracker(proj, ship, firePos, size, soundId));
    }


    //Internal class for keeping track of a single "arc-spawning" projectile
    private class ThunderboltTracker extends BaseEveryFrameCombatPlugin {
        DamagingProjectileAPI proj;
        ShipAPI ship;
        Vector2f spawnPosRelative;
        float shipStartingAngle;
        float size;
        String soundID;

        ThunderboltTracker(DamagingProjectileAPI proj, ShipAPI ship, Vector2f spawnPos, float size, String soundID) {
            this.proj = proj;
            this.ship = ship;
            this.spawnPosRelative = Vector2f.sub(spawnPos, ship.getLocation(), new Vector2f(0f, 0f));
            this.shipStartingAngle = ship.getFacing();
            this.size = size;
            this.soundID = soundID;
        }

        @Override
        public void advance(float amount, List<InputEventAPI> events) {
            //Quietly remove us and the projectile if our source ship is no more
            if (!engine.isEntityInPlay(ship)) {
                engine.removeEntity(proj);
                engine.removePlugin(this);
            }

            //If the projectile has hit something, or despawned on its own, spawn a deco arc and play a sound!
            if (proj.didDamage() || !engine.isEntityInPlay(proj)) {
                Vector2f originPoint = getOriginPos();
                engine.spawnEmpArc(ship, originPoint, ship, new SimpleEntity(proj.getLocation()), DamageType.ENERGY,
                        0f, 0f, 9999999f, null, size,
                        ARC_FRINGE_COLOR, ARC_CORE_COLOR);
                Global.getSoundPlayer().playSound(soundID, 1f, 1f, proj.getLocation(), new Vector2f(0f, 0f));

                engine.removePlugin(this);
            }
        }

        //Gets the position we originated from, backwards-calculated from where we spawned and rotated to fit new ship location
        private Vector2f getOriginPos() {
            Vector2f rotated = VectorUtils.rotate(spawnPosRelative, ship.getFacing() - shipStartingAngle);
            return Vector2f.add(rotated, ship.getLocation(), new Vector2f(0f, 0f));
        }
    }
}
