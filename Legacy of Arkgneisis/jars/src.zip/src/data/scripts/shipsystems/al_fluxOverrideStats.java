package data.scripts.shipsystems;
 
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.WeaponAPI;
import com.fs.starfarer.api.impl.combat.BaseShipSystemScript;
import com.fs.starfarer.api.plugins.ShipSystemStatsScript;
import java.awt.Color;
 
public class al_fluxOverrideStats extends BaseShipSystemScript
{
    private static final float PULSATION_FACTOR = 0.1f;
    private static final float PULSATION_PERIOD = 3f;
    private float currentVisualIntensity = 0f;
    private boolean hasRun = false;
    private boolean hasStopped = false;
    private ShipAPI ship;
 
    @Override
public void apply(MutableShipStatsAPI stats, String id, State state, float effectLevel)
    {
        ship = (ShipAPI) stats.getEntity();
        if (ship == null)
        {
            return;
        }
        float intensity = (float) Math.pow(0.85, (ship.getSystem().getMaxAmmo() - ship.getSystem().getAmmo()) - 1);
 
 
        float visualIntensity = Math.min(currentVisualIntensity
                * (1f + (float) Math.sin(Global.getCombatEngine().getTotalElapsedTime(true) * (2f * Math.PI) / PULSATION_PERIOD) * PULSATION_FACTOR), 1f);
 
        WeaponAPI glowDeco = null;
        for (WeaponAPI weapon : ship.getAllWeapons())
        {
            if (weapon.getId().endsWith("_glow") && weapon.getId().startsWith("al_"))
            {
                glowDeco = weapon;
            }
        }
 
        ship.setJitter(ship, Color.RED, visualIntensity / 30f, 6, 30f);
        ship.setJitterUnder(ship, Color.RED, visualIntensity / 8f, 10, 50f);
        if (glowDeco != null && glowDeco.getAnimation() != null)
        {
            glowDeco.getSprite().setAdditiveBlend();
            glowDeco.getAnimation().setAlphaMult(visualIntensity);
            glowDeco.getAnimation().setFrame(1);
        }
 
        if (!hasRun)
        {
            hasRun = true;
            Global.getSoundPlayer().playSound("al_bullpup_fire", 0.9f + intensity * 0.1f, 0.5f + intensity * 0.5f,
                    ship.getLocation(), ship.getVelocity());
        }
        else
        {
            Global.getSoundPlayer().playLoop("al_tacscan_loop", ship, 0.9f + intensity * 0.1f, (0.5f + intensity * 0.5f) * effectLevel,
                    ship.getLocation(), ship.getVelocity());
        }
        if (state == ShipSystemStatsScript.State.OUT && !hasStopped)
        {
            hasStopped = true;
            Global.getSoundPlayer().playSound("al_beampunch_hit", 0.9f + intensity * 0.1f, 0.5f + intensity * 0.5f,
                    ship.getLocation(), ship.getVelocity());
        }
    }
 
    @Override
    public ShipSystemStatsScript.StatusData getStatusData(int index, ShipSystemStatsScript.State state, float effectLevel)
    {
        if (ship != null)
        {
            float intensity = (float) Math.pow(0.85, (ship.getSystem().getMaxAmmo() - ship.getSystem().getAmmo()) - 1);
            if (index == 0)
            {
                return new ShipSystemStatsScript.StatusData("+" + (int) (60f * intensity * effectLevel) + "% flux dissipation", false);
            }
        }
        return null;
    }
 
    @Override
    public void unapply(MutableShipStatsAPI stats, String id)
    {
        ship = (ShipAPI) stats.getEntity();
        if (ship == null)
        {
            return;
        }
 
        currentVisualIntensity = 0f;
        hasRun = false;
        hasStopped = false;
 
        WeaponAPI glowDeco = null;
        for (WeaponAPI weapon : ship.getAllWeapons())
        {
            if (weapon.getId().endsWith("_glow") && weapon.getId().startsWith("al_"))
            {
                glowDeco = weapon;
            }
        }
 
        if (glowDeco != null)
        {
            glowDeco.getAnimation().setFrame(0);
        }
    }
}