//By Nicke535, spawns a projectile behind a ship, which is then tracked by a special plugin to become an EMP bomb
package data.scripts.shipsystems;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.*;
import com.fs.starfarer.api.fleet.FleetMemberType;
import com.fs.starfarer.api.impl.combat.BaseShipSystemScript;
import com.fs.starfarer.api.loading.WeaponSlotAPI;
import com.fs.starfarer.api.mission.FleetSide;
import data.scripts.plugins.al_empcore_plugin;
import org.lazywizard.lazylib.MathUtils;
import org.lazywizard.lazylib.VectorUtils;
import org.lazywizard.lazylib.combat.CombatUtils;
import org.lazywizard.lazylib.combat.entities.SimpleEntity;
import com.fs.starfarer.api.util.Misc;
import org.lwjgl.util.vector.Vector2f;

import java.awt.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class al_empcore extends BaseShipSystemScript {
    //The weapon ID for the "fake weapon" we fire our projectile with. This can vary by hullsize, so it gets different power depending on target size
    private final static Map<ShipAPI.HullSize, String> WEAPON_ID_MAP = new HashMap<ShipAPI.HullSize, String>();
    static {
        WEAPON_ID_MAP.put(ShipAPI.HullSize.FIGHTER, "al_empcore_frigate");
        WEAPON_ID_MAP.put(ShipAPI.HullSize.FRIGATE, "al_empcore_frigate");
        WEAPON_ID_MAP.put(ShipAPI.HullSize.DESTROYER, "al_empcore_destroyer");
        WEAPON_ID_MAP.put(ShipAPI.HullSize.CRUISER, "al_empcore_cruiser");
        WEAPON_ID_MAP.put(ShipAPI.HullSize.CAPITAL_SHIP, "al_empcore_capital");
    }

    //The maximum range we can activate the system at
    private final static float  MAX_RANGE = 1600f;

    //How far away the projectile is spawned (this is then increased by the targeted ship's collision radius)
    // This should be about as far away as the projectile would travel in its lifetime; a 100 speed projectile which lasts 4 seconds would set this to around 400
    private final static float SPAWN_RANGE = 150f;

    //Percentage of enemy ship speed that the projectile travels at; 0.7 equals 70%
    private final static Map<ShipAPI.HullSize, Float> PROJ_SPEED_PERCENTAGES = new HashMap<ShipAPI.HullSize, Float>();
    static {
    PROJ_SPEED_PERCENTAGES.put(ShipAPI.HullSize.FIGHTER, 0.9f);
    PROJ_SPEED_PERCENTAGES.put(ShipAPI.HullSize.FRIGATE, 0.5f);
    PROJ_SPEED_PERCENTAGES.put(ShipAPI.HullSize.DESTROYER, 0.6f);
    PROJ_SPEED_PERCENTAGES.put(ShipAPI.HullSize.CRUISER, 0.7f);
    PROJ_SPEED_PERCENTAGES.put(ShipAPI.HullSize.CAPITAL_SHIP, 0.8f);
    }

    //VISUALS AND SOUND EFFECTS:
    private static final float BOLT_CHANCE = 0.05f;                                //The chance each frame that a small decorative lightning bolt is spawned from a system slot. This scales with effectLevel
    private static final Color BOLT_COLOR = new Color(0, 100, 255);         //The color of the small decorative lighting bolts (this is then blended with a pure white core)
    private static final float BOLT_MAX_RANGE = 200f;                               //The longest length a decorative lightning bolt can have
    private static final float BOLT_MIN_RANGE = 50f;                               //The shortest length a decorative lightning bolt can have
    private static final String ACTIVATION_SOUND = "al_empcore_charge";     //Plays once the projectile is spawned
    private static final String BOLT_SOUND = "al_emoverload_zap";            //Plays each time we spawn a small decorative lightning bolt
    private static final String DROP_SOUND = "al_empcore_shutdown";           //Plays once the projectile is detonated for any reason
    
    //Script-used
    private ShipAPI target = null;
    private boolean hasTriggered = false;
    private DamagingProjectileAPI proj = null;

    //Function for enabling/disabling system use
    @Override
    public boolean isUsable(ShipSystemAPI system, ShipAPI ship) {
        //Can't use our system if we have no valid target, or our target is out of range
        if (ship.getShipTarget() == null || ship.getShipTarget().getOwner() == ship.getOwner()) {
            return false;
        }
        if (MathUtils.getDistance(ship.getShipTarget(), ship.getLocation()) > MAX_RANGE) {
            return false;
        }
        //On fallthrough, use default implementation
        return super.isUsable(system, ship);
    }

    //Function to describe our system's current status
    @Override
    public String getInfoText(ShipSystemAPI system, ShipAPI ship) {
        //Can't use our system if we have no valid target, or our target is out of range
        if (ship.getShipTarget() == null) {
            return "NO TARGET";
        }
        if (ship.getShipTarget().getOwner() == ship.getOwner()) {
            return "INVALID TARGET";
        }
        if (MathUtils.getDistance(ship.getShipTarget(), ship.getLocation()) > MAX_RANGE) {
            return "OUT OF RANGE";
        }
        //On fallthrough, use default implementation
        return super.getInfoText(system, ship);
    }

    //Main apply loop
    public void apply(MutableShipStatsAPI stats, String id, State state, float effectLevel) {
        //Don't run when paused
        if (Global.getCombatEngine().isPaused()) {
            return;
        }

        //Ensures we have a ship
        ShipAPI ship = null;
        boolean player = false;
        if (stats.getEntity() instanceof ShipAPI) {
            ship = (ShipAPI) stats.getEntity();
            player = ship == Global.getCombatEngine().getPlayerShip();
            id = id + "_" + ship.getId();
        } else {
            return;
        }

        //If our system is on, we lock our ship target in place, start spawning visual effects, and spawns a projectile if we haven't already
        if (effectLevel > 0f) {
            //Locks target
            if (target == null) {
                target = ship.getShipTarget();
            }

            //Visual effects depending on charge level: spawn small energy bolts from all system weapon slots
            for (WeaponSlotAPI slot : ship.getHullSpec().getAllWeaponSlotsCopy()) {
                if (slot.isSystemSlot()) {
                    //Check our random number to see if we will spawn a bolt this frame
                    if (Math.random() < BOLT_CHANCE * effectLevel) {
                        //Gets a random point in a cone in front of our weapon slot
                        Vector2f targetPoint = MathUtils.getPointOnCircumference(slot.computePosition(ship), MathUtils.getRandomNumberInRange(BOLT_MIN_RANGE, BOLT_MAX_RANGE), slot.getAngle() + ship.getFacing() + MathUtils.getRandomNumberInRange(-slot.getArc()/2f, slot.getArc()/2f));

                        //Spawns a fake entity so we can target it with the bolt
                        CombatEntityAPI targetEntity = new SimpleEntity(targetPoint);

                                                //NEW: has a 30% chance to target the projectile itself, instead of the fake entity (if the projectile is within the proper arc, of course)
                        if (Math.random() < 0.3f) {
                            //Checks if the projectile is within the slot's arc
                            if (Misc.getAngleInDegrees(slot.computePosition(ship), proj.getLocation()) >= slot.getAngle() + ship.getFacing() - slot.getArc()/2f
                                    && Misc.getAngleInDegrees(slot.computePosition(ship), proj.getLocation()) <= slot.getAngle() + ship.getFacing() + slot.getArc()/2f) {
                                targetEntity = proj;
                                //Increase EMP resistance if the projectile is a missile, so the projectile doesn't flame-out from the fake lightning
                                if (proj instanceof MissileAPI) {
                                    ((MissileAPI) proj).setEmpResistance(((MissileAPI) proj).getEmpResistance() + 1);
                                }
                            }
                        }
                        
                        //And then spawns the bolt itself
                        Global.getCombatEngine().spawnEmpArc(ship, slot.computePosition(ship), ship, targetEntity,
                                DamageType.ENERGY, //Damage type
                                0f, //Damage
                                0f, //Emp
                                100000f, //Max range
                                BOLT_SOUND, //Impact sound
                                MathUtils.getRandomNumberInRange(7f, 11f) * (float)Math.sqrt(effectLevel), // thickness of the lightning bolt
                                new Color(255, 255, 255), //Central color
                                BOLT_COLOR); //Fringe Color

                        //Fix for how vanilla culls EMP arc sounds
                        Global.getSoundPlayer().playSound(BOLT_SOUND, 1f, 1f, slot.computePosition(ship), ship.getVelocity());
                    }
                }
            }

            //If we haven't fired yet, fire!
            if (!hasTriggered) {
                hasTriggered = true;

                //Decides which weapon ID we fire with
                String weaponID = WEAPON_ID_MAP.get(target.getHullSize());

                //Gets a point slightly behind our current target
                Vector2f spawnPoint = MathUtils.getPointOnCircumference(target.getLocation(), target.getCollisionRadius()+SPAWN_RANGE, target.getFacing()+180f);

                //Spawns a projectile at said point, and adds it to our plugin
                DamagingProjectileAPI newProj = (DamagingProjectileAPI)Global.getCombatEngine().spawnProjectile(ship, null, weaponID, spawnPoint, target.getFacing(), target.getVelocity());
                al_empcore_plugin.startTrackingProjectile(newProj, target, target.getMutableStats().getMaxSpeed().getModifiedValue()*PROJ_SPEED_PERCENTAGES.get(target.getHullSize()));

                //Stores the projectile, so we know if it disappears
                proj = newProj;

                //Plays a sound to indicate that we have spawned the projectile
                Global.getSoundPlayer().playSound(ACTIVATION_SOUND, 1f, 1f, ship.getLocation(), ship.getVelocity());
            }
        }

        //If our projectile is gone, and our system is active, we immediately turn off the system
        if (effectLevel > 0f && (state.equals(State.ACTIVE) || state.equals(State.IN)) && (proj.didDamage() || proj.getHitpoints() <= 0f || proj.getCollisionClass().equals(CollisionClass.NONE))) {
            ship.getSystem().deactivate();
        }

        //If our system is off, run unapply() once
        if (effectLevel <= 0f && hasTriggered) {
            unapply(stats, id);
        }
    }

    //Fixes variables
    public void unapply(MutableShipStatsAPI stats, String id) {
        ShipAPI ship = null;
        boolean player = false;
        if (stats.getEntity() instanceof ShipAPI) {
            ship = (ShipAPI) stats.getEntity();
            player = ship == Global.getCombatEngine().getPlayerShip();
            id = id + "_" + ship.getId();
        } else {
            return;
        }

        hasTriggered = false;
        target = null;
                //Plays a ship-side sound for detonating the charge
        Global.getSoundPlayer().playSound(DROP_SOUND, 1f, 1f, ship.getLocation(), ship.getVelocity());
    }

    public StatusData getStatusData(int index, State state, float effectLevel) {
        if (index == 0 && effectLevel > 0f && !state.equals(State.OUT)) {
            return new StatusData("manipulating enemy drive pulse", false);
        }
        return null;
    }
}