package data.scripts.shipsystems;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.*;
import com.fs.starfarer.api.graphics.SpriteAPI;
import com.fs.starfarer.api.impl.combat.BaseShipSystemScript;
import com.fs.starfarer.api.input.InputEventAPI;
import org.lazywizard.lazylib.MathUtils;
import org.lwjgl.util.vector.Vector2f;

import java.awt.*;
import java.util.*;
import java.util.List;

public class loa_awacs extends BaseShipSystemScript {
    //The range at which the AOE benefits are applied
	public static final float ACTIVE_RANGE = 1250f;

	//The three different "staged" bonuses for all nearby ships, as multipliers (1.3f means 30% extra range and so on)
    public static final Map<ShipAPI.HullSize, Float> STAGE_1_RANGE_MULTS = new HashMap<>();
    static {
        STAGE_1_RANGE_MULTS.put(ShipAPI.HullSize.FIGHTER, 1f);
        STAGE_1_RANGE_MULTS.put(ShipAPI.HullSize.FRIGATE, 1.1f);
        STAGE_1_RANGE_MULTS.put(ShipAPI.HullSize.DESTROYER, 1.1f);
        STAGE_1_RANGE_MULTS.put(ShipAPI.HullSize.CRUISER, 1.05f);
        STAGE_1_RANGE_MULTS.put(ShipAPI.HullSize.CAPITAL_SHIP, 1.05f);
    }
    public static final Map<ShipAPI.HullSize, Float> STAGE_2_RANGE_MULTS = new HashMap<>();
    static {
        STAGE_2_RANGE_MULTS.put(ShipAPI.HullSize.FIGHTER, 1f);
        STAGE_2_RANGE_MULTS.put(ShipAPI.HullSize.FRIGATE, 1.2f);
        STAGE_2_RANGE_MULTS.put(ShipAPI.HullSize.DESTROYER, 1.15f);
        STAGE_2_RANGE_MULTS.put(ShipAPI.HullSize.CRUISER, 1.1f);
        STAGE_2_RANGE_MULTS.put(ShipAPI.HullSize.CAPITAL_SHIP, 1.1f);
    }
    public static final Map<ShipAPI.HullSize, Float> STAGE_3_RANGE_MULTS = new HashMap<>();
    static {
        STAGE_3_RANGE_MULTS.put(ShipAPI.HullSize.FIGHTER, 1f);
        STAGE_3_RANGE_MULTS.put(ShipAPI.HullSize.FRIGATE, 1.3f);
        STAGE_3_RANGE_MULTS.put(ShipAPI.HullSize.DESTROYER, 1.2f);
        STAGE_3_RANGE_MULTS.put(ShipAPI.HullSize.CRUISER, 1.15f);
        STAGE_3_RANGE_MULTS.put(ShipAPI.HullSize.CAPITAL_SHIP, 1.1f);
    }

    //The active time in seconds required to reach stage 2/3, respectively
    public static final float STAGE_2_DELAY = 30f;
    public static final float STAGE_3_DELAY = 90f;

    //The sound to play when reaching stage 2/3, respectively
    private static final String STAGE_2_SOUND = "loa_awacs_2";
    private static final String STAGE_3_SOUND = "loa_awacs_3";

    //The "ping" sound of the system
    private static final String PING_SOUND = "loa_awacs_ping";

    //How often "pings" appear from the system
    private static final float PING_DELAY = 5f;

    //The duration a "ping" lasts
    private static final float PING_DURATION = 2f;

    //The jitter to apply to the ring's size each frame. Does not affect system range at all
    private static final float SIZE_JITTER_MIN = -2f;
    private static final float SIZE_JITTER_MAX = 2f;

    //The color to use for circle/ping at each of the three stages
    private static final Color STAGE_1_COLOR = new Color(150, 150, 150);
    private static final Color STAGE_2_COLOR = new Color(125, 200, 125);
    private static final Color STAGE_3_COLOR = new Color(100, 175, 255);

    //Color jitter to apply randomly each frame on the circle (but not the ping)
    private static final int COLOR_JITTER_MIN = -50;
    private static final int COLOR_JITTER_MAX = 50;

    //The opacity of the "ring" each stage (1f = opaque, 0f = transparent)
    private static final float STAGE_1_RING_OPACITY = 0.15f;
    private static final float STAGE_2_RING_OPACITY = 0.2f;
    private static final float STAGE_3_RING_OPACITY = 0.25f;

    //Opacity jitter to apply randomly each frame on the circle (but not the ping)
    private static final float OPACITY_JITTER_MIN = -0.01f;
    private static final float OPACITY_JITTER_MAX = 0.01f;

    //The max/min opacity of the "ping" each stage
    private static final float STAGE_1_PING_MAX_OPACITY = 0.3f;
    private static final float STAGE_1_PING_MIN_OPACITY = 0f;
    private static final float STAGE_2_PING_MAX_OPACITY = 0.5f;
    private static final float STAGE_2_PING_MIN_OPACITY = 0f;
    private static final float STAGE_3_PING_MAX_OPACITY = 0.7f;
    private static final float STAGE_3_PING_MIN_OPACITY = 0f;

    //The path to the sprite displayed in the side-bar when the system is used and the player is affected
    private static final String SIDE_BAR_ICON_PATH = "graphics/icons/hullsys/drone_sensor.png";

    //The name of the stat used to track which bonus level we're at. Just keep it unique and everything should work out fine
    public static final String TRACKER_STAT_ID = "LOA_TRACKER_STAT_ID";

    //ID for the bonus stat; same as above, can be anything as long as it's unique
    public static final String BONUS_ID = "LOA_AWACS_BONUS_ID";

    //In-script variables
    private float pingCounter = 0f;
    private float pingActiveCounter = 0f;
    private float activeCounter = 0f;
    private int highestStageReached = 1;
    private AwacsRenderData pingRenderData = null;
    private AwacsRenderData ringRenderData = null;
    private InternalAwacsRenderPlugin renderer = null;

    public void apply(MutableShipStatsAPI stats, String id, State state, float effectLevel) {
        ShipAPI ship = null;
        if (stats.getEntity() instanceof ShipAPI) {
            ship = (ShipAPI) stats.getEntity();
            id = id + "_" + ship.getId();
        } else {
            return;
        }

        //If we're active, ensure we have a renderer in play
        if (renderer == null) {
            renderer = new InternalAwacsRenderPlugin(this);
            Global.getCombatEngine().addPlugin(renderer);
        }

        //The sprite to draw as "area circle"
        SpriteAPI CIRCLE_SPRITE = Global.getSettings().getSprite("loa_combat", "loa_pingcircle");

        //The sprite to draw as "sensor ping"
        SpriteAPI PING_SPRITE = Global.getSettings().getSprite("loa_combat", "loa_pingcircle");

        //Ticks our counters
        activeCounter += Global.getCombatEngine().getElapsedInLastFrame() * ship.getMutableStats().getTimeMult().getModifiedValue();
        pingCounter += Global.getCombatEngine().getElapsedInLastFrame() * ship.getMutableStats().getTimeMult().getModifiedValue();

        //Triggers a ping if appropriate
        if (pingCounter > PING_DELAY) {
            pingCounter -= PING_DELAY;
            pingActiveCounter += Global.getCombatEngine().getElapsedInLastFrame() * ship.getMutableStats().getTimeMult().getModifiedValue();
            Global.getSoundPlayer().playSound(PING_SOUND, 1f, 1f, ship.getLocation(), ship.getVelocity());
        } else if (pingActiveCounter > 0f) {
            pingActiveCounter += Global.getCombatEngine().getElapsedInLastFrame() * ship.getMutableStats().getTimeMult().getModifiedValue();
        }

        //Removes existing ping if appropriate
        if (pingActiveCounter >= PING_DURATION) {
            pingActiveCounter = 0f;
        }

        //Change effects depending on current stage. Also play a sound the first time we reach a certain stage
        Color baseColorThisStage = STAGE_1_COLOR;
        float ringOpacityThisStage = STAGE_1_RING_OPACITY;
        float pingOpacityMaxThisStage = STAGE_1_PING_MAX_OPACITY;
        float pingOpacityMinThisStage = STAGE_1_PING_MIN_OPACITY;
        if (activeCounter > STAGE_3_DELAY) {
            baseColorThisStage = STAGE_3_COLOR;
            ringOpacityThisStage = STAGE_3_RING_OPACITY;
            pingOpacityMaxThisStage = STAGE_3_PING_MAX_OPACITY;
            pingOpacityMinThisStage = STAGE_3_PING_MIN_OPACITY;
            if (highestStageReached < 3) {
                Global.getSoundPlayer().playSound(STAGE_3_SOUND, 1f, 1f, ship.getLocation(), ship.getVelocity());
                highestStageReached = 3;
            }
        } else if (activeCounter > STAGE_2_DELAY) {
            baseColorThisStage = STAGE_2_COLOR;
            ringOpacityThisStage = STAGE_2_RING_OPACITY;
            pingOpacityMaxThisStage = STAGE_2_PING_MAX_OPACITY;
            pingOpacityMinThisStage = STAGE_2_PING_MIN_OPACITY;
            if (highestStageReached < 2) {
                Global.getSoundPlayer().playSound(STAGE_2_SOUND, 1f, 1f, ship.getLocation(), ship.getVelocity());
                highestStageReached = 2;
            }
        }
        Color actualRingColorThisFrame = new Color (Math.min(255f, (float)baseColorThisStage.getRed() + MathUtils.getRandomNumberInRange(COLOR_JITTER_MIN, COLOR_JITTER_MAX))/255f,
                Math.min(255f, (float)baseColorThisStage.getGreen() + MathUtils.getRandomNumberInRange(COLOR_JITTER_MIN, COLOR_JITTER_MAX))/255f,
                Math.min(255f, (float)baseColorThisStage.getBlue() + MathUtils.getRandomNumberInRange(COLOR_JITTER_MIN, COLOR_JITTER_MAX))/255f,
                Math.min(1f, ringOpacityThisStage + MathUtils.getRandomNumberInRange(OPACITY_JITTER_MIN, OPACITY_JITTER_MAX)) * effectLevel);

        //Always render our effect circle
        ringRenderData = new AwacsRenderData(actualRingColorThisFrame, new Vector2f(ship.getLocation()),
                ACTIVE_RANGE * 2f + MathUtils.getRandomNumberInRange(SIZE_JITTER_MIN, SIZE_JITTER_MAX), CIRCLE_SPRITE);

        //If we have an active ping, render that too
        if (pingActiveCounter > 0f) {
            Color actualPingColorThisFrame = new Color (((float)baseColorThisStage.getRed())/255f,
                    ((float)baseColorThisStage.getGreen())/255f,
                    ((float)baseColorThisStage.getBlue())/255f,
                    (pingOpacityMaxThisStage * ((PING_DURATION-pingActiveCounter)/PING_DURATION) + pingOpacityMinThisStage * (pingActiveCounter/PING_DURATION)) * effectLevel);
            float pingSizeThisFrame = (ACTIVE_RANGE * 3f) * (pingActiveCounter/PING_DURATION);
            pingRenderData = new AwacsRenderData(actualPingColorThisFrame, new Vector2f(ship.getLocation()), pingSizeThisFrame, PING_SPRITE);
        } else {
            pingRenderData = null;
        }

        //Give ourselves a tracker stat telling our plugin (loa_awacs_bonus_applier_plugin) what level we've reached
        ship.getMutableStats().getDynamic().getStat(TRACKER_STAT_ID + "_1").modifyFlat(id, 500f);
        if (highestStageReached >= 2) {
            ship.getMutableStats().getDynamic().getStat(TRACKER_STAT_ID + "_2").modifyFlat(id, 500f);
        }
        if (highestStageReached >= 3) {
            ship.getMutableStats().getDynamic().getStat(TRACKER_STAT_ID + "_3").modifyFlat(id, 500f);
        }
    }


    public void unapply(MutableShipStatsAPI stats, String id) {
        ShipAPI ship = null;
        if (stats.getEntity() instanceof ShipAPI) {
            ship = (ShipAPI) stats.getEntity();
            id = id + "_" + ship.getId();
        } else {
            return;
        }

        //Resets variables
        highestStageReached = 1;
        activeCounter = 0f;
        pingCounter = 0f;
        pingActiveCounter = 0f;
        ringRenderData = null;
        pingRenderData = null;
        Global.getCombatEngine().removePlugin(renderer);
        renderer = null;
		
        //Set our current bonus level to 0 by removing all our tracker stats
        ship.getMutableStats().getDynamic().getStat(TRACKER_STAT_ID + "_1").unmodify(id);
        ship.getMutableStats().getDynamic().getStat(TRACKER_STAT_ID + "_2").unmodify(id);
        ship.getMutableStats().getDynamic().getStat(TRACKER_STAT_ID + "_3").unmodify(id);
    }

    public StatusData getStatusData(int index, State state, float effectLevel) {
        if (index == 0) {
            return new StatusData("AWACS Active : Stage " + Math.round(highestStageReached), false);
        }
        return null;
    }

    //Internal class for keeping track of render data
    class AwacsRenderData {
        Color colorThisFrame;
        Vector2f positionThisFrame;
        float sizeThisFrame;
        SpriteAPI spriteToRender;

        AwacsRenderData(Color colorThisFrame, Vector2f positionThisFrame, float sizeThisFrame, SpriteAPI spriteToRender) {
            this.colorThisFrame = colorThisFrame;
            this.positionThisFrame = positionThisFrame;
            this.sizeThisFrame = sizeThisFrame;
            this.spriteToRender = spriteToRender;
        }
    }

    //Internal class for managing rendering
    class InternalAwacsRenderPlugin extends BaseEveryFrameCombatPlugin {
        //Keep track of its parent script, so we know when we need to stop/disappear and how to render stuff
        loa_awacs parentScript = null;

        InternalAwacsRenderPlugin(loa_awacs parentScript) {
            this.parentScript = parentScript;
        }

        @Override
        public void advance(float amount, List<InputEventAPI> events)
        {
            if (parentScript.pingRenderData == null && parentScript.ringRenderData == null) {
                if (Global.getCombatEngine() != null) {
                    parentScript.renderer = null;
                    Global.getCombatEngine().removePlugin(this);
                }
            }
        }

        @Override
        public void renderInWorldCoords(ViewportAPI viewport)
        {
            if (Global.getCombatEngine() == null)
            {
                return;
            }

            //Ring render
            if (parentScript.ringRenderData != null) {
                SpriteAPI spriteToRender = parentScript.ringRenderData.spriteToRender;
                spriteToRender.setAngle(0f);
                spriteToRender.setSize(parentScript.ringRenderData.sizeThisFrame, parentScript.ringRenderData.sizeThisFrame);
                spriteToRender.setColor(parentScript.ringRenderData.colorThisFrame);
                spriteToRender.renderAtCenter(parentScript.ringRenderData.positionThisFrame.x, parentScript.ringRenderData.positionThisFrame.y);
            }

            //Ping render
            if (parentScript.pingRenderData != null) {
                SpriteAPI spriteToRender = parentScript.pingRenderData.spriteToRender;
                spriteToRender.setAngle(0f);
                spriteToRender.setSize(parentScript.pingRenderData.sizeThisFrame, parentScript.pingRenderData.sizeThisFrame);
                spriteToRender.setColor(parentScript.pingRenderData.colorThisFrame);
                spriteToRender.renderAtCenter(parentScript.pingRenderData.positionThisFrame.x, parentScript.pingRenderData.positionThisFrame.y);
            }
        }
    }
}