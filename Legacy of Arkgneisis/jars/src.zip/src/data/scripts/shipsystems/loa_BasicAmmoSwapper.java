package data.scripts.shipsystems;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipSystemAPI;
import com.fs.starfarer.api.combat.WeaponAPI;
import com.fs.starfarer.api.impl.combat.BaseShipSystemScript;

import java.awt.*;
import java.util.HashSet;

/**
 * Used in tandem with special weapons to act as a "Shell Swapper"
 * Can be overriden for more unique swap effects
 * @author Nicke535
 */
public class loa_BasicAmmoSwapper extends BaseShipSystemScript {
    //Internal variables
    private int actualAmmo = 1;
    private boolean runOnce = true;

    //Always display the currently loaded shell type
    @Override
    public String getInfoText(ShipSystemAPI system, ShipAPI ship) {
        if (system.getAmmo() == 1) {
            return "KE Mode";
        } else {
            return "HE Mode";
        }
    }

    @Override
    public void apply(MutableShipStatsAPI stats, String id, State state, float effectLevel) {
        if (stats.getEntity() != null && stats.getEntity() instanceof ShipAPI) {
            ShipAPI ship = (ShipAPI)stats.getEntity();

            if (ship.getSystem().getAmmo() != actualAmmo) {
                ship.getSystem().setAmmo(actualAmmo);
            }

            if (state == State.IN) {
                if (runOnce) {
                    runOnce = false;
                    if (actualAmmo >= 2) {
                        actualAmmo = 1;
                    } else {
                        actualAmmo = 2;
                    }
                }

                //Tell weapons to wait with firing until the ammo switching is complete
                //The weapons need their own scripts to keep track of this (for animation support)
                Global.getCombatEngine().getCustomData().put("loa_AmmoSwapperSwapTimeRemaining" + ship.getId(), (1f-effectLevel)*ship.getSystem().getChargeUpDur());
            } else {
                runOnce = true;
                Global.getCombatEngine().getCustomData().put("loa_AmmoSwapperSwapTimeRemaining" + ship.getId(), 0f);
            }
        }
    }

    public StatusData getStatusData(int index, State state, float effectLevel) {
        return null;
    }
}