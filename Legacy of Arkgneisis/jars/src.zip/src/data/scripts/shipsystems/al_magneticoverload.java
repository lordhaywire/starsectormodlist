//By Nicke535, a modified version of the Burndrive script which fires EMP arcs at anything that gets too close
package data.scripts.shipsystems;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.*;
import com.fs.starfarer.api.impl.combat.BaseShipSystemScript;
import com.fs.starfarer.api.loading.WeaponSlotAPI;
import com.fs.starfarer.api.plugins.ShipSystemStatsScript;
import org.lazywizard.lazylib.MathUtils;
import org.lazywizard.lazylib.VectorUtils;
import org.lazywizard.lazylib.combat.CombatUtils;
import org.lazywizard.lazylib.combat.entities.SimpleEntity;
import org.lwjgl.util.vector.Vector2f;


public class al_magneticoverload extends BaseShipSystemScript {

    //Actual gameplay configurations: adjusts the system's behaviour

    public static float LIGHTNING_DAMAGE = 100f;
    public static float LIGHTNING_EMP_DAMAGE = 200f;
    public static float LIGHTNING_RANGE = 500f;
    public static float ACCELERATION_MULT = 3f;
    public static float LIGHTNING_CHANCE_PER_SECOND_AND_MOUNT = 0.75f;

    public static float MAX_SPEED_INCREASE = 125f;

    //Visual config: change some visual parameters
    public static Color ENGINE_COLOR = new Color(100, 170, 255);
    public static Color LIGHTNING_COLOR = new Color(100, 170, 255);
    public static boolean FAR_PROPAGATION = false;

    public void apply(MutableShipStatsAPI stats, String id, State state, float effectLevel) {
        ShipAPI ship = null;
        boolean player = false;
        if (stats.getEntity() instanceof ShipAPI) {
            ship = (ShipAPI) stats.getEntity();
            player = ship == Global.getCombatEngine().getPlayerShip();
            id = id + "_" + ship.getId();
        } else {
            return;
        }

        ship.getEngineController().fadeToOtherColor(this, ENGINE_COLOR, ENGINE_COLOR, 1.0f, 1.0f);

        for (WeaponSlotAPI weaponSlotAPI : ship.getHullSpec().getAllWeaponSlotsCopy()) {
            //Only care about system slots
            if (!weaponSlotAPI.isSystemSlot()) {
                continue;
            }

            //Do we send out lightning this frame? If not, skip to next mount
            if (Math.pow((1f - LIGHTNING_CHANCE_PER_SECOND_AND_MOUNT), Global.getCombatEngine().getElapsedInLastFrame()) >= (Math.random() * effectLevel)) {
                continue;
            }

            //Get our weapon slot's position
            Vector2f point = weaponSlotAPI.computePosition(ship);

            CombatEntityAPI targetEntity = null;
            List<ShipAPI> shipsWithinRange = CombatUtils.getShipsWithinRange(point, LIGHTNING_RANGE);
            List<CombatEntityAPI> removeList = new ArrayList<CombatEntityAPI>();
                       for (ShipAPI testShip : shipsWithinRange) {
                if (testShip.getOwner() == ship.getOwner() || testShip.isPhased() || testShip.getCollisionClass().equals(CollisionClass.NONE)) {
                    removeList.add(testShip);
                }
            }
            List<MissileAPI> missilesWithinRange = CombatUtils.getMissilesWithinRange(point, LIGHTNING_RANGE);
            for (MissileAPI testMissile : missilesWithinRange) {
                if (testMissile.getOwner() == ship.getOwner() || testMissile.getCollisionClass().equals(CollisionClass.NONE)) {
                    removeList.add(testMissile);
                }
            }

            for (CombatEntityAPI removeThing : removeList) {
                if (shipsWithinRange.contains(removeThing)) {
                    shipsWithinRange.remove(removeThing);
                }
                if (missilesWithinRange.contains(removeThing)) {
                    missilesWithinRange.remove(removeThing);
                }
            }


            //Targeting: find which missile/ship we want to hit
            //(the damage nuller is for if we don't find a target)
            float damageNuller = 1f;
            if (missilesWithinRange.isEmpty() && shipsWithinRange.isEmpty()) {
                damageNuller = 0f;

                //Checks if we want random propagation or self-discharge as a visual indicator when no enemies are in range
                if (FAR_PROPAGATION) {
                    targetEntity = new SimpleEntity(MathUtils.getRandomPointOnCircumference(point, LIGHTNING_RANGE));
                } else {
                    targetEntity = ship;
                }
            } else if (!missilesWithinRange.isEmpty() && (shipsWithinRange.isEmpty() || MathUtils.getRandomNumberInRange(0, missilesWithinRange.size() + shipsWithinRange.size()) < missilesWithinRange.size())) {
                targetEntity = (CombatEntityAPI)missilesWithinRange.get(MathUtils.getRandomNumberInRange(0, missilesWithinRange.size()-1));
            } else {
                targetEntity = (CombatEntityAPI)shipsWithinRange.get(MathUtils.getRandomNumberInRange(0, shipsWithinRange.size()-1));
            }

            Global.getCombatEngine().spawnEmpArc(ship, point, ship, targetEntity,
                    DamageType.ENERGY, //Damage type
                    LIGHTNING_DAMAGE * damageNuller, //Damage
                    LIGHTNING_EMP_DAMAGE * damageNuller, //Emp
                    100000f, //Max range
                    "al_emoverload_zap", //Impact sound
                    MathUtils.getRandomNumberInRange(15f, 18f), // thickness of the lightning bolt
                    new Color(255, 255, 255), //Central color
                    LIGHTNING_COLOR //Fringe Color
            );
        }

        float level = effectLevel;
        
        //Burndrive-related code
        if (state == State.OUT) {
            stats.getMaxSpeed().unmodify(id);
        } else {
            stats.getMaxSpeed().modifyFlat(id, MAX_SPEED_INCREASE * effectLevel);
            stats.getAcceleration().modifyMult(id,1f + (ACCELERATION_MULT-1f)*level);
            stats.getDeceleration().modifyMult(id,1f + (ACCELERATION_MULT-1f)*level);
        }
    }


    public void unapply(MutableShipStatsAPI stats, String id) {
        ShipAPI ship = null;
        boolean player = false;
        if (stats.getEntity() instanceof ShipAPI) {
            ship = (ShipAPI) stats.getEntity();
            player = ship == Global.getCombatEngine().getPlayerShip();
            id = id + "_" + ship.getId();
        } else {
            return;
        }

        stats.getMaxSpeed().unmodify(id);
        stats.getAcceleration().unmodify(id);
        stats.getDeceleration().unmodify(id);
    }

    public StatusData getStatusData(int index, State state, float effectLevel) {
        if (index == 0) {
            return new StatusData("all power to thrusters", false);
        }
		if (index == 1) {
			return new StatusData("engaging bolt emitters", false);
		}
        return null;
    }
}