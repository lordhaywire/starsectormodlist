//By Nicke535, adapted from the MineStrikeStats script by Alex
package data.scripts.shipsystems;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;

import com.fs.starfarer.api.combat.*;
import com.fs.starfarer.api.impl.combat.BaseShipSystemScript;
import com.fs.starfarer.api.impl.combat.MineStrikeStatsAIInfoProvider;
import com.fs.starfarer.api.loading.WeaponSlotAPI;
import org.lazywizard.lazylib.MathUtils;
import org.lazywizard.lazylib.VectorUtils;
import org.lazywizard.lazylib.combat.entities.SimpleEntity;
import org.lwjgl.util.vector.Vector2f;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.ShipSystemAPI.SystemState;
import com.fs.starfarer.api.combat.ShipwideAIFlags.AIFlags;
import com.fs.starfarer.api.input.InputEventAPI;
import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.api.util.WeightedRandomPicker;
import org.lazywizard.lazylib.CollisionUtils;
import org.lazywizard.lazylib.combat.CombatUtils;

public class loa_alastairsweb2stats extends BaseShipSystemScript implements MineStrikeStatsAIInfoProvider {
	//The weapon ID of the mine weapon in weapon_data.csv
	private static final String MINE_WEAPON_ID = "loa_webmine";

	//Range of the minelayer
	private static final float MINE_RANGE = 1600f;

	//Minimum distance a mine will spawn from a target
	private static final float MIN_SPAWN_DIST = 120f;

	//How long the mine will move around before stopping for the last stage of detonation.
	private static final float MOVING_TIME = 7f;

	//How long the mine will "live" after arming (but before detonating)
	private static final float ARMED_TIME = 3f;

	//The size of the EMP AoE applied when the projectile explodes. Should ideally match up with the mine's AoE in the .proj file
	private static final float EMP_DAMAGE_AOE = 250f;

	//The amount of "extra" EMP damage to deal, since the vanilla mines can't deal EMP damage apparently
	private static final float EMP_EXTRA_DAMAGE = 500f;

	//The sound the system makes when placing a mine
	private static final String MINE_PLACE_SOUND = "loa_hightech_zap";

	//The loop sounds for mines
	private static final String MINE_LOOP_SOUND = "al_empcore_loop";

	//The loop sound for the ship itself, plays as long as any mine is active
	private static final String SHIP_LOOP_SOUND = "al_empcore_loop_2";

	//The sound the EMP bolts make
	private static final String BOLT_SOUND = "al_emoverload_zap";

	//The center color of EMP bolts spawned by this script
	private static final Color BOLT_CENTER_COLOR = new Color(100, 175, 255, 255);

	//The fringe color of EMP bolts spawned by this script
	private static final Color BOLT_COLOR = new Color(0, 50, 255, 120);

	//A list of all weapon slot IDs that shoot fake EMP bolts at the mines intermittently
	private static final List<String> BOLT_SOURCES_MINE = new ArrayList<>();
	static {
		BOLT_SOURCES_MINE.add("farzap01");
		BOLT_SOURCES_MINE.add("farzap02");
                BOLT_SOURCES_MINE.add("farzap03");
                BOLT_SOURCES_MINE.add("farzap04");
	}

	//A list of all weapon slot IDs that shoot fake EMP bolts at a fixed distance intermittently
	//	This "fixed distance" is equal to the arc of the weapon slot
	private static final List<String> BOLT_SOURCES_STATIC = new ArrayList<>();
	static {
		BOLT_SOURCES_STATIC.add("nearzap01");
		BOLT_SOURCES_STATIC.add("nearzap02");
                BOLT_SOURCES_STATIC.add("nearzap03");
                BOLT_SOURCES_STATIC.add("nearzap04");
	}

	//How large of a chance, per frame and weapon slot, is there of an EMP bolt being fired at a mine?
	private static final float BOLT_MINESTRIKE_CHANCE = 1f / 50f;

	//How large of a chance, per frame and weapon slot, is there of an EMP bolt being fired across our static bolt locations?
	private static final float BOLT_STATIC_CHANCE = 1f / 50f;


	//---  VISUALS FOR MINE   ---//

	//The maximum and minimum size of the mine's glow; the actual glow will be a random value between these multiplied
	//by the mine's lifetime; after half the mine's life, the mine has a size between half of these values, for example
	private static final float VIS_MINE_GLOW_SIZE_MAX = 300f;
	private static final float VIS_MINE_GLOW_SIZE_MIN = 100f;

	//The maximum and minimum lifetime of any given glow particle on the mine. Should be larger than the delay between particles
	private static final float VIS_MINE_GLOW_DURATION_MAX = 0.20f;
	private static final float VIS_MINE_GLOW_DURATION_MIN = 0.10f;

	//The maximum and minimum delay between particles spawning on the mine
	private static final float VIS_MINE_GLOW_SPAWNDELAY_MAX = 0.08f;
	private static final float VIS_MINE_GLOW_SPAWNDELAY_MIN = 0.03f;

	//The color of the mine's glow
	private static final Color VIS_MINE_GLOW_COLOR = new Color(75, 150, 255, 255);

	//The maximum and minimum distances "passive" EMP arcs spawn from the mine. Multiplied by the mine's "charge level"
	private static final float VIS_MINE_ARC_DISTANCE_MAX = 200f;
	private static final float VIS_MINE_ARC_DISTANCE_MIN = 70f;

	//The maximum and minimum delay between decorative EMP arcs spawning on the mine, *at 0 lifetime spent*: it goes
	//up the longer it has existed, finally reaching VIS_MINE_ARC_SPAWNDELAY_MAX/MIN_END. Note that anytime the mine takes
	//damage, an arc is also spawned.
	private static final float VIS_MINE_ARC_SPAWNDELAY_MAX_START = 0.72f;
	private static final float VIS_MINE_ARC_SPAWNDELAY_MIN_START = 0.4f;

	//The maximum and minimum delay between decorative EMP arcs spawning on the mine, *at maximum lifetime spent*: it
	//starts at VIS_MINE_ARC_SPAWNDELAY_MAX/MIN_START, increasing over time. Note that anytime the mine takes damage,
	//an arc is also spawned.
	private static final float VIS_MINE_ARC_SPAWNDELAY_MAX_END = 0.1f;
	private static final float VIS_MINE_ARC_SPAWNDELAY_MIN_END = 0.05f;

	//How close/far away the mine can spawn electrical arcs when exploding properly
	private static final float VIS_MINE_EXPLODE_ARC_DISTANCE_MAX = 260f;
	private static final float VIS_MINE_EXPLODE_ARC_DISTANCE_MIN = 50f;

	//How many arcs are spawned when the mine detonates? A random number between these two is chosen for each mine
	private static final float VIS_MINE_EXPLODE_ARC_COUNT_MAX = 15f;
	private static final float VIS_MINE_EXPLODE_ARC_COUNT_MIN = 10f;

	//--- END OF MINE VISUALS ---//


	//SCRIPT-REQUIRED VARIABLES
	List<MissileAPI> activeMines = new ArrayList<>(); //List for all mines currently deployed by the system


	//Returns how long the fuse of the mine is, IE how long it takes before the mine is allowed to explode.
	//For us, this should be the mine's entire lifetime, since we don't want premature detonations
	public float getFuseTime() {
		return ARMED_TIME + MOVING_TIME;
	}

	//Needed by the API nowadays
	public float getMineRange(ShipAPI ship) {return MINE_RANGE;}


	//Main apply function
	public void apply(MutableShipStatsAPI stats, String id, State state, float effectLevel) {
		//Gets the ship
		ShipAPI ship = null;
		if (stats.getEntity() instanceof ShipAPI) {
			ship = (ShipAPI) stats.getEntity();
		} else {
			return;
		}

		//Always run secondary visuals, as long as any mines are active
		if (!activeMines.isEmpty()) {
			//Play our loop sound
			Global.getSoundPlayer().playLoop(SHIP_LOOP_SOUND, ship, 1f, 1f, ship.getLocation(), ship.getVelocity());

			//Checks for our random mine-striking bolts
			for (String slotID : BOLT_SOURCES_MINE) {
				if (Math.random() < BOLT_MINESTRIKE_CHANCE) {
					//Checks all mines in the list to see if they are valid; if none are valid, don't fire a bolt after all
					WeaponSlotAPI slot = ship.getHullSpec().getWeaponSlotAPI(slotID);
					if (slot == null) { continue; }
					List<MissileAPI> validTargets = new ArrayList<>();
					for (MissileAPI possibleTarget : activeMines) {
						if (Misc.isInArc(slot.getAngle()+ship.getFacing(), slot.getArc(), VectorUtils.getAngle(slot.computePosition(ship), possibleTarget.getLocation()))) {
							validTargets.add(possibleTarget);
						}
					}

					//Choose a random valid target, if there is any
					if (validTargets.isEmpty()) {
						continue;
					}
					MissileAPI target = validTargets.get(MathUtils.getRandomNumberInRange(0, validTargets.size()-1));

					//Don't do anything if we somehow got a nullpointer
					if (target != null) {
						//Spawns a fake entity so we can target it with the bolt
						CombatEntityAPI targetEntity = new SimpleEntity(new Vector2f(target.getLocation()));

						//And then spawns the bolt itself
						Global.getCombatEngine().spawnEmpArc(ship, slot.computePosition(ship), ship, targetEntity,
								DamageType.ENERGY, //Damage type
								0f, //Damage
								0f, //Emp
								100000f, //Max range
								BOLT_SOUND, //Impact sound
								MathUtils.getRandomNumberInRange(6f, 9f), // thickness of the lightning bolt
								BOLT_CENTER_COLOR, //Central color
								BOLT_COLOR); //Fringe Color

						//Fix for how vanilla culls EMP arc sounds
						Global.getSoundPlayer().playSound(BOLT_SOUND, 1f, 1f, ship.getLocation(), ship.getVelocity());
					}
				}
			}

			//Checks for our random "static" bolts, IE fixed-distance bolts
			for (String slotID : BOLT_SOURCES_STATIC) {
				if (Math.random() < BOLT_STATIC_CHANCE) {
					//Gets our weapon slot
					WeaponSlotAPI slot = ship.getHullSpec().getWeaponSlotAPI(slotID);

					//Don't do anything if we somehow got a nullpointer
					if (slot != null) {
						//Gets the target point for the bolt
						Vector2f targetPoint = MathUtils.getPoint(slot.computePosition(ship), slot.getArc(), slot.getAngle()+ship.getFacing());

						//Spawns a fake entity so we can target it with the bolt
						CombatEntityAPI targetEntity = new SimpleEntity(targetPoint);

						//And then spawns the bolt itself
						Global.getCombatEngine().spawnEmpArc(ship, slot.computePosition(ship), ship, targetEntity,
								DamageType.ENERGY, //Damage type
								0f, //Damage
								0f, //Emp
								100000f, //Max range
								BOLT_SOUND, //Impact sound
								MathUtils.getRandomNumberInRange(6f, 9f), // thickness of the lightning bolt
								BOLT_CENTER_COLOR, //Central color
								BOLT_COLOR); //Fringe Color

						//Fix for how vanilla culls EMP arc sounds
						Global.getSoundPlayer().playSound(BOLT_SOUND, 1f, 1f, ship.getLocation(), ship.getVelocity());
					}
				}
			}
		}

		if (state != State.IN && effectLevel >= 1) {
			//Gets our system target point; first, check the mouse target and any eventual flag-based target
			Vector2f target = ship.getMouseTarget();
			if (ship.getShipAI() != null && ship.getAIFlags().hasFlag(AIFlags.SYSTEM_TARGET_COORDS)){
				target = (Vector2f) ship.getAIFlags().getCustom(AIFlags.SYSTEM_TARGET_COORDS);
			}

			//If we have a target, we do some vanilla math to determine where we want to drop the mine
			if (target != null) {
				float dist = Misc.getDistance(ship.getLocation(), target);
				float max = getMaxRange(ship) + ship.getCollisionRadius();
				if (dist > max) {
					float dir = Misc.getAngleInDegrees(ship.getLocation(), target);
					target = Misc.getUnitVectorAtDegreeAngle(dir);
					target.scale(max);
					Vector2f.add(target, ship.getLocation(), target);
				}

				target = findClearLocation(ship, target);

				if (target != null) {
					spawnMine(ship, target);
				}
			}

		}
	}


	//Unapply function: never runs
	public void unapply(MutableShipStatsAPI stats, String id) {
	}


	//Function for actually spawning a "mine"
	public void spawnMine(ShipAPI source, Vector2f mineLoc) {
		//Vanilla mine spawning checks and math. Essentially, find a nice location which doesn't have mines too close
		CombatEngineAPI engine = Global.getCombatEngine();
		Vector2f currLoc = Misc.getPointAtRadius(mineLoc, 30f + (float) Math.random() * 30f);
		float start = (float) Math.random() * 360f;
		for (float angle = start; angle < start + 390; angle += 30f) {
			if (angle != start) {
				Vector2f loc = Misc.getUnitVectorAtDegreeAngle(angle);
				loc.scale(50f + (float) Math.random() * 30f);
				currLoc = Vector2f.add(mineLoc, loc, new Vector2f());
			}
			for (MissileAPI other : Global.getCombatEngine().getMissiles()) {
				if (!other.isMine()) continue;

				float dist = Misc.getDistance(currLoc, other.getLocation());
				if (dist < other.getCollisionRadius() + 40f) {
					currLoc = null;
					break;
				}
			}
			if (currLoc != null) {
				break;
			}
		}
		if (currLoc == null) {
			currLoc = Misc.getPointAtRadius(mineLoc, 30f + (float) Math.random() * 30f);
		}

		//Spawn us the "mine", at the location we selected earlier
		MissileAPI mine = (MissileAPI) engine.spawnProjectile(source, null,
				MINE_WEAPON_ID,
				currLoc,
				(float) Math.random() * 360f, null);

		//Starts tracking the mine as an active mine
		activeMines.add(mine);

		//"Fades in" the mine. Can be very short for us, since our visuals are a bit different than vanilla mines
		float fadeInTime = 0.1f;
		mine.getVelocity().scale(0);
		mine.fadeOutThenIn(fadeInTime);

		//Adjusts the mine's lifetime, so it detonates at the right time
		float liveTime = MOVING_TIME + ARMED_TIME;
		mine.setFlightTime(mine.getMaxFlightTime()-MOVING_TIME);
		mine.setUntilMineExplosion(liveTime);

		//Tracks extra mine effects, such as visuals and EMP arcs
		Global.getCombatEngine().addPlugin(handleAlistairFakeMinePlugin(engine, mine, ARMED_TIME, this));

		//Sound for spawning a "mine"
		Global.getSoundPlayer().playSound(MINE_PLACE_SOUND, 1f, 1f, mine.getLocation(), mine.getVelocity());
	}


	//An everyframeplugin added to handle each individual mine's effects
	protected EveryFrameCombatPlugin handleAlistairFakeMinePlugin(final CombatEngineAPI engine, final MissileAPI mine, final float expectedArmTime, final loa_alastairsweb2stats originScript) {
		return new BaseEveryFrameCombatPlugin() {
			//Timer for elapsed time
			float elapsed = 0f;

			//Timer for elapsed time *while armed*
			float elapsedArmed = 0f;

			//Counts when the next particle is supposed to spawn
			float nextParticleSpawnElapsed = 0f;

			//Counts when the next arc is supposed to spawn
			float nextArcSpawnElapsed = 0f;

			//The health the mine had the last frame
			float lastMineHealth = mine.getHitpoints();

			@Override
			public void advance(float amount, List<InputEventAPI> events) {
				//Advance the timer
				if (Global.getCombatEngine().isPaused()) return;
				elapsed += amount;

				//If we are armed, also advance the "armed" timer
				if (mine.isMinePrimed()) {
					elapsedArmed += amount;
				}

				//If the mine is dead, remove it completely: it has simply fizzled out due to damage
				if (mine.getHitpoints() <= 0f) {
					originScript.activeMines.remove(mine);
					Global.getCombatEngine().removePlugin(this);
					return;
				}

				//Shorthand for "charge level" of the mine
				float chargeLevel = Math.max(0.2f, Math.min(1f, elapsedArmed/expectedArmTime));

				//Once the mine has dissapeared (wihtout dying to damage), detonate it visually (the actual damage and
				//stuff is handled vanilla-like by the projectile, except EMP) and remove the tracker entirely
				if (!engine.isEntityInPlay(mine)) {
					originScript.activeMines.remove(mine);
					handleMineDetonation();
					Global.getCombatEngine().removePlugin(this);
					return;
				}

				//Spawns visual particles at the mine's location, so that it can be seen charging
				if (elapsed >= nextParticleSpawnElapsed) {
					engine.addSmoothParticle(mine.getLocation(), mine.getVelocity(),
							chargeLevel * MathUtils.getRandomNumberInRange(VIS_MINE_GLOW_SIZE_MIN, VIS_MINE_GLOW_SIZE_MAX),
							MathUtils.getRandomNumberInRange(0.98f, 1f),
							MathUtils.getRandomNumberInRange(VIS_MINE_GLOW_DURATION_MIN, VIS_MINE_GLOW_DURATION_MAX),
							VIS_MINE_GLOW_COLOR);
					nextParticleSpawnElapsed += MathUtils.getRandomNumberInRange(VIS_MINE_GLOW_SPAWNDELAY_MIN, VIS_MINE_GLOW_SPAWNDELAY_MAX);
				}

				//Spawns a visual arc near the mine to indicate that it's charging, or that it has been damaged
				if (elapsed >= nextArcSpawnElapsed || mine.getHitpoints() < lastMineHealth) {
					//Picks a random "nearby" point
					Vector2f targetPoint = MathUtils.getPointOnCircumference(mine.getLocation(),
							MathUtils.getRandomNumberInRange(VIS_MINE_ARC_DISTANCE_MIN*chargeLevel, VIS_MINE_ARC_DISTANCE_MAX*chargeLevel),
							MathUtils.getRandomNumberInRange(0f, 360f));

					//Spawns a fake entity so we can target it with the bolt
					CombatEntityAPI targetEntity = new SimpleEntity(targetPoint);

					//And then spawns the bolt itself
					Global.getCombatEngine().spawnEmpArc(mine.getSource(), mine.getLocation(), mine, targetEntity,
							DamageType.ENERGY, //Damage type
							0f, //Damage
							0f, //Emp
							100000f, //Max range
							BOLT_SOUND, //Impact sound
							MathUtils.getRandomNumberInRange(7f, 10f) * (float)Math.sqrt(chargeLevel), // thickness of the lightning bolt
							BOLT_CENTER_COLOR, //Central color
							BOLT_COLOR); //Fringe Color

					//Fix for how vanilla culls EMP arc sounds
					Global.getSoundPlayer().playSound(BOLT_SOUND, 1f, 1f, mine.getLocation(), mine.getVelocity());

					//Sets the cooldown for the next arc
					nextArcSpawnElapsed = elapsed + MathUtils.getRandomNumberInRange(VIS_MINE_ARC_SPAWNDELAY_MIN_START *(1f-chargeLevel) + VIS_MINE_ARC_SPAWNDELAY_MIN_END *chargeLevel,
							VIS_MINE_ARC_SPAWNDELAY_MAX_START *(1f-chargeLevel) + VIS_MINE_ARC_SPAWNDELAY_MAX_END *chargeLevel);
				}

				//Plays a loop sound while the mine is alive
				Global.getSoundPlayer().playLoop(MINE_LOOP_SOUND, mine, chargeLevel, chargeLevel, mine.getLocation(), mine.getVelocity());

				//Stores how much health the mine has, so it can detect getting shot
				lastMineHealth = mine.getHitpoints();
			}

			//Handles the "explosion" of the mine, when it ends charging but wasn't shot down
			private void handleMineDetonation () {
				//Spawn a bunch of EMP arcs
				float arcCount = MathUtils.getRandomNumberInRange(VIS_MINE_EXPLODE_ARC_COUNT_MIN, VIS_MINE_EXPLODE_ARC_COUNT_MAX);
				for (int i = 0; i < arcCount; i++) {
					//Picks a random "nearby" point
					Vector2f targetPoint = MathUtils.getPointOnCircumference(mine.getLocation(),
							MathUtils.getRandomNumberInRange(VIS_MINE_EXPLODE_ARC_DISTANCE_MIN, VIS_MINE_EXPLODE_ARC_DISTANCE_MAX),
							MathUtils.getRandomNumberInRange(0f, 360f));

					//Spawns a fake entity so we can target it with the bolt
					CombatEntityAPI targetEntity = new SimpleEntity(targetPoint);

					//And then spawns the bolt itself
					Global.getCombatEngine().spawnEmpArc(mine.getSource(), mine.getLocation(), mine, targetEntity,
							DamageType.ENERGY, //Damage type
							0f, //Damage
							0f, //Emp
							100000f, //Max range
							BOLT_SOUND, //Impact sound
							MathUtils.getRandomNumberInRange(7f, 10f), // thickness of the lightning bolt
							BOLT_CENTER_COLOR, //Central color
							BOLT_COLOR); //Fringe Color
				}

				//Simulate EMP AoE, since vanilla doesn't handle it properly
				List<ShipAPI> targetList = new ArrayList<ShipAPI>();
				for (ShipAPI temp : CombatUtils.getShipsWithinRange(mine.getLocation(), EMP_DAMAGE_AOE)) {
					//Ignore ships that are untargetable
					if (temp.isPhased() || temp.getCollisionClass().equals(CollisionClass.NONE)) {
						continue;
					}

					targetList.add(temp);
				}
				handleEMPAoE (targetList,mine,1f,EMP_EXTRA_DAMAGE,EMP_DAMAGE_AOE);

				//...and the arc sound, of course
				Global.getSoundPlayer().playSound(BOLT_SOUND, 1f, 1f, mine.getLocation(), mine.getVelocity());
			}
		};
	}


	//Function to simplify adding the new code, this handles the AoE part of the EMP bomb for all targets
	private void handleEMPAoE (List<ShipAPI> targets, DamagingProjectileAPI proj, float damage, float emp, float range) {
		//Runs once per target
		for (ShipAPI target : targets) {
			//To simulate our AoE, we apply the damage each 0.5 degrees in a radial pattern from our projectile. Should *both* these "collision rays" miss, we stop the calculations
			float currentAngleOffset = 0f;
			float angleToTarget = VectorUtils.getAngle(proj.getLocation(), target.getLocation());

			//Never go more than 180 degrees in either direction, that's a full lap!
			boolean missedLastTime = false;
			while (currentAngleOffset < 180f) {
				//Makes it easier to write angles later
				float angleRight = (float)Math.toRadians(angleToTarget+currentAngleOffset);
				float angleLeft = (float)Math.toRadians(angleToTarget-currentAngleOffset);

				//Gets our right-side checker point
				Vector2f checkerPointRight = new Vector2f(proj.getLocation().x+(float)(Math.cos(angleRight)*range), proj.getLocation().y+(float)(Math.sin(angleRight)*range));

				//Gets where we collide with the target
				Vector2f hitPointRight = CollisionUtils.getCollisionPoint(proj.getLocation(), checkerPointRight, target);

				//If this one is a miss, skip its damage application and log that
				boolean rightMiss = false;
				if (hitPointRight != null) {
					missedLastTime = false;

					//This was apparently a hit; apply EMP damage at the point we hit (don't ignore shields!)
					Global.getCombatEngine().applyDamage(target, hitPointRight, damage, DamageType.ENERGY, emp, false, true, proj.getSource(), false);
				} else {
					rightMiss = true;
				}

				//Gets our left-side checker point
				Vector2f checkerPointLeft = new Vector2f(proj.getLocation().x+(float)(Math.cos(angleLeft)*range), proj.getLocation().y+(float)(Math.sin(angleLeft)*range));

				//Gets where we collide with the target
				Vector2f hitPointLeft = CollisionUtils.getCollisionPoint(proj.getLocation(), checkerPointLeft, target);

				//If this one is a miss, skip its damage application: if the right side was *also* a miss, we log that we missed entirely this time. If this happens *twice* in a row, we stop hit calculations
				if (hitPointLeft != null) {
					missedLastTime = false;

					//This was apparently a hit; apply EMP damage at the point we hit (don't ignore shields!)
					Global.getCombatEngine().applyDamage(target, hitPointLeft, damage, DamageType.ENERGY, emp, false, true, proj.getSource(), false);
				} else {
					if (rightMiss) {
						if (missedLastTime) {
							break;
						} else {
							missedLastTime = true;
						}
					}
				}

				//Iterate up our angle
				currentAngleOffset += 0.5f;
			}
		}
	}


	//For AI: returns the maximum range to activate at
	protected float getMaxRange(ShipAPI ship) {
		return getMineRange(ship);
	}


	//Returns info text
	@Override
	public String getInfoText(ShipSystemAPI system, ShipAPI ship) {
		if (system.isOutOfAmmo()) return null;
		if (system.getState() != SystemState.IDLE) return null;

		Vector2f target = ship.getMouseTarget();
		if (target != null) {
			float dist = Misc.getDistance(ship.getLocation(), target);
			float max = getMaxRange(ship) + ship.getCollisionRadius();
			if (dist > max) {
				return "OUT OF RANGE";
			} else {
				return "READY";
			}
		}
		return null;
	}


	//Determines if a shipsystem is usable
	@Override
	public boolean isUsable(ShipSystemAPI system, ShipAPI ship) {
		return ship.getMouseTarget() != null;
	}


	//Some vanilla math to get a non-occuped location for the mine
	private Vector2f findClearLocation(ShipAPI ship, Vector2f dest) {
		if (isLocationClear(dest)) return dest;

		float incr = 50f;

		WeightedRandomPicker<Vector2f> tested = new WeightedRandomPicker<Vector2f>();
		for (float distIndex = 1; distIndex <= 32f; distIndex *= 2f) {
			float start = (float) Math.random() * 360f;
			for (float angle = start; angle < start + 360; angle += 60f) {
				Vector2f loc = Misc.getUnitVectorAtDegreeAngle(angle);
				loc.scale(incr * distIndex);
				Vector2f.add(dest, loc, loc);
				tested.add(loc);
				if (isLocationClear(loc)) {
					return loc;
				}
			}
		}

		if (tested.isEmpty()) return dest; // shouldn't happen

		return tested.pick();
	}

	//Some more vanilla math to find clear locations for mines
	private boolean isLocationClear(Vector2f loc) {
		for (ShipAPI other : Global.getCombatEngine().getShips()) {
			if (other.isShuttlePod()) continue;
			if (other.isFighter()) continue;
			float dist = Misc.getDistance(loc, other.getLocation());
			float r = other.getCollisionRadius();
			//r = Math.min(r, Misc.getTargetingRadius(loc, other, false) + r * 0.25f);
			if (dist < r + MIN_SPAWN_DIST) {
				return false;
			}
		}
		for (CombatEntityAPI other : Global.getCombatEngine().getAsteroids()) {
			float dist = Misc.getDistance(loc, other.getLocation());
			if (dist < other.getCollisionRadius() + MIN_SPAWN_DIST) {
				return false;
			}
		}

		return true;
	}
}



