package data.scripts.ai;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.*;
import com.fs.starfarer.api.loading.DamagingExplosionSpec;
import com.fs.starfarer.api.util.Misc;
import org.lazywizard.lazylib.CollisionUtils;
import org.lazywizard.lazylib.FastTrig;
import org.lazywizard.lazylib.MathUtils;
import org.lazywizard.lazylib.VectorUtils;
import org.lazywizard.lazylib.combat.AIUtils;
import org.lwjgl.util.vector.Vector2f;

import java.awt.*;
import java.util.List;

/**
 * Torpedo AI for a proximity-fused fragmentation torpedo
 *
 * @author MesoTronik, with fusing logic by Nicke535
 */
public class loa_aoetorpedo_ai extends loa_BaseMissile {
    /* Configurations */
    private static final float ENGINE_DEAD_TIME_MAX = 0.5f;  // Max time until engine burn starts
    private static final float ENGINE_DEAD_TIME_MIN = 0.25f; // Min time until engine burn starts
    private static final float FIRE_INACCURACY = 3f; // Set-once for entire shot lifetime leading offset
    private static final float LEAD_GUIDANCE_FACTOR = 0.35f;
    private static final float LEAD_GUIDANCE_FACTOR_FROM_ECCM = 0.35f;
    private static final float VELOCITY_DAMPING_FACTOR = 0.1f;
    private static final float WEAVE_FALLOFF_DISTANCE = 500f; // Weaving stops entirely at 0 distance
    private static final float WEAVE_SINE_A_AMPLITUDE = 20f; // Degrees offset
    private static final float WEAVE_SINE_A_PERIOD = 6f;
    private static final float WEAVE_SINE_B_AMPLITUDE = 27f; // Degrees offset
    private static final float WEAVE_SINE_B_PERIOD = 13f;
    private static final float PROXIMITY_FUSE_RANGE = 60f;
    private static final int FRAG_COUNT = 16;
    private static final float FRAG_VELOCITY_MOD_MAX = 900f;
    private static final float FRAG_VELOCITY_MOD_MIN = 700f;
    private static final float EXPLOSION_SIZE_OUTER = 100f;
    private static final float EXPLOSION_SIZE_INNER = 50f;
    private static final float EXPLOSION_DAMAGE_MAX = 1200f;
    private static final float EXPLOSION_DAMAGE_MIN = 600f;
    private static final float EXPLOSION_DURATION = 0.25f;
    private static final float PARTICLE_DURATION = 0.5f;
    private static final int PARTICLE_COUNT = 25;
    private static final int PARTICLE_SIZE_MIN = 2;
    private static final int PARTICLE_SIZE_RANGE = 5;
    private static final float HEATGLOW_SIZE = 500f;
    private static final Color HEATGLOW_COLOR = new Color(255, 100, 0, 255);
    private static final float HEATGLOW_DURATION = 1f;
    private static final String FRAG_WEAPON_ID = "loa_mosaic_fragment";
    private static final Color VFX_COLOR = new Color(0, 0, 0, 0);
    private static final String SOUND_ID = "loa_mosaic_explode";
    private static final float ARMING_TIME = 0.5f;

    /* Internal script variables */
    private static final Vector2f ZERO = new Vector2f();
    private boolean aspectLocked = true;
    private float engineDeadTime;
    private float timeAccum = 0f;
    private final float weaveSineAPhase;
    private final float weaveSineBPhase;
    private final float inaccuracy;
    protected final float eccmMult;

    public loa_aoetorpedo_ai(MissileAPI missile, ShipAPI launchingShip) {
        super(missile, launchingShip);

        weaveSineAPhase = (float) (Math.random() * Math.PI * 2.0);
        weaveSineBPhase = (float) (Math.random() * Math.PI * 2.0);
        engineDeadTime = MathUtils.getRandomNumberInRange(ENGINE_DEAD_TIME_MIN, ENGINE_DEAD_TIME_MAX);

        eccmMult = 0.5f; // How much ECCM affects FIRE_INACCURACY

        inaccuracy = MathUtils.getRandomNumberInRange(-FIRE_INACCURACY, FIRE_INACCURACY);
    }

    public float getInaccuracyAfterECCM() {
        float eccmEffectMult = 1;
        if (launchingShip != null) {
            eccmEffectMult = 1 - eccmMult * launchingShip.getMutableStats().getMissileGuidance().getModifiedValue();
        }
        if (eccmEffectMult < 0) {
            eccmEffectMult = 0;
        }

        return inaccuracy * eccmEffectMult;
    }

    @Override
    public void advance(float amount) {
        if (missile.isFizzling() || missile.isFading()) {
            return;
        }

        if (engineDeadTime > 0f) {
            engineDeadTime -= amount;
            return;
        }

        timeAccum += amount;

        if (!acquireTarget(amount)) {
            missile.giveCommand(ShipCommand.ACCELERATE);
            return;
        }

        float distance = MathUtils.getDistance(target.getLocation(), missile.getLocation());
        float maxSpeed = missile.getMaxSpeed();
        float guidance = LEAD_GUIDANCE_FACTOR;
        if (missile.getSource() != null) {
            guidance += Math.min(missile.getSource().getMutableStats().getMissileGuidance().getModifiedValue()
                    - missile.getSource().getMutableStats().getMissileGuidance().getBaseValue(), 1f) * LEAD_GUIDANCE_FACTOR_FROM_ECCM;
        }
        Vector2f guidedTarget = intercept(missile.getLocation(), missile.getVelocity().length(), target.getLocation(), target.getVelocity());
        if (guidedTarget == null) {
            Vector2f projection = new Vector2f(target.getVelocity());
            float scalar = distance / (missile.getVelocity().length() + 1f);
            projection.scale(scalar);
            guidedTarget = Vector2f.add(target.getLocation(), projection, null);
        }
        Vector2f.sub(guidedTarget, target.getLocation(), guidedTarget);
        guidedTarget.scale(guidance);
        Vector2f.add(guidedTarget, target.getLocation(), guidedTarget);

        float weaveSineA = WEAVE_SINE_A_AMPLITUDE * (float) FastTrig.sin((2.0 * Math.PI * timeAccum / WEAVE_SINE_A_PERIOD) + weaveSineAPhase);
        float weaveSineB = WEAVE_SINE_B_AMPLITUDE * (float) FastTrig.sin((2.0 * Math.PI * timeAccum / WEAVE_SINE_B_PERIOD) + weaveSineBPhase);
        float weaveOffset = (weaveSineA + weaveSineB) * Math.min(1f, distance / WEAVE_FALLOFF_DISTANCE);

        float angularDistance;
        if (aspectLocked) {
            angularDistance = MathUtils.getShortestRotation(missile.getFacing(),
                    MathUtils.clampAngle(VectorUtils.getAngle(missile.getLocation(), guidedTarget) + getInaccuracyAfterECCM() + weaveOffset));
        } else {
            angularDistance = MathUtils.getShortestRotation(missile.getFacing(),
                    MathUtils.clampAngle(VectorUtils.getAngle(missile.getLocation(), guidedTarget)));
        }
        float absDAng = Math.abs(angularDistance);

        missile.giveCommand(angularDistance < 0 ? ShipCommand.TURN_RIGHT : ShipCommand.TURN_LEFT);

        if (aspectLocked && absDAng > 60f) {
            aspectLocked = false;
        }

        if (!aspectLocked && absDAng <= 45f) {
            aspectLocked = true;
        }

        if (aspectLocked || missile.getVelocity().length() <= maxSpeed * 0.4f) {
            missile.giveCommand(ShipCommand.ACCELERATE);
        }

        if (absDAng < 5) {
            float MFlightAng = VectorUtils.getAngle(ZERO, missile.getVelocity());
            float MFlightCC = MathUtils.getShortestRotation(missile.getFacing(), MFlightAng);
            if (Math.abs(MFlightCC) > 20) {
                missile.giveCommand(MFlightCC < 0 ? ShipCommand.STRAFE_LEFT : ShipCommand.STRAFE_RIGHT);
            }
        }

        if (absDAng < Math.abs(missile.getAngularVelocity()) * VELOCITY_DAMPING_FACTOR) {
            missile.setAngularVelocity(angularDistance / VELOCITY_DAMPING_FACTOR);
        }

        //Runs fusing logic
        runFusingLogic();
    }

    private void explode() {
        // This destroys the missile
        Global.getCombatEngine().applyDamage(missile, missile.getLocation(), missile.getHitpoints() * 100f, DamageType.FRAGMENTATION, 0f, false, false, missile);

        // This spawns some custom vfx stacked with the "normal" ones done by spawnDamagingExplosion
        Global.getCombatEngine().spawnExplosion(missile.getLocation(), ZERO, VFX_COLOR, EXPLOSION_SIZE_INNER, EXPLOSION_DURATION);
        Global.getCombatEngine().addSmoothParticle(missile.getLocation(), ZERO, HEATGLOW_SIZE, 1f, HEATGLOW_DURATION, HEATGLOW_COLOR);

        // This spawns the damaging explosion
        /*
                float duration
                float radius
                float coreRadius
                float maxDamage
                float minDamage
                CollisionClass collisionClass
                CollisionClass collisionClassByFighter
                float particleSizeMin
                float particleSizeRange
                float particleDuration
                int particleCount
                Color particleColor
                Color explosionColor
         */
        DamagingExplosionSpec boom = new DamagingExplosionSpec(
                EXPLOSION_DURATION,
                EXPLOSION_SIZE_OUTER,
                EXPLOSION_SIZE_INNER,
                EXPLOSION_DAMAGE_MAX,
                EXPLOSION_DAMAGE_MIN,
                CollisionClass.PROJECTILE_FF,
                CollisionClass.PROJECTILE_FIGHTER,
                PARTICLE_SIZE_MIN,
                PARTICLE_SIZE_RANGE,
                PARTICLE_DURATION,
                PARTICLE_COUNT,
                VFX_COLOR,
                VFX_COLOR
        );
        boom.setDamageType(DamageType.HIGH_EXPLOSIVE);
        boom.setShowGraphic(true);
        boom.setSoundSetId(SOUND_ID);
        Global.getCombatEngine().spawnDamagingExplosion(boom, missile.getSource(), missile.getLocation(), false);

        // This spawns the frag, also distributing them in a nice even 360 degree arc
        Vector2f vel = new Vector2f();
        for (int i = 0; i < FRAG_COUNT; i++) {
            float angle = missile.getFacing() + i * 360f / FRAG_COUNT + (float) Math.random() * 180f / FRAG_COUNT;
            angle %= 360f;
            vel.set((float) Math.random() * FRAG_VELOCITY_MOD_MAX - FRAG_VELOCITY_MOD_MIN, 0f);
            VectorUtils.rotate(vel, angle, vel);
            Vector2f location = MathUtils.getPointOnCircumference(missile.getLocation(), 3f, angle);
            Global.getCombatEngine().spawnProjectile(missile.getSource(), missile.getWeapon(), FRAG_WEAPON_ID, location, angle, vel);
        }
    }

    @Override
    protected boolean acquireTarget(float amount) {
        if (!isTargetValidAlternate(target)) {
            if (target instanceof ShipAPI) {
                ShipAPI ship = (ShipAPI) target;
                if (ship.isPhased() && ship.isAlive()) {
                    return false;
                }
            }
            setTarget(findBestTarget());
            if (target == null) {
                setTarget(findBestTargetAlternate());
            }
            if (target == null) {
                return false;
            }
        } else {
            if (!isTargetValid(target)) {
                if (target instanceof ShipAPI) {
                    ShipAPI ship = (ShipAPI) target;
                    if (ship.isPhased() && ship.isAlive()) {
                        return false;
                    }
                }
                CombatEntityAPI newTarget = findBestTarget();
                if (newTarget != null) {
                    target = newTarget;
                }
            }
        }
        return true;
    }

    // This is some bullshit weighted random picker that favors larger ships
    @Override
    protected ShipAPI findBestTarget() {
        ShipAPI best = null;
        float weight, bestWeight = 0f;
        List<ShipAPI> ships = AIUtils.getEnemiesOnMap(missile);
        int size = ships.size();
        for (int i = 0; i < size; i++) {
            ShipAPI tmp = ships.get(i);
            float mod;
            if (!isTargetValid(tmp)) {
                mod = 0f;
            } else {
                switch (tmp.getHullSize()) {
                    default:
                    case FIGHTER:
                        mod = 1f;
                        break;
                    case FRIGATE:
                        mod = 10f;
                        break;
                    case DESTROYER:
                        mod = 50f;
                        break;
                    case CRUISER:
                        mod = 100f;
                        break;
                    case CAPITAL_SHIP:
                        mod = 125f;
                        break;
                }
            }
            weight = (1500f / Math.max(MathUtils.getDistance(tmp, missile.getLocation()), 750f)) * mod;
            if (weight > bestWeight) {
                best = tmp;
                bestWeight = weight;
            }
        }
        return best;
    }

    protected ShipAPI findBestTargetAlternate() {
        ShipAPI best = null;
        float weight, bestWeight = 0f;
        List<ShipAPI> ships = AIUtils.getEnemiesOnMap(missile);
        int size = ships.size();
        for (int i = 0; i < size; i++) {
            ShipAPI tmp = ships.get(i);
            float mod;
            if (!isTargetValidAlternate(tmp)) {
                mod = 0f;
            } else {
                switch (tmp.getHullSize()) {
                    default:
                    case FIGHTER:
                        mod = 1f;
                        break;
                    case FRIGATE:
                        mod = 10f;
                        break;
                    case DESTROYER:
                        mod = 50f;
                        break;
                    case CRUISER:
                        mod = 100f;
                        break;
                    case CAPITAL_SHIP:
                        mod = 125f;
                        break;
                }
            }
            weight = (1500f / Math.max(MathUtils.getDistance(tmp, missile.getLocation()), 750f)) * mod;
            if (weight > bestWeight) {
                best = tmp;
                bestWeight = weight;
            }
        }
        return best;
    }

    @Override
    protected boolean isTargetValid(CombatEntityAPI target) {
        if (target instanceof ShipAPI) {
            ShipAPI ship = (ShipAPI) target;
            if (ship.isFighter() || ship.isDrone()) {
                return false;
            }
        }
        return super.isTargetValid(target);
    }

    protected boolean isTargetValidAlternate(CombatEntityAPI target) {
        return super.isTargetValid(target);
    }


    //Fusing logic
    private void runFusingLogic() {
        //We can't detonate before we're armed
        if (timeAccum < ARMING_TIME || !missile.isArmed()) {
            return;
        }

        //Against non-ship targets, just run a *very* simple targeting check
        if (!(target instanceof ShipAPI)) {
            if (MathUtils.getDistance(missile.getLocation(), target.getLocation()) < PROXIMITY_FUSE_RANGE + target.getCollisionRadius()) {
                explode();
            }
        } else {
            ShipAPI targetShip = (ShipAPI) target;
            //First of all, we can't detonate without being close enough to the enemy's collision radius
            if (MathUtils.getDistance(missile.getLocation(), targetShip.getLocation()) > PROXIMITY_FUSE_RANGE + targetShip.getCollisionRadius()) {
                return;
            }

            //Then, check if the enemy has shields we could potentially impact
            boolean potShieldImpact = false;
            if (targetShip.getShield() != null
                    && (targetShip.getShield().getType() == ShieldAPI.ShieldType.FRONT || targetShip.getShield().getType() == ShieldAPI.ShieldType.OMNI)
                    && targetShip.getShield().isOn()) {
                potShieldImpact = true;
            }

            //If there was potential for a shield hit, check that first
            if (potShieldImpact) {
                //We cannot possibly hit a shield we're too far away from
                float distanceToShieldCenter = MathUtils.getDistance(targetShip.getShieldCenterEvenIfNoShield(), missile.getLocation());
                if (distanceToShieldCenter <= PROXIMITY_FUSE_RANGE + targetShip.getShieldRadiusEvenIfNoShield()) {
                    //If we're in the shield arc, we're in fuse range: detonate
                    if (targetShip.getShield().isWithinArc(missile.getLocation())) {
                        explode();
                        return;
                    }

                    //Otherwise, we get the two points that are closest to the missile on each shield edge and check
                    // the distance to those points
                    Vector2f corner1 = MathUtils.getPoint(targetShip.getShieldCenterEvenIfNoShield(),
                            targetShip.getShield().getRadius(),
                            targetShip.getShield().getFacing() - (targetShip.getShield().getActiveArc() / 2f));
                    Vector2f closestPoint1 = Misc.closestPointOnSegmentToPoint(targetShip.getShieldCenterEvenIfNoShield(),
                            corner1, missile.getLocation());
                    Vector2f corner2 = MathUtils.getPoint(targetShip.getShieldCenterEvenIfNoShield(),
                            targetShip.getShield().getRadius(),
                            targetShip.getShield().getFacing() + (targetShip.getShield().getActiveArc() / 2f));
                    Vector2f closestPoint2 = Misc.closestPointOnSegmentToPoint(targetShip.getShieldCenterEvenIfNoShield(),
                            corner2, missile.getLocation());

                    if (MathUtils.getDistance(closestPoint1, missile.getLocation()) < PROXIMITY_FUSE_RANGE
                            || MathUtils.getDistance(closestPoint2, missile.getLocation()) < PROXIMITY_FUSE_RANGE) {
                        explode();
                        return;
                    }
                }
            }

            //Check for hull impact, if we didn't trigger on the shield
            float distanceToBounds = MathUtils.getDistance(CollisionUtils.getNearestPointOnBounds(missile.getLocation(), targetShip),
                                                            missile.getLocation());
            if (distanceToBounds < PROXIMITY_FUSE_RANGE) {
                explode();
            }
        }
    }
}
