package data.scripts.ai;

import com.fs.starfarer.api.combat.*;
import com.fs.starfarer.api.loading.WeaponSlotAPI;
import com.fs.starfarer.api.util.IntervalUtil;
import com.fs.starfarer.api.util.Misc;
import org.lazywizard.lazylib.MathUtils;
import org.lazywizard.lazylib.VectorUtils;
import org.lazywizard.lazylib.combat.CombatUtils;
import org.lwjgl.util.vector.Vector2f;

import java.awt.*;
import java.util.*;
import java.util.List;

/**
 * Where we rammin', boys?
 * @author Nicke535
 */
public class loa_massivethrusters_ai implements ShipSystemAIScript {
    //Debug mode for printing out a lot of extra data
    private static final boolean DEBUG_MODE = false;

    //The hull ID of any modules we want to affect must contain this string
    private static final String HULL_ID_TO_AFFECT = "loa_arscapitol_engine";

    //The "target" range both forward and backward. This determines avoiding friendly fire and selecting opportune moments
    public static final float BACK_TARGET_RANGE = 500f;
    public static final float FRONT_TARGET_RANGE = 1750f;

    //The "danger" angle and range: any targets within this angle and the frontal target range are considered a potential threat when activating
    //  Counts in both directions: 360 is in every direction, 180 the frontal hemisphere
    public static final float DANGER_ANGLE = 120f;

    //We need at this many DP in our target areas to activate the system
    public static final float MINIMUM_DP_TO_ACTIVATE = 40f;

    //The maximum amount of DP we are allowed to engage: if there are more enemies than this, we're biting off more than we can chew
    public static final float MAX_THREAT_DP = 80f;

    //How often does the script check for activation/deactivation?
    private IntervalUtil tracker = new IntervalUtil(0.15f, 0.2f);


    //--Used in-script to simplify later calls and some other tracking: don't touch--
    private ShipAPI ship;
    private CombatEngineAPI engine;
    private ShipwideAIFlags flags;
    private ShipSystemAPI system;

    //Initialize some variables for later use
    public void init(ShipAPI ship, ShipSystemAPI system, ShipwideAIFlags flags, CombatEngineAPI engine) {
        this.ship = ship;
        this.flags = flags;
        this.engine = engine;
        this.system = system;
    }

    //Main advance loop
    @SuppressWarnings("unchecked")
    public void advance(float amount, Vector2f missileDangerDir, Vector2f collisionDangerDir, ShipAPI target) {
        //If the system is on, or not off cooldown, don't run any checks: no stopping!
        if (!system.getState().equals(ShipSystemAPI.SystemState.IDLE)) {
            return;
        }

        //Check our tracker if we should do anything
        tracker.advance(amount);
        if (tracker.intervalElapsed()) {
            //Keeps a set of all targets that are in either our danger or target zones
            Set<ShipAPI> targetsToCareAbout = new HashSet<>();
            Set<ShipAPI> threatsToCareAbout = new HashSet<>();

            //First finds all our modules that fire projectiles, so we can check from those
            List<ShipAPI> engineModules = new ArrayList<>();
            for (ShipAPI module : ship.getChildModulesCopy()) {
                //Dead or non-engine modules don't count
                if (!module.getHullSpec().getHullId().contains(HULL_ID_TO_AFFECT) || !module.isAlive()) {
                    continue;
                }

                //Also, if the module is flamed out, it should also not count
                if (module.getEngineController().isFlamedOut()) {
                    continue;
                }

                engineModules.add(module);
            }
            for (ShipAPI module : engineModules) {
                for (WeaponSlotAPI slot : module.getHullSpec().getAllWeaponSlotsCopy()) {
                    //Only care about system slots
                    if (!slot.isSystemSlot()) {
                        continue;
                    }

                    //Get our weapon slot's position, facing and arc
                    Vector2f point = slot.computePosition(module);
                    float facing = slot.getAngle() + module.getFacing();
                    float arc = slot.getArc();

                    //Get all targets within range and arc
                    for (ShipAPI potTarget : CombatUtils.getShipsWithinRange(point, BACK_TARGET_RANGE)) {
                        //Ignore fighters, and our own modules
                        if (!potTarget.isAlive() || potTarget.isFighter() || potTarget.getParentStation() == ship || potTarget == ship) {
                            continue;
                        }

                        float angle = VectorUtils.getAngle(point, potTarget.getLocation());
                        if (Misc.isInArc(facing, arc, angle)) {
                            //Never friendly-fire: just cancel outright if we are about to
                            if (potTarget.getOwner() == ship.getOwner()) {
                                if (DEBUG_MODE) {
                                    engine.addFloatingText(potTarget.getLocation(), "Friendly fire!", 20f, Color.GREEN, potTarget, 0f, 1f);
                                }
                                return;
                            }
                            targetsToCareAbout.add(potTarget);
                        }
                    }
                }
            }

            //Then, find all targets and threats in front of us
            Vector2f forwardCheckPoint = MathUtils.getPoint(ship.getLocation(), FRONT_TARGET_RANGE, ship.getFacing());
            for (ShipAPI potTarget : CombatUtils.getShipsWithinRange(ship.getLocation(), FRONT_TARGET_RANGE)) {
                //Ignore dead ships, fighters, and our own modules
                if (!potTarget.isAlive() || potTarget.isFighter() || potTarget.getParentStation() == ship || potTarget == ship) {
                    continue;
                }

                float angle = VectorUtils.getAngle(ship.getLocation(), potTarget.getLocation());
                if (Misc.isInArc(ship.getFacing(), DANGER_ANGLE, angle)) {
                    threatsToCareAbout.add(potTarget);
                }

                //Slightly trickier to check for targets, but basically: check the distance they are from a
                // forward-facing line and check if that's smaller than the combined collision radius
                if (Misc.distanceFromLineToPoint(forwardCheckPoint, ship.getLocation(), potTarget.getLocation())
                        <= potTarget.getCollisionRadius()+ship.getCollisionRadius()) {
                    //Never friendly-fire: just cancel outright if we are about to
                    if (potTarget.getOwner() == ship.getOwner()) {
                        if (DEBUG_MODE) {
                            engine.addFloatingText(potTarget.getLocation(), "Friendly fire!", 20f, Color.GREEN, potTarget, 0f, 1f);
                        }
                        return;
                    }
                    targetsToCareAbout.add(potTarget);
                }
            }

            //Now that we have our sets, check them for how many targets we actually have, and determine if it's worth the risk
            float threatDP = 0f;
            float targetDP = 0f;
            for (ShipAPI threat : threatsToCareAbout) {
                threatDP += threat.getMutableStats().getSuppliesToRecover().getBaseValue();
            }
            if (threatDP > MAX_THREAT_DP) {
                if (DEBUG_MODE) {
                    engine.addFloatingText(ship.getLocation(), "Too many threats to activate ("+(int)threatDP+" DP)", 20f, Color.RED, ship, 0f, 1f);
                }
                return;
            }
            for (ShipAPI enemy : targetsToCareAbout) {
                targetDP += enemy.getMutableStats().getSuppliesToRecover().getBaseValue();
            }
            if (targetDP > MINIMUM_DP_TO_ACTIVATE) {
                activateSystem();
            } else {
                if (DEBUG_MODE) {
                    engine.addFloatingText(ship.getLocation(), "Not enough enemy DP ahead ("+(int)targetDP+" DP)", 20f, Color.ORANGE, ship, 0f, 1f);
                }
            }
        }
    }

    private void activateSystem() {
        if (!system.isOn()) {
            ship.useSystem();
        }
    }
}

