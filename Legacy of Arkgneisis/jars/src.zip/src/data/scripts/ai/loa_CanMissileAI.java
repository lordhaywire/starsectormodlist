package data.scripts.ai;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.CombatEntityAPI;
import com.fs.starfarer.api.combat.DamageType;
import com.fs.starfarer.api.combat.GuidedMissileAI;
import com.fs.starfarer.api.combat.MissileAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipCommand;
import java.awt.Color;
import java.util.List;
import org.lazywizard.lazylib.MathUtils;
import org.lazywizard.lazylib.VectorUtils;
import org.lazywizard.lazylib.combat.AIUtils;
import org.lwjgl.util.vector.Vector2f;

// Used for two stage missiles that perform combat entity substitution for the second stage
public class loa_CanMissileAI extends loa_BaseMissile
{
    private static final float AIM_THRESHOLD = 0.5f;
    private static final float BURN_DELAY_MAX = 0.3f; // Max time until thrusting starts after target acquired
    private static final float BURN_DELAY_MIN = 0.3f; // Min time until thrusting starts after target acquired
    private static final float ENGINE_DEAD_TIME_MAX = 0.1f;  // Max time until engine burn starts
    private static final float ENGINE_DEAD_TIME_MIN = 0.05f; // Min time until engine burn starts
    private static final float FIRE_INACCURACY = 5f;
    private static final float FLARE_OFFSET = -9f;
    private static final float MIRV_INACCURACY = 5f;
    private static final Color FLARE_COLOR = new Color(200, 165, 55, 255);
    private static final Color SMOKE_COLOR = new Color(155, 145, 135, 75);
    private static final boolean STAGE_ONE_EXPLODE = true;
    private static final boolean STAGE_ONE_FLARE = false;
    private static final boolean STAGE_ONE_TRANSFER_DAMAGE = false;
    private static final boolean STAGE_ONE_TRANSFER_MOMENTUM = true;
    private static final boolean STAGE_ONE_CAN_PAUSE_FIRE_CYCLES = false; // If it can pause its firing cycles if target lock is lost
    private static final int STAGE_ONE_NUM_FIRE_CYCLES = 3; // How many times it fires missiles
    private static final int STAGE_ONE_SUBMUNITIONS_PER_FIRE_CYCLE = 1; // How many missiles it fires per "cycle"
    private static final float STAGE_ONE_FIRE_CYCLE_DELAY = 0.5f; // How long between each set of missiles
    private static final float STAGE_ONE_EXPIRATION_DELAY = 1f; // How long the missile will stick around after its done firing
    private static final String STAGE_TWO_SOUND_ID = "loa_cone_launch";
    private static final String STAGE_TWO_WEAPON_ID = "al_cone";
    private static final float VELOCITY_DAMPING_FACTOR = 0.15f;
    private static final Vector2f ZERO = new Vector2f();
    private float burnDelayTimer;
    private float engineDeadTimer;
    private float sequentialFireTimer;
    private float expireTimer;
    private final float inaccuracy;
    private int fireCyclesLeft;
    private boolean lockedOn = false;
    private boolean readyToFly = false;
    private boolean expiring = false;
    protected final float eccmMult;     // How much ECCM affects accuracy

    public loa_CanMissileAI(MissileAPI missile, ShipAPI launchingShip)
    {
        super(missile, launchingShip);

        burnDelayTimer = MathUtils.getRandomNumberInRange(BURN_DELAY_MIN, BURN_DELAY_MAX);
        engineDeadTimer = MathUtils.getRandomNumberInRange(ENGINE_DEAD_TIME_MIN, ENGINE_DEAD_TIME_MAX);

        eccmMult = 0.75f;

        fireCyclesLeft = STAGE_ONE_NUM_FIRE_CYCLES;
        sequentialFireTimer = 0f; // First shot is fired instantly, don't change this line

        inaccuracy = MathUtils.getRandomNumberInRange(-FIRE_INACCURACY, FIRE_INACCURACY);
    }

    public float getInaccuracyAfterECCM()
    {
        float eccmEffectMult = 1;
        if (launchingShip != null)
        {
            eccmEffectMult = 1 - eccmMult * launchingShip.getMutableStats().getMissileGuidance().getModifiedValue();
        }
        if (eccmEffectMult < 0)
        {
            eccmEffectMult = 0;
        }

        return inaccuracy * eccmEffectMult;
    }

    @Override
    public void advance(float amount)
    {
        if (missile.isFading() || missile.isFizzling())
        {
            return;
        }

        // Do not fly until we have both aimed correctly and finished engineDeadTimer
        if (!lockedOn || !readyToFly)
        {
            if (engineDeadTimer > 0f)
            {
                engineDeadTimer -= amount;
                if (engineDeadTimer <= 0f)
                {
                    readyToFly = true;
                }
            }
        }

        if (!lockedOn || STAGE_ONE_CAN_PAUSE_FIRE_CYCLES)
        {
            // If we have a valid target, turn to face desired intercept point
            lockedOn = false;
            if (acquireTarget(amount))
            {
                float distance = MathUtils.getDistance(target.getLocation(), missile.getLocation());
                Vector2f guidedTarget = intercept(missile.getLocation(), missile.getMaxSpeed(), target.getLocation(), target.getVelocity());
                if (guidedTarget == null)
                {
                    Vector2f projection = new Vector2f(target.getVelocity());
                    float scalar = distance / (missile.getVelocity().length() + 1f);
                    projection.scale(scalar);
                    guidedTarget = Vector2f.add(target.getLocation(), projection, null);
                }

                float angularDistance = MathUtils.getShortestRotation(missile.getFacing(),
                        MathUtils.clampAngle(VectorUtils.getAngle(missile.getLocation(), guidedTarget) + getInaccuracyAfterECCM()));
                float absDAng = Math.abs(angularDistance);

                missile.giveCommand(angularDistance < 0 ? ShipCommand.TURN_RIGHT : ShipCommand.TURN_LEFT);

                if (absDAng < Math.abs(missile.getAngularVelocity()) * VELOCITY_DAMPING_FACTOR)
                {
                    missile.setAngularVelocity(angularDistance / VELOCITY_DAMPING_FACTOR);
                }

                if (absDAng <= AIM_THRESHOLD)
                {
                    lockedOn = true;
                }
            }
        }

        // Pointed at desired intercept point, waiting for boost
        // Decelerate missile in the meantime
        if (burnDelayTimer > 0f)
        {
            burnDelayTimer -= amount;
            missile.giveCommand(ShipCommand.DECELERATE);
            return;
        }

        // "Boost" (create new missile)
        if (lockedOn && fireCyclesLeft > 0)
        {
            sequentialFireTimer -= amount;
            if (sequentialFireTimer > 0f)
            {
                return;
            }

            MissileAPI newMissile;
            if (STAGE_ONE_TRANSFER_MOMENTUM)
            {
                for (int i = 0; i < STAGE_ONE_SUBMUNITIONS_PER_FIRE_CYCLE; i++)
                {
                    float angle = missile.getFacing() + (i - 1) * 10f + MathUtils.getRandomNumberInRange(-MIRV_INACCURACY, MIRV_INACCURACY);
                    if (angle < 0f)
                    {
                        angle += 360f;
                    }
                    else if (angle >= 360f)
                    {
                        angle -= 360f;
                    }
                    MathUtils.getPointOnCircumference(missile.getLocation(), 5f, angle);

                    newMissile = (MissileAPI) Global.getCombatEngine().spawnProjectile(launchingShip,
                            missile.getWeapon(), STAGE_TWO_WEAPON_ID,
                            missile.getLocation(), angle, missile.getVelocity());
                    newMissile.setAngularVelocity(missile.getAngularVelocity());

                     Vector2f vel = new Vector2f();
                    vel.set(((float) Math.random() * 1f + 0.25f) * 25f, 0f);
                    VectorUtils.rotate(vel, MathUtils.getRandomNumberInRange(-15f, 15f) + missile.getFacing() + 180f, vel);
                    Global.getCombatEngine().addSmokeParticle(missile.getLocation(), vel, 60f, 0.75f, 0.75f, SMOKE_COLOR);
                }
            }
            else
            {
                for (int i = 0; i < STAGE_ONE_SUBMUNITIONS_PER_FIRE_CYCLE; i++)
                {
                    float angle = missile.getFacing() + (i - 1) * 10f + MathUtils.getRandomNumberInRange(-MIRV_INACCURACY, MIRV_INACCURACY);
                    if (angle < 0f)
                    {
                        angle += 360f;
                    }
                    else if (angle >= 360f)
                    {
                        angle -= 360f;
                    }
                    MathUtils.getPointOnCircumference(missile.getLocation(), 5f, angle);

                    newMissile = (MissileAPI) Global.getCombatEngine().spawnProjectile(launchingShip,
                            missile.getWeapon(), STAGE_TWO_WEAPON_ID,
                            missile.getLocation(), angle, ZERO);

                     Vector2f vel = new Vector2f();
                    vel.set(((float) Math.random() * 1f + 0.25f) * 25f, 0f);
                    VectorUtils.rotate(vel, MathUtils.getRandomNumberInRange(-15f, 15f) + missile.getFacing() + 180f, vel);
                    Global.getCombatEngine().addSmokeParticle(missile.getLocation(), vel, 60f, 0.75f, 0.75f, SMOKE_COLOR);
                }

                newMissile.setFromMissile(true);
                ((GuidedMissileAI) newMissile.getMissileAI()).setTarget(target);
            }

            // Transfer any damage the missile has incurred if so desired
            if (STAGE_ONE_TRANSFER_DAMAGE)
            {
                newMissile.setEmpResistance(missile.getEmpResistance());
                float damageToDeal = missile.getMaxHitpoints() - missile.getHitpoints();
                if (damageToDeal > 0f)
                {
                    Global.getCombatEngine().applyDamage(newMissile, missile.getLocation(), damageToDeal,
                            DamageType.FRAGMENTATION, 0f, true, false, missile.getSource());
                }
            }

            Global.getSoundPlayer().playSound(STAGE_TWO_SOUND_ID, 1f, 1f, missile.getLocation(), missile.getVelocity());

            // Missile will start the expiration process once it's fired all of its submunitions
            fireCyclesLeft--;
            sequentialFireTimer = STAGE_ONE_FIRE_CYCLE_DELAY;
            if (fireCyclesLeft <= 0)
            {
                expiring = true;
                expireTimer = STAGE_ONE_EXPIRATION_DELAY;
            }
        }

        // Expiration phase
        if (expiring)
        {
            expireTimer -= amount;
            if (expireTimer <= 0f)
            {
                // GFX on the spot of the switcheroo if desired
                // Remove old missile
                if (STAGE_ONE_EXPLODE)
                {
                    Global.getCombatEngine().applyDamage(missile, missile.getLocation(), missile.getHitpoints() * 100f,
                            DamageType.FRAGMENTATION, 0f, false, false, missile);
                }
                else if (STAGE_ONE_FLARE)
                {
                    Vector2f offset = new Vector2f(FLARE_OFFSET, 0f);
                    VectorUtils.rotate(offset, missile.getFacing(), offset);
                    Vector2f.add(offset, missile.getLocation(), offset);
                    Global.getCombatEngine().addHitParticle(offset, missile.getVelocity(), 100f, 0.5f, 0.25f, FLARE_COLOR);
                    Global.getCombatEngine().removeEntity(missile);
                }
                else
                {
                    Global.getCombatEngine().removeEntity(missile);
                }
            }
        }
    }

    @Override
    protected boolean acquireTarget(float amount)
    {
        // If our current target is totally invalid, look for a new one
        if (!isTargetValid(target))
        {
            if (target instanceof ShipAPI)
            {
                ShipAPI ship = (ShipAPI) target;
                if (ship.isAlive())
                {
                    // We were locked onto a ship that has now phased, do not attempt to acquire a new target
                    return false;
                }
            }
            // Look for a target that is not a drone or fighter, if available
            setTarget(findBestTarget(false));
            // No such target, look again except this time we allow drones and fighters
            if (target == null)
            {
                setTarget(findBestTarget(true));
            }

            if (target == null)
            {
                return false;
            }
        }

        // If our target is valid but a drone or fighter, see if there's a bigger ship we can aim for instead
        else
        {
            if (isDroneOrFighter(target))
            {
                if (target instanceof ShipAPI)
                {
                    ShipAPI ship = (ShipAPI) target;
                    if (ship.isAlive())
                    {
                        // We were locked onto a ship that has now phased, do not attempt to acquire a new target
                        return false;
                    }
                }
                CombatEntityAPI newTarget = findBestTarget();
                if (newTarget != null)
                {
                    target = newTarget;
                }
            }
        }
        return true;
    }

    @Override
    protected ShipAPI findBestTarget()
    {
        return findBestTarget(false);
    }

    /**
     * This is some bullshit weighted random picker that favors larger ships
     *
     * @param allowDroneOrFighter True if looking for an alternate target
     * (normally it refuses to target fighters or drones)
     *
     * @return
     */
    protected ShipAPI findBestTarget(boolean allowDroneOrFighter)
    {
        ShipAPI best = null;
        float weight, bestWeight = 0f;
        List<ShipAPI> ships = AIUtils.getEnemiesOnMap(missile);
        int size = ships.size();
        for (int i = 0; i < size; i++)
        {
            ShipAPI tmp = ships.get(i);
            float mod;
            // This is a valid target if:
            //   It is NOT a (drone or fighter), OR we're in alternate mode
            //   It passes the valid target check
            boolean valid = allowDroneOrFighter || !isDroneOrFighter(target);
            valid = valid && isTargetValid(tmp);
            if (!valid)
            {
                continue;
            }
            else
            {
                switch (tmp.getHullSize())
                {
                    default:
                    case FIGHTER:
                        mod = 1f;
                        break;
                    case FRIGATE:
                        mod = 10f;
                        break;
                    case DESTROYER:
                        mod = 50f;
                        break;
                    case CRUISER:
                        mod = 100f;
                        break;
                    case CAPITAL_SHIP:
                        mod = 125f;
                        break;
                }
            }
            weight = (1500f / Math.max(MathUtils.getDistance(tmp, missile.getLocation()), 750f)) * mod;
            if (weight > bestWeight)
            {
                best = tmp;
                bestWeight = weight;
            }
        }
        return best;
    }

    protected boolean isDroneOrFighter(CombatEntityAPI target)
    {
        if (target instanceof ShipAPI)
        {
            ShipAPI ship = (ShipAPI) target;
            if (ship.isFighter() || ship.isDrone())
            {
                return true;
            }
        }
        return false;
    }
}
