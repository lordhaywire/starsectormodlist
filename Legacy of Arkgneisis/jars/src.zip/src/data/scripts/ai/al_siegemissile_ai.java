package data.scripts.ai;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.*;
import com.fs.starfarer.api.loading.DamagingExplosionSpec;
import com.fs.starfarer.api.util.Misc;
import org.lazywizard.lazylib.CollisionUtils;
import org.lazywizard.lazylib.MathUtils;
import org.lazywizard.lazylib.VectorUtils;
import org.lazywizard.lazylib.combat.AIUtils;
import org.lwjgl.util.vector.Vector2f;

import java.awt.*;

/**
 * Adapted fused torpedo logic, combined with previous Siege Missile targeting AI
 *
 * @author Explosion function by MesoTronik
 * @author Fusing logic by Nicke535
 */
public class al_siegemissile_ai implements MissileAIPlugin, GuidedMissileAI {
    //Explosion/fuse configuration
    private static final float PROXIMITY_FUSE_RANGE = 60f;
    private static final int FRAG_COUNT = 16;
    private static final float FRAG_VELOCITY_MOD_MAX = 900f;
    private static final float FRAG_VELOCITY_MOD_MIN = 700f;
    private static final float EXPLOSION_SIZE_OUTER = 100f;
    private static final float EXPLOSION_SIZE_INNER = 50f;
    private static final float EXPLOSION_DAMAGE_MAX = 1200f;
    private static final float EXPLOSION_DAMAGE_MIN = 600f;
    private static final float EXPLOSION_DURATION = 0.25f;
    private static final float PARTICLE_DURATION = 0.5f;
    private static final int PARTICLE_COUNT = 25;
    private static final int PARTICLE_SIZE_MIN = 2;
    private static final int PARTICLE_SIZE_RANGE = 5;
    private static final float HEATGLOW_SIZE = 500f;
    private static final Color HEATGLOW_COLOR = new Color(255, 100, 0, 255);
    private static final float HEATGLOW_DURATION = 1f;
    private static final String FRAG_WEAPON_ID = "loa_mosaic_fragment";
    private static final Color VFX_COLOR = new Color(0, 0, 0, 0);
    private static final String SOUND_ID = "loa_mosaic_explode";
    private static final float ARMING_TIME = 0.5f;

    //Internal script variables
    private CombatEngineAPI engine;
    private final MissileAPI missile;
    private CombatEntityAPI target;
    private Vector2f lead = new Vector2f(0f,0f);
    private boolean overshoot = false;
    private boolean runOnce = false;
    //data
    private final float flightSpeed;
    private final float maxSearchRange = 5000;
    private final float searchCone = 10;
    //wider cone for cancelling the ship target if it is way out the attack cone
    private final float cancellingCone = 20;
    private final static float damping = 0.1f;

    //////////////////////
    //  DATA COLLECTING //
    //////////////////////
    
    public al_siegemissile_ai(MissileAPI missile, ShipAPI launchingShip) {
        this.missile = missile;
        flightSpeed = missile.getMaxSpeed();
    }
    
    //////////////////////
    //   MAIN AI LOOP   //
    //////////////////////
    
    @Override
    public void advance(float amount) {
        if (engine != Global.getCombatEngine()) {
            this.engine = Global.getCombatEngine();
        }
        
        // assign a target only once
        if (!runOnce)
        {
            setTarget(assignTarget(missile));
            runOnce=true;
        }
        
        //cancelling IF: skip the AI if the game is paused, the missile is way off course, engineless or without a target or target is phased out
        if (Global.getCombatEngine().isPaused() || overshoot || missile.isFading() || missile.isFizzling() || target == null) {return;}

        //Run fusing logic!
        runFusingLogic();
       
        //fiding lead point to aim to
        //public static Vector2f getBestInterceptPoint(Vector2f point, float speed,Vector2f targetLoc, Vector2f targetVel)
        lead = AIUtils.getBestInterceptPoint(missile.getLocation(), flightSpeed, target.getLocation(), target.getVelocity());
        
        if(lead == null) {
            return; //just in case to makes sure a corect lead has been calculated
        }
           
        //aimAngle = angle between the missile facing and the lead direction
        float aimAngle = MathUtils.getShortestRotation(missile.getFacing(), VectorUtils.getAngle(missile.getLocation(), lead));

        //if the missile overshoot the target, just shut the AI
        if (Math.abs(aimAngle) > 90) {
            if (aimAngle < 0) {
                overshoot = true;
                return;                
            }
        } else {
            //if the lead is forward, turn the missile toward the lead accelerating
            missile.giveCommand(ShipCommand.ACCELERATE);            
                if (aimAngle < 0) {
                    missile.giveCommand(ShipCommand.TURN_RIGHT);
                } else {
                    missile.giveCommand(ShipCommand.TURN_LEFT);
                }  
        }        
        // Damp angular velocity if the missile aim is getting close to the targeted angle
        if (Math.abs(aimAngle) < Math.abs(missile.getAngularVelocity()) * damping)
        {
            missile.setAngularVelocity(aimAngle / damping);
        }
    }
    
    //////////////////////
    //    TARGETTING    //
    //////////////////////
    
    public CombatEntityAPI assignTarget(MissileAPI missile)
    {
        ShipAPI source = missile.getSource();
        ShipAPI currentTarget = source.getShipTarget();
        
        if (currentTarget != null && 
                !currentTarget.isFighter() && 
                !currentTarget.isDrone() && 
                currentTarget.isAlive() && 
                currentTarget.getOwner()!=missile.getOwner() && 
                //current target is in the attack cone
                MathUtils.getShortestRotation(missile.getFacing(), VectorUtils.getAngle(missile.getLocation(), currentTarget.getLocation())) < cancellingCone){
            //return the ship's target if it's valid
            return (CombatEntityAPI)currentTarget;            
        } else {
            //search for the closest enemy in the cone of attack
            ShipAPI closest = null;
            float distance, closestDistance = Float.MAX_VALUE;
            //grab all nearby enemies
            for (ShipAPI tmp : AIUtils.getNearbyEnemies(missile, maxSearchRange))
            {
                //rule out ships out of the missile attack cone
                if (MathUtils.getShortestRotation(missile.getFacing(), VectorUtils.getAngle(missile.getLocation(), tmp.getLocation())) > searchCone)
                {
                    continue;
                }
                //sort closest enemy
                distance = MathUtils.getDistance(tmp, missile.getLocation());  
                if (distance < closestDistance)
                {
                    closest = tmp;
                    closestDistance = distance;
                }
            }
            //return the closest enemy
            return closest;
        }
    }

    @Override
    public CombatEntityAPI getTarget() {
        return target;
    }

    @Override
    public void setTarget(CombatEntityAPI target) {
        this.target = target;
    }
    
    public void init(CombatEngineAPI engine) {}

    //Function for exploding the missile
    private void explode() {
        // This destroys the missile
        Global.getCombatEngine().applyDamage(missile, missile.getLocation(), missile.getHitpoints() * 100f, DamageType.FRAGMENTATION, 0f, false, false, missile);

        // This spawns some custom vfx stacked with the "normal" ones done by spawnDamagingExplosion
        Global.getCombatEngine().spawnExplosion(missile.getLocation(), Misc.ZERO, VFX_COLOR, EXPLOSION_SIZE_INNER, EXPLOSION_DURATION);
        Global.getCombatEngine().addSmoothParticle(missile.getLocation(), Misc.ZERO, HEATGLOW_SIZE, 1f, HEATGLOW_DURATION, HEATGLOW_COLOR);

        // This spawns the damaging explosion
        DamagingExplosionSpec boom = new DamagingExplosionSpec(
                EXPLOSION_DURATION, //duration
                EXPLOSION_SIZE_OUTER, //radius
                EXPLOSION_SIZE_INNER, //coreRadius
                EXPLOSION_DAMAGE_MAX, //maxDamage
                EXPLOSION_DAMAGE_MIN, //minDamage
                CollisionClass.PROJECTILE_FF, //collisionClass
                CollisionClass.PROJECTILE_FIGHTER, //collisionClassByFighter
                PARTICLE_SIZE_MIN, //particleSizeMin
                PARTICLE_SIZE_RANGE, //particleSizeRange
                PARTICLE_DURATION, //particleDuration
                PARTICLE_COUNT, //particleCount
                VFX_COLOR, //particleColor
                VFX_COLOR //explosionColor
        );
        boom.setDamageType(DamageType.HIGH_EXPLOSIVE);
        boom.setShowGraphic(true);
        boom.setSoundSetId(SOUND_ID);
        Global.getCombatEngine().spawnDamagingExplosion(boom, missile.getSource(), missile.getLocation(), false);

        // This spawns the frag, also distributing them in a nice even 360 degree arc
        Vector2f vel = new Vector2f();
        for (int i = 0; i < FRAG_COUNT; i++) {
            float angle = missile.getFacing() + i * 360f / FRAG_COUNT + (float) Math.random() * 180f / FRAG_COUNT;
            angle %= 360f;
            vel.set((float) Math.random() * FRAG_VELOCITY_MOD_MAX - FRAG_VELOCITY_MOD_MIN, 0f);
            VectorUtils.rotate(vel, angle, vel);
            Vector2f location = MathUtils.getPointOnCircumference(missile.getLocation(), 3f, angle);
            Global.getCombatEngine().spawnProjectile(missile.getSource(), missile.getWeapon(), FRAG_WEAPON_ID, location, angle, vel);
        }
    }


    //Fusing logic
    private void runFusingLogic() {
        //We can't detonate before we're armed
        if (missile.getFlightTime() < ARMING_TIME || !missile.isArmed()) {
            return;
        }

        //Against non-ship targets, just run a *very* simple targeting check
        if (!(target instanceof ShipAPI)) {
            if (MathUtils.getDistance(missile.getLocation(), target.getLocation()) < PROXIMITY_FUSE_RANGE + target.getCollisionRadius()) {
                explode();
            }
        } else {
            ShipAPI targetShip = (ShipAPI) target;
            //First of all, we can't detonate without being close enough to the enemy's collision radius
            if (MathUtils.getDistance(missile.getLocation(), targetShip.getLocation()) > PROXIMITY_FUSE_RANGE + targetShip.getCollisionRadius()) {
                return;
            }

            //Then, check if the enemy has shields we could potentially impact
            boolean potShieldImpact = false;
            if (targetShip.getShield() != null
                    && (targetShip.getShield().getType() == ShieldAPI.ShieldType.FRONT || targetShip.getShield().getType() == ShieldAPI.ShieldType.OMNI)
                    && targetShip.getShield().isOn()) {
                potShieldImpact = true;
            }

            //If there was potential for a shield hit, check that first
            if (potShieldImpact) {
                //We cannot possibly hit a shield we're too far away from
                float distanceToShieldCenter = MathUtils.getDistance(targetShip.getShieldCenterEvenIfNoShield(), missile.getLocation());
                if (distanceToShieldCenter <= PROXIMITY_FUSE_RANGE + targetShip.getShieldRadiusEvenIfNoShield()) {
                    //If we're in the shield arc, we're in fuse range: detonate
                    if (targetShip.getShield().isWithinArc(missile.getLocation())) {
                        explode();
                        return;
                    }

                    //Otherwise, we get the two points that are closest to the missile on each shield edge and check
                    // the distance to those points
                    Vector2f corner1 = MathUtils.getPoint(targetShip.getShieldCenterEvenIfNoShield(),
                            targetShip.getShield().getRadius(),
                            targetShip.getShield().getFacing() - (targetShip.getShield().getActiveArc() / 2f));
                    Vector2f closestPoint1 = Misc.closestPointOnSegmentToPoint(targetShip.getShieldCenterEvenIfNoShield(),
                            corner1, missile.getLocation());
                    Vector2f corner2 = MathUtils.getPoint(targetShip.getShieldCenterEvenIfNoShield(),
                            targetShip.getShield().getRadius(),
                            targetShip.getShield().getFacing() + (targetShip.getShield().getActiveArc() / 2f));
                    Vector2f closestPoint2 = Misc.closestPointOnSegmentToPoint(targetShip.getShieldCenterEvenIfNoShield(),
                            corner2, missile.getLocation());

                    if (MathUtils.getDistance(closestPoint1, missile.getLocation()) < PROXIMITY_FUSE_RANGE
                            || MathUtils.getDistance(closestPoint2, missile.getLocation()) < PROXIMITY_FUSE_RANGE) {
                        explode();
                        return;
                    }
                }
            }

            //Check for hull impact, if we didn't trigger on the shield
            float distanceToBounds = MathUtils.getDistance(CollisionUtils.getNearestPointOnBounds(missile.getLocation(), targetShip),
                    missile.getLocation());
            if (distanceToBounds < PROXIMITY_FUSE_RANGE) {
                explode();
            }
        }
    }
}
