//By Nicke535, edited from the vanilla shipsystem AI by Alex Mosolov
//Switches between two ammo racks
package data.scripts.ai;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.*;
import com.fs.starfarer.api.util.IntervalUtil;
import org.lazywizard.lazylib.CollisionUtils;
import org.lazywizard.lazylib.MathUtils;
import org.lazywizard.lazylib.VectorUtils;
import org.lazywizard.lazylib.combat.CombatUtils;
import org.lwjgl.util.vector.Vector2f;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class loa_missiletube_ai implements ShipSystemAIScript {
    //How close is a valid target for using the shipsystem?
    private static final float RANGE = 2000f;

    //All valid hull sizes that we will trigger against
    private static final List<ShipAPI.HullSize> VALID_TARGET_SIZES = new ArrayList<>();
    static {
        VALID_TARGET_SIZES.add(ShipAPI.HullSize.FRIGATE);
        VALID_TARGET_SIZES.add(ShipAPI.HullSize.DESTROYER);
        VALID_TARGET_SIZES.add(ShipAPI.HullSize.CRUISER);
        VALID_TARGET_SIZES.add(ShipAPI.HullSize.CAPITAL_SHIP);
    }

    //How often does the script check for an oppurtunity to activate?
    private IntervalUtil tracker = new IntervalUtil(0.1f, 0.2f);

    //At what failure chance will the AI stop using the system for DPS gain and only use it for ammo refill?
    private static final float MAXIMUM_FAIL_CHANCE_FOR_DPS = 0.40f;

    //A fudge number to make the AI slightly more/slightly less willing to trigger for DPS; high values means it needs to earn more DPS for it to be worthwhile
    //In more technical terms: at 1f, it needs to earn at least 1 second of reload on at least one weapon to use the system, at 2f it needs at least 2 seconds etc.
    private static final float FUDGE_RELOAD_NUMBER = 2f;

    //Used in-script to simplify later calls and some other tracking
    private ShipAPI ship;
    private CombatEngineAPI engine;
    private ShipwideAIFlags flags;
    private ShipSystemAPI system;

    //Initialize some variables for later use
    public void init(ShipAPI ship, ShipSystemAPI system, ShipwideAIFlags flags, CombatEngineAPI engine) {
        this.ship = ship;
        this.flags = flags;
        this.engine = engine;
        this.system = system;
    }

    //Main advance loop
    @SuppressWarnings("unchecked")
    public void advance(float amount, Vector2f missileDangerDir, Vector2f collisionDangerDir, ShipAPI target) {
        //Don't run when we can't use the shipsystem
        if (!system.getState().equals(ShipSystemAPI.SystemState.IDLE)) { return; }

        //Advance the tracker
        tracker.advance(amount);
        if (tracker.intervalElapsed()) {
            int missileWeps = 0;
            int emptyWeps = 0;
            boolean canUseForDPS = false;
            boolean canUseForDPSAmmoless = true;
            float reloadScore = 0f;
            float dpsScore = 0f;
            for (WeaponAPI wep : ship.getAllWeapons()) {
                //Ignore non-missiles
                if (wep.getType() != WeaponAPI.WeaponType.MISSILE) {
                    continue;
                }
                missileWeps++;

                //If it's out of ammo, register that
                if (wep.getAmmo() <= 0) {
                    emptyWeps++;
                }
				if (wep.usesAmmo()) {
					reloadScore += (float)wep.getAmmo() / (float)wep.getMaxAmmo();
				} else {
					reloadScore += 1f;
				}

                //Also store how many weapons, and how much said weapons, are on cooldown. Also store whether we're going to get *any* DPS from this
                if (wep.getCooldownRemaining() < wep.getCooldown()) {
                    dpsScore += 1f - (wep.getCooldownRemaining() / wep.getCooldown());
                    if (wep.getCooldownRemaining() > system.getChargeUpDur()+system.getChargeActiveDur()+FUDGE_RELOAD_NUMBER) {
                        if (wep.usesAmmo()) {
                            canUseForDPSAmmoless = false;
                        }
                        canUseForDPS = true;
                    }
                }
            }
            dpsScore /= missileWeps;

            //Never trigger if our reload score is worse after using the system compared to before
            reloadScore /= (float)missileWeps;
            float otherReloadScore = 1f;
            if (Global.getCombatEngine().getCustomData().get("loa_dual_missile_racks_" + ship.getId() + "_reloadscore") instanceof Float) {
                otherReloadScore = (float)Global.getCombatEngine().getCustomData().get("loa_dual_missile_racks_" + ship.getId() + "_reloadscore");
            }
            if (otherReloadScore < reloadScore) {
                return;
            }

            //Only trigger for DPS if we're actually gaining DPS... also, don't trigger for DPS if our fail chance is too high (unless we're triggering for ammoless missiles only)
            float otherDpsScore = 0f;
            if (Global.getCombatEngine().getCustomData().get("loa_dual_missile_racks_" + ship.getId() + "_dpsscore") instanceof Float) {
                otherDpsScore = (float)Global.getCombatEngine().getCustomData().get("loa_dual_missile_racks_" + ship.getId() + "_dpsscore");
            }
            float failChance = 0f;
            if (Global.getCombatEngine().getCustomData().get("loa_dual_missile_racks_" + ship.getId() + "_failchance") instanceof Float) {
                failChance = (float)Global.getCombatEngine().getCustomData().get("loa_dual_missile_racks_" + ship.getId() + "_failchance");
            }
            if ((failChance < MAXIMUM_FAIL_CHANCE_FOR_DPS || canUseForDPSAmmoless) && canUseForDPS && dpsScore < otherDpsScore) {
                ship.useSystem();
                return;
            }

            //Also trigger if we are out of ammo and have a target in range, but only if the other rack has more ammo
            if (missileWeps <= emptyWeps && otherReloadScore > reloadScore) {
                for (ShipAPI potTarget : CombatUtils.getShipsWithinRange(ship.getLocation(), RANGE)) {
                    if (VALID_TARGET_SIZES.contains(potTarget.getHullSize()) && potTarget.getOwner() != ship.getOwner()) {
                        ship.useSystem();
                        return;
                    }
                }
            }
        }
    }
}

