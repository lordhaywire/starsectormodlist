//Credit goes to Psiyon for his firecontrol AI script.
package data.scripts.ai;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.*;
import com.fs.starfarer.api.util.IntervalUtil;
import org.lazywizard.lazylib.MathUtils;
import org.lwjgl.util.vector.Vector2f;

import java.awt.*;

public class loa_NickeAmmoSwapperAI implements ShipSystemAIScript {

    //Time the target's shields have to be down for the ship to consider swapping to HE rounds
    private static final float SHIELD_OPPORTUNITY_DOWNTIME = 2f;

    //Flux level the target has to be at to consider swapping to HE
    private static final float HIGH_FLUX_LEVEL = 0.85f;

    //The ship swaps to HE when its target overloads/vents for more than this many seconds
    private static final float OVERLOAD_TIME_TO_SWAP = 1f;
    private static final float VENT_TIME_TO_SWAP = 1f;

    //Which ammo type is which number?
    private static final int KE_AMMO_NUM = 1;
    private static final int HE_AMMO_NUM = 2;

    //Is our debug mode on?
    private static final boolean DEBUG_MODE = false;


    private ShipSystemAPI system;
    private ShipAPI ship;
    private ShipAPI lastTarget;
    private float timeShieldInactive = 0;

    //Sets an interval for once every 0.21-0.24 seconds. (meaning the code will only run once this interval has elapsed, not every frame)
    private final IntervalUtil tracker = new IntervalUtil(0.21f, 0.24f);

    @Override
    public void init(ShipAPI ship, ShipSystemAPI system, ShipwideAIFlags flags, CombatEngineAPI engine) {
        this.ship = ship;
        this.system = system;
    }

    @Override
    public void advance(float amount, Vector2f missileDangerDir, Vector2f collisionDangerDir, ShipAPI target) {
        //Are we overloading or venting? Do nothing, we can't use the system
        if (ship.getFluxTracker().isOverloadedOrVenting()) {
            return;
        }

        //This happens more than we want
        if (target == null) {
            Object manouverTarget = ship.getAIFlags().getCustom(ShipwideAIFlags.AIFlags.MANEUVER_TARGET);
            if (manouverTarget instanceof ShipAPI && ((ShipAPI) manouverTarget).getOwner() != ship.getOwner()) {
                target = (ShipAPI)manouverTarget;
            }
        }

        //When switching targets, reset shield inactive time
        if (lastTarget != target) {
            timeShieldInactive = 0f;
            lastTarget = target;
        }

        tracker.advance(amount);
        timeShieldInactive += amount;

        //Once the interval has elapsed...
        if (tracker.intervalElapsed()) {
            //Weapon disabled: don't do anything
            float weaponRange = getWeaponRange();
            if (weaponRange <= -1f) {
                if (DEBUG_MODE) {Global.getCombatEngine().addFloatingText(ship.getLocation(), "No valid weapon!", 20f, Color.RED, ship, 0.5f, 2f); }
                return;
            }

            //No target: just use KE
            if (target == null) {
                setToAmmoType(KE_AMMO_NUM);
                if (DEBUG_MODE) {Global.getCombatEngine().addFloatingText(ship.getLocation(), "No target!", 20f, Color.RED, ship, 0.5f, 2f); }
                return;
            }

            boolean targetHasShields = !(target.getShield() == null
                                         || target.getShield().getType().equals(ShieldAPI.ShieldType.NONE)
                                         || target.getShield().getType().equals(ShieldAPI.ShieldType.PHASE));
            if (targetHasShields && target.getShield().isOn() && target.getShield().isWithinArc(ship.getLocation())) {
                timeShieldInactive = 0f;
            }


            //Target without shielding: use our HE
            if (!targetHasShields) {
                setToAmmoType(HE_AMMO_NUM);
                if (DEBUG_MODE) {Global.getCombatEngine().addFloatingText(ship.getLocation(), "No shields!", 20f, Color.RED, ship, 0.5f, 2f); }
            }
            //Target has shields, but is out of range: use KE
            else if (MathUtils.getDistance(ship.getLocation(), target.getLocation()) > weaponRange) {
                setToAmmoType(KE_AMMO_NUM);
                if (DEBUG_MODE) {Global.getCombatEngine().addFloatingText(ship.getLocation(), "Out of range!", 20f, Color.RED, ship, 0.5f, 2f); }
            }
            //Target has shields, but they have diabled their shields at high flux/for a long time: use HE
            else if (timeShieldInactive >= SHIELD_OPPORTUNITY_DOWNTIME || (target.getShield().isOff() && target.getFluxLevel() >= HIGH_FLUX_LEVEL)) {
                setToAmmoType(HE_AMMO_NUM);
                if (DEBUG_MODE) {Global.getCombatEngine().addFloatingText(ship.getLocation(), "Shield opportunity!", 20f, Color.RED, ship, 0.5f, 2f); }
            }
            //Target is overloading and has a pretty long time left on it: use HE
            else if ((target.getFluxTracker().isOverloaded() && target.getFluxTracker().getOverloadTimeRemaining() > OVERLOAD_TIME_TO_SWAP)
                     || (target.getFluxTracker().isVenting() && target.getFluxTracker().getTimeToVent() > VENT_TIME_TO_SWAP)) {
                setToAmmoType(HE_AMMO_NUM);
                if (DEBUG_MODE) {Global.getCombatEngine().addFloatingText(ship.getLocation(), "Overload/Vent!", 20f, Color.RED, ship, 0.5f, 2f); }
            }
            //Default: use KE
            else {
                setToAmmoType(KE_AMMO_NUM);
                if (DEBUG_MODE) {Global.getCombatEngine().addFloatingText(ship.getLocation(), "Default!", 20f, Color.RED, ship, 0.5f, 2f); }
            }
        }
    }

    private void activateSystem() {
        if (!system.isOn()) {
            ship.useSystem();
        }
    }

    private void setToAmmoType(int ammoNumber) {
        if (system.getAmmo() != ammoNumber && system.getCooldownRemaining() <= 0f && system.getState().equals(ShipSystemAPI.SystemState.IDLE)) {
            activateSystem();
        }
    }

    //Returns -1f if the weapon is currently disabled
    private float getWeaponRange() {
        float returnValue = -1f;
        for (WeaponAPI wep : ship.getAllWeapons()) {
            if (wep.isDisabled()) {
                continue;
            }
            if (wep.getSpec().getWeaponId().equals("loa_nicke_gun")) {
                returnValue = wep.getRange();
                break;
            }
        }
        return returnValue;
    }
}
