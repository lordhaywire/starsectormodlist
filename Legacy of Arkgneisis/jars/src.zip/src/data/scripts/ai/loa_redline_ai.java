package data.scripts.ai;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.*;
import com.fs.starfarer.api.util.IntervalUtil;
import com.fs.starfarer.api.util.Misc;
import data.scripts.shipsystems.loa_warspeed;
import org.lazywizard.lazylib.MathUtils;
import org.lwjgl.util.vector.Vector2f;

/**
 * Handles the AI for the as-of-yet-unnamed speed boosting shipsystem
 * @author Nicke535
 */
public class loa_redline_ai implements ShipSystemAIScript {
    //Internal variables
    private ShipSystemAPI system;
    private ShipAPI ship;
	private float graceTracker = 0f;
	private float sinceLastTrackerElapse = 0f;

    //How often we check for AI conditions (min, max). Keep relatively low
    private final IntervalUtil tracker = new IntervalUtil(0.2f, 0.35f);
	
    //How long the system must be without a proper "on" condition for it to turn off
    private static final float GRACE_PERIOD = 1f;

    @Override
    public void init(ShipAPI ship, ShipSystemAPI system, ShipwideAIFlags flags, CombatEngineAPI engine) {
        this.ship = ship;
        this.system = system;
    }

    @Override
    public void advance(float amount, Vector2f missileDangerDir, Vector2f collisionDangerDir, ShipAPI target) {
        tracker.advance(amount);
		sinceLastTrackerElapse += amount;

        //Only run when our tracker is done
        if (tracker.intervalElapsed()) {
			graceTracker += sinceLastTrackerElapse;
			sinceLastTrackerElapse = 0f;

            //Basic data useful for several checks
            float ourWeaponRange = getLongestWeaponRange(ship);
            ShipAPI currentTarget = target;
            if (currentTarget == null) {
                if (ship.getAIFlags().getCustom(ShipwideAIFlags.AIFlags.MANEUVER_TARGET) instanceof ShipAPI) {
                    currentTarget = (ShipAPI) ship.getAIFlags().getCustom(ShipwideAIFlags.AIFlags.MANEUVER_TARGET);
                }
            }
            boolean chasingTarget = ship.getAIFlags().hasFlag(ShipwideAIFlags.AIFlags.PURSUING) ||
                                    ship.getAIFlags().hasFlag(ShipwideAIFlags.AIFlags.HARASS_MOVE_IN);


            //-- On approach to enemy, but not yet in range --//
            if (currentTarget != null && chasingTarget) {
                float targetWeaponRange = getLongestWeaponRange(currentTarget);
                float desiredStartRange = ourWeaponRange * 4f;

                if (targetWeaponRange > ourWeaponRange) {
                    desiredStartRange = targetWeaponRange;
                }

                if (MathUtils.getDistance(ship, currentTarget) > ourWeaponRange*0.75f && MathUtils.getDistance(ship, currentTarget) < desiredStartRange) {
                    activateSystem();
                    return;
                }
            }

            //-- Backing off --//
            if (ship.getAIFlags().hasFlag(ShipwideAIFlags.AIFlags.BACKING_OFF)
                    || ship.getAIFlags().hasFlag(ShipwideAIFlags.AIFlags.RUN_QUICKLY)) {
                activateSystem();
                return;
            }

            //-- Chasing an enemy that's faster than us, and the enemy is running away --//
            if (currentTarget != null && chasingTarget) {
                if (currentTarget.getAIFlags().hasFlag(ShipwideAIFlags.AIFlags.BACKING_OFF)
                        || currentTarget.getAIFlags().hasFlag(ShipwideAIFlags.AIFlags.RUN_QUICKLY)) {
                    if (currentTarget.getMaxSpeed() > ship.getMaxSpeed()) {
                        activateSystem();
                        return;
                    }
                }
            }

            //If no earlier conditions match, and our grace period is up, deactivate the system
			if (graceTracker >= GRACE_PERIOD) {					
				deactivateSystem();
			}
        }
    }

    //Function for getting the maximum range on the ship
    private float getLongestWeaponRange (ShipAPI target) {
        //Go through all weapons, discard missiles, and return the highest range
        float maxRange = 0f;
        for (WeaponAPI wep : target.getAllWeapons()) {
            if (wep.getType() == WeaponAPI.WeaponType.MISSILE) {
                continue;
            }

            if (maxRange < wep.getRange()) {
                maxRange = wep.getRange();
            }
        }
        return maxRange;
    }

    private void deactivateSystem() {
        if (system.isOn()) {
            ship.useSystem();
        }
    }

    private void activateSystem() {
		graceTracker = 0f;
        if (!system.isOn()) {
            ship.useSystem();
        }
    }
}
