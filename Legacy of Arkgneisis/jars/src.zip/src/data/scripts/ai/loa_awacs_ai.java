//By Nicke535, edited from the vanilla shipsystem AI by Alex Mosolov
//Activates the system fairly aggressively, unless there is a better target within 1.5x of activation range. Is less conservative with the first charge of a shipsystem
package data.scripts.ai;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.*;
import com.fs.starfarer.api.util.IntervalUtil;
import org.lazywizard.lazylib.MathUtils;
import org.lazywizard.lazylib.combat.CombatUtils;
import org.lwjgl.util.vector.Vector2f;

import java.awt.*;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map;
import java.util.Queue;

public class loa_awacs_ai implements ShipSystemAIScript {
    //The range at which the AOE benefits are applied.
    //Ideally, you would remove this and import it from the system script instead, but I can't myself since I don't know how you've renamed it/placed it
    public static final float ACTIVE_RANGE = 1750f;

    //If there are no enemies within this range, we don't bother keeping the system active since we're most likely not even in combat
    private static final float PEACEFUL_RANGE = 3000f;

    //Map for determining how important a certain ship is compared to another, by hull size
    //A hullsize with 2 counts as 2 ships for the purpose of activating the system, while 0 means they are ignored
    private static final Map<ShipAPI.HullSize, Float> THREAT_SIZE_MAP = new HashMap<>();
    static {
        THREAT_SIZE_MAP.put(ShipAPI.HullSize.FIGHTER, 0f);
        THREAT_SIZE_MAP.put(ShipAPI.HullSize.FRIGATE, 1f);
        THREAT_SIZE_MAP.put(ShipAPI.HullSize.DESTROYER, 1f);
        THREAT_SIZE_MAP.put(ShipAPI.HullSize.CRUISER, 2f);
        THREAT_SIZE_MAP.put(ShipAPI.HullSize.CAPITAL_SHIP, 3f);
    }

    //How long does the AI "remember" hull/armor damage (in seconds)?
    private static final float DAMAGE_REMEMBER_TIME = 1.5f;

    //How much (in percentage, 0.1f = 10%) hull or armor can the ship lose before being afraid?
    private static final float HULL_LOSS_SCARE_LEVEL = 0.05f;
    private static final float ARMOR_LOSS_SCARE_LEVEL = 0.1f;

    //The range at which the AI detects threatening missiles
    public static final float MISSILE_THREAT_RANGE = 250f;

    //How long is the AI "scared" for when a threatening situation comes up? (it won't use the shipsystem while scared)
    private static final float SCARE_TIME = 5f;

    //How often does the script check for activation/deactivation?
    private IntervalUtil tracker = new IntervalUtil(0.05f, 0.1f);


    //--Used in-script to simplify later calls and some other tracking: don't touch--
    private ShipAPI ship;
    private CombatEngineAPI engine;
    private ShipwideAIFlags flags;
    private ShipSystemAPI system;
    private Queue<DamageRememberer> hullStatusQueue = new LinkedList<>();
    private Queue<DamageRememberer> armorStatusQueue = new LinkedList<>();
    private float scaredCounter = 0f;
    private boolean currentlyScaredOfMissiles = false;

    //Initialize some variables for later use
    public void init(ShipAPI ship, ShipSystemAPI system, ShipwideAIFlags flags, CombatEngineAPI engine) {
        this.ship = ship;
        this.flags = flags;
        this.engine = engine;
        this.system = system;
    }

    //Main advance loop
    @SuppressWarnings("unchecked")
    public void advance(float amount, Vector2f missileDangerDir, Vector2f collisionDangerDir, ShipAPI target) {
        //Dequeue any "old" damage data, regardless of whether it's used or not
        for (DamageRememberer rem : hullStatusQueue) {
            rem.tick(amount);
        }
        while (hullStatusQueue.peek() != null && hullStatusQueue.peek().timeAgo >= DAMAGE_REMEMBER_TIME) {
            hullStatusQueue.poll();
        }
        for (DamageRememberer rem : armorStatusQueue) {
            rem.tick(amount);
        }
        while (armorStatusQueue.peek() != null && armorStatusQueue.peek().timeAgo >= DAMAGE_REMEMBER_TIME) {
            armorStatusQueue.poll();
        }

        //If we're scared, just deactivate the system and return
        if (scaredCounter > 0f) {
            scaredCounter -= amount;
            deactivateSystem();
            //If we're scared of missiles, we might prolong our afraid time
            if (currentlyScaredOfMissiles) {
                for (MissileAPI msl : CombatUtils.getMissilesWithinRange(ship.getLocation(), MISSILE_THREAT_RANGE)) {
                    if (msl.getOwner() != ship.getOwner() && !msl.didDamage() && Global.getCombatEngine().isEntityInPlay(msl)) {
                        scaredCounter = SCARE_TIME;
                        return;
                    }
                }
            }
            return;
        } else {
            currentlyScaredOfMissiles = false;
        }

        //Check our tracker if we should do anything
        tracker.advance(amount);
        if (tracker.intervalElapsed()) {
            //Store the hull damage and armor status this frame
            float hullThisFrame = ship.getHullLevel();
            hullStatusQueue.add(new DamageRememberer(hullThisFrame));
            //Armor is trickier, but uses the same overall method
            float armorThisFrame = 0f;
            int numberOfCells = 0;
            for (int ix = 0; ix < (ship.getArmorGrid().getLeftOf() + ship.getArmorGrid().getRightOf()); ix++) {
                for (int iy = 0; iy < (ship.getArmorGrid().getAbove() + ship.getArmorGrid().getBelow()); iy++) {
                    armorThisFrame += ship.getArmorGrid().getArmorFraction(ix, iy);
                    numberOfCells++;
                }
            }
            armorThisFrame /= (float)numberOfCells;
            armorStatusQueue.add(new DamageRememberer(armorThisFrame));

            //If we should be scared, we don't do any other checks, so check that first
            if ((hullStatusQueue.peek() != null && (hullStatusQueue.peek().status - hullThisFrame) > HULL_LOSS_SCARE_LEVEL)
                || (armorStatusQueue.peek() != null && (armorStatusQueue.peek().status - armorThisFrame) > ARMOR_LOSS_SCARE_LEVEL)) {
                scaredCounter = SCARE_TIME;
                deactivateSystem();
                return;
            }
            for (MissileAPI msl : CombatUtils.getMissilesWithinRange(ship.getLocation(), MISSILE_THREAT_RANGE)) {
                //Ignore friendly missiles
                if (msl.getOwner() != ship.getOwner()) {
                    //Imperfect, won't catch all custom missile AIs unfortunately, only those that allow their target to be read
                    if (msl.getMissileAI() instanceof GuidedMissileAI) {
                        GuidedMissileAI guidedAI = (GuidedMissileAI) msl.getMissileAI();
                        if (guidedAI.getTarget() != null) {
                            if (guidedAI.getTarget().equals(ship)) {scaredCounter = SCARE_TIME;
                                currentlyScaredOfMissiles = true;
                                deactivateSystem();
                                return;
                            }
                        }
                    }
                }
            }

            //Check allied ships within system range, enemies within their weapon range, and compare the two
            float enemyWeight = 0f;
            float allyWeight = 0f;
            for (ShipAPI otherShip : CombatUtils.getShipsWithinRange(ship.getLocation(), PEACEFUL_RANGE)) {
                if (otherShip.getOwner() == ship.getOwner() && MathUtils.getDistance(ship, otherShip) < ACTIVE_RANGE) {
                    allyWeight += THREAT_SIZE_MAP.get(otherShip.getHullSize());
                }

                else if (otherShip.getOwner() != ship.getOwner() && MathUtils.getDistance(otherShip, ship) < getLongestWeaponRange(otherShip)) {
                    enemyWeight += THREAT_SIZE_MAP.get(otherShip.getHullSize());
                }
            }
            float usabilityFactor = allyWeight / (Math.max(1f, enemyWeight));

            //Deactivate if there are no enemies within our peace range
            boolean hasPeace = true;
            for (ShipAPI otherShip : CombatUtils.getShipsWithinRange(ship.getLocation(), PEACEFUL_RANGE)) {
                if (otherShip.getOwner() != ship.getOwner()) {
                    hasPeace = false;
                    break;
                }
            }
            if (hasPeace) {
                deactivateSystem();
                return;
            }

            //Choose between two different activation conditions depending on if we're escorting someone at the moment
            CombatAssignmentType assignmentType = CombatAssignmentType.ASSAULT;
            if (engine.getFleetManager(ship.getOwner()) != null && engine.getFleetManager(ship.getOwner()).getTaskManager(false) != null && engine.getFleetManager(ship.getOwner()).getTaskManager(false).getAssignmentFor(ship) != null) {
                assignmentType = engine.getFleetManager(ship.getOwner()).getTaskManager(false).getAssignmentFor(ship).getType();
            }
            if (assignmentType.equals(CombatAssignmentType.LIGHT_ESCORT) || assignmentType.equals(CombatAssignmentType.MEDIUM_ESCORT) || assignmentType.equals(CombatAssignmentType.HEAVY_ESCORT)) {
                //--ESCORT--
                //Deactivate if there's way too many enemies, otherwise activate
                if (usabilityFactor < 1f/3f) {
                    deactivateSystem();
                } else {
                    activateSystem();
                }
            } else {
                //--NON-ESCORT--
                //Deactivate if there are too many enemies, otherwise activate
                if (usabilityFactor < 1f) {
                    deactivateSystem();
                } else {
                    activateSystem();
                }
            }
        }
    }

    //Function for getting the maximum range on the ship
    private float getLongestWeaponRange (ShipAPI target) {
        //Go through all weapons, discard missiles, and return the highest range
        float maxRange = 0f;
        for (WeaponAPI wep : target.getAllWeapons()) {
            if (wep.getType() == WeaponAPI.WeaponType.MISSILE) {
                continue;
            }

            if (maxRange < wep.getRange()) {
                maxRange = wep.getRange();
            }
        }
        return maxRange;
    }

    //Utility class for storing damage data
    private class DamageRememberer {
        protected float status;
        protected float timeAgo;
        DamageRememberer (float status) {
            timeAgo = 0f;
            this.status = status;
        }

        protected void tick(float amount) {
            this.timeAgo += amount;
        }
    }

    private void deactivateSystem() {
        if (system.isOn()) {
            ship.useSystem();
        }
    }

    private void activateSystem() {
        if (!system.isOn()) {
            ship.useSystem();
        }
    }
}

