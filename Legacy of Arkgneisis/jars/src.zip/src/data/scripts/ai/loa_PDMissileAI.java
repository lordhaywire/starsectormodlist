package data.scripts.ai;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.CollisionClass;
import com.fs.starfarer.api.combat.CombatEntityAPI;
import com.fs.starfarer.api.combat.DamageType;
import com.fs.starfarer.api.combat.MissileAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipCommand;
import static java.awt.Color.red;
import org.lazywizard.lazylib.MathUtils;
import org.lazywizard.lazylib.VectorUtils;
import org.lazywizard.lazylib.combat.AIUtils;
import org.lwjgl.util.vector.Vector2f;

public class loa_PDMissileAI extends loa_BaseMissile
{
    public static final boolean DEBUG_MODE = false; // Default: false
    private static final float VELOCITY_DAMPING_FACTOR = 0.05f;

    public loa_PDMissileAI(MissileAPI missile, ShipAPI launchingShip)
    {
        super(missile, launchingShip);
        target = null; // Fixes a bug, and also ensures they ignore all manual targeting by the player or NPCs
    }

    @Override
    public void advance(float amount)
    {
        // This missile is a kinetic kill vehicle, and its "warhead" should *never* disarm
        missile.setArmingTime(0);
        missile.setArmedWhileFizzling(true);

        if (missile.isFading() || missile.isFizzling())
        {
            return;
        }

        if (!isTargetValid(target))
        {
            setTarget(findBestTarget());
            if (target == null)
            {
                missile.giveCommand(ShipCommand.ACCELERATE);
                return;
            }
        }

        float distance = MathUtils.getDistance(target.getLocation(), missile.getLocation()) - target.getCollisionRadius();

        float acceleration = missile.getAcceleration();
        float maxSpeed = missile.getMaxSpeed();

        Vector2f guidedTarget = interceptAdvanced(missile.getLocation(), missile.getVelocity().length(), acceleration, maxSpeed, target.getLocation(),
                target.getVelocity());
        if (guidedTarget == null)
        {
            Vector2f projection = new Vector2f(target.getVelocity());
            float scalar = distance / (missile.getVelocity().length() + 1f);
            projection.scale(scalar);
            guidedTarget = Vector2f.add(target.getLocation(), projection, null);
        }

        float velocityFacing = VectorUtils.getFacing(missile.getVelocity());
        float absoluteDistance = MathUtils.getShortestRotation(velocityFacing, VectorUtils.getAngle(missile.getLocation(), guidedTarget));
        float angularDistance = MathUtils.getShortestRotation(missile.getFacing(), VectorUtils.getAngle(missile.getLocation(), guidedTarget));
        float compensationDifference = MathUtils.getShortestRotation(angularDistance, absoluteDistance);
        if (Math.abs(compensationDifference) <= 75f)
        {
            angularDistance += 0.5f * compensationDifference;
        }
        float absDAng = Math.abs(angularDistance);

        missile.giveCommand(angularDistance < 0 ? ShipCommand.TURN_RIGHT : ShipCommand.TURN_LEFT);
        missile.giveCommand(ShipCommand.ACCELERATE);

        if (absDAng < 5)
        {
            float MFlightAng = VectorUtils.getAngle(new Vector2f(0, 0), missile.getVelocity());
            float MFlightCC = MathUtils.getShortestRotation(missile.getFacing(), MFlightAng);
            if (Math.abs(MFlightCC) > 20)
            {
                missile.giveCommand(MFlightCC < 0 ? ShipCommand.STRAFE_LEFT : ShipCommand.STRAFE_RIGHT);
            }
        }

        if (absDAng < Math.abs(missile.getAngularVelocity()) * VELOCITY_DAMPING_FACTOR)
        {
            missile.setAngularVelocity(angularDistance / VELOCITY_DAMPING_FACTOR);
        }
    }

    @Override
    protected CombatEntityAPI findBestTarget()
    {
        CombatEntityAPI closest = null;
        float distance;
        float closestDistance = Float.MAX_VALUE;

        float remainingRange = (missile.getMaxFlightTime() - missile.getElapsed()) * missile.getMaxSpeed();
        for (MissileAPI tmp : AIUtils.getNearbyEnemyMissiles(missile, remainingRange))
        {
            if (!isTargetValid(tmp))
            {
                continue;
            }

            // Determine threat of each incoming missile based on its damage, damage type, and EMP damage
            // For MIRVs, these figures are summed for all submunitions
            float baseDamage;
            float emp;
            DamageType damType;
            if (tmp.isMirv())
            {
                int numWarheads = tmp.getMirvNumWarheads();
                baseDamage = tmp.getMirvWarheadDamage() * numWarheads;
                emp = tmp.getMirvWarheadEMPDamage() * numWarheads;
                damType = tmp.getMirvWarheadDamageType();
            }
            else
            {
                baseDamage = tmp.getDamageAmount();
                emp = tmp.getEmpAmount();
                damType = tmp.getDamageType();
            }

            float damage
                    = (float) Math.sqrt(baseDamage * (damType == DamageType.FRAGMENTATION ? 0.33f : 1f) + emp * 0.33f);
            if (damage <= 0f)
            {
                damage = 1f;
            }

            distance = MathUtils.getDistance(tmp, missile.getLocation()) / damage;
            if (distance < closestDistance)
            {
                closest = tmp;
                closestDistance = distance;
            }

            // Debug indicator
            if (DEBUG_MODE)
            {
                Global.getCombatEngine().addFloatingText(tmp.getLocation(), "" + damage, 32, red, tmp, 0, 0);
            }
        }

        if (closest == null)
        {
            for (ShipAPI tmp : AIUtils.getEnemiesOnMap(missile))
            {
                if (!isTargetValid(tmp))
                {
                    continue;
                }
                float mod = 0f;
                if (!tmp.isFighter() && !tmp.isDrone())
                {
                    mod = 4000f;
                }
                distance = MathUtils.getDistance(tmp, missile.getLocation()) + mod;
                if (distance < closestDistance)
                {
                    closest = tmp;
                    closestDistance = distance;
                }
            }
        }

        return closest;
    }

    @Override
    protected boolean isTargetValid(CombatEntityAPI target)
    {
        if (target == null || (missile.getOwner() == target.getOwner()) || !Global.getCombatEngine().isEntityInPlay(target))
        {
            return false;
        }

        if (target instanceof MissileAPI)
        {
            MissileAPI m = (MissileAPI) target;
            if (m.getCollisionClass() == CollisionClass.NONE)
            {
                return false;
            }
        }
        else if (target instanceof ShipAPI)
        {
            ShipAPI ship = (ShipAPI) target;
            if (ship.isPhased() || !ship.isAlive())
            {
                return false;
            }
        }
        else if (target.getCollisionClass() == CollisionClass.NONE)
        {
            return false;
        }

        return true;
    }
}
