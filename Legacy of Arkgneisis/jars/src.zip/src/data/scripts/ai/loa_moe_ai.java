//By Nicke535
//Handles the AI for the M.O.E. mk2's AI
package data.scripts.ai;

import com.fs.starfarer.api.combat.*;
import com.fs.starfarer.api.util.IntervalUtil;
import org.lazywizard.lazylib.MathUtils;
import org.lazywizard.lazylib.combat.AIUtils;
import org.lwjgl.util.vector.Vector2f;

import java.util.ArrayList;
import java.util.List;

public class loa_moe_ai implements ShipSystemAIScript {
    //Internal variables
    private ShipSystemAPI system;
    private ShipAPI ship;
    private float timeWithoutFiring = 0f;
    private boolean hasShutDownFromHighFlux = false;

    //The "high flux" level to check for when determining if we've shut off from high (hard) flux
    private static final float HIGH_HARDFLUX_UPPER_LIMIT = 0.6f;
    //The hardflux limit we have to fall below to no longer be in our "shut off from high flux" mode
    private static final float HIGH_HARDFLUX_LOWER_LIMIT = 0.15f;

    //How often we check for AI conditions (min, max). Keep relatively low
    private final IntervalUtil tracker = new IntervalUtil(0.2f, 0.35f);
	
	//A counter for tracking just how long we've been at above 33% hardflux
	private float medHardFluxTimer = 0f;

    @Override
    public void init(ShipAPI ship, ShipSystemAPI system, ShipwideAIFlags flags, CombatEngineAPI engine) {
        this.ship = ship;
        this.system = system;
    }

    @Override
    public void advance(float amount, Vector2f missileDangerDir, Vector2f collisionDangerDir, ShipAPI target) {
        tracker.advance(amount);

        //Keep track of how long we haven't fired for, not counting missiles
        if (isAnyWeaponFiring(false, false)) {
            timeWithoutFiring = 0f;
        } else {
            timeWithoutFiring += amount;
        }

        //Keep track of medium-high hard flux
        if (ship.getHardFluxLevel() * ship.getFluxLevel() > 0.33f) {
            medHardFluxTimer += amount;
        } else {
            medHardFluxTimer = 0f;
        }

        //Check if the system is off and we're at a lot of hardflux, or if we've recovered from that state
        if (!system.isOn() && ship.getFluxTracker().getHardFlux()/ship.getMaxFlux() >= HIGH_HARDFLUX_UPPER_LIMIT) {
            hasShutDownFromHighFlux = true;
        } else if (ship.getFluxTracker().getHardFlux()/ship.getMaxFlux() <= HIGH_HARDFLUX_LOWER_LIMIT) {
            hasShutDownFromHighFlux = false;
        }

        //Wait for interval elapse before doing a check
        if (tracker.intervalElapsed()) {
            float ourTriggerRange = getLongestWeaponRange(ship);

            //Gets all enemies in range, and registers them in different lists based on properties
            List<ShipAPI> farEnemies = new ArrayList<>();           //Enemies within 150% of weapon range
            List<ShipAPI> mediumRangeEnemies = new ArrayList<>();   //Enemies within 120% of weapon range
            List<ShipAPI> closeEnemies = new ArrayList<>();         //Enemies within 110% weapon range
            List<ShipAPI> closeFighterEnemies = new ArrayList<>();  //Fighters get their own list
            for (ShipAPI potEnemy : AIUtils.getNearbyEnemies(ship, ourTriggerRange*1.5f)) {
                if (potEnemy.getHullSize().equals(ShipAPI.HullSize.FIGHTER)) {
                    if (MathUtils.getDistance(potEnemy, ship) <= ourTriggerRange) {
                        closeFighterEnemies.add(potEnemy);
                    }
                } else {
                    if (MathUtils.getDistance(potEnemy, ship) <= ourTriggerRange) {
                        closeEnemies.add(potEnemy);
                        mediumRangeEnemies.add(potEnemy);
                        farEnemies.add(potEnemy);
                    } else if (MathUtils.getDistance(potEnemy, ship) <= ourTriggerRange*1.1f) {
                        mediumRangeEnemies.add(potEnemy);
                        farEnemies.add(potEnemy);
                    } else {
                        farEnemies.add(potEnemy);
                    }
                }
            }

            float weight = 0f;
            /*-- Go through our conditions in order and add their weight --*/
            //No enemies in far range, enemy fighters or missiles in range
            if (farEnemies.isEmpty() && (!AIUtils.getNearbyEnemyMissiles(ship, ourTriggerRange).isEmpty() || !closeFighterEnemies.isEmpty())) {
                weight += 999f;
            }

            //At least one hostile in short range
            if (!closeEnemies.isEmpty()) {
                weight += 1f;
            }

            //Current target is within range, and is at 75% flux
            if (target != null) {
                if (MathUtils.getDistance(target, ship) <= ourTriggerRange && target.getFluxTracker().getFluxLevel() > 0.75f) {
                    weight += 0f;
                }
            }

            //No enemies in far range
            if (farEnemies.isEmpty()) {
                weight -= 998f;
            }

            //No hostiles in medium range
            if (mediumRangeEnemies.isEmpty()) {
                weight -= 1f;
            }

            //REALLY high soft flux
            if (ship.getFluxLevel() > 0.85f) {
                weight -= 997f;
            }

            //High hard-flux
            if (ship.getHardFluxLevel() * ship.getFluxLevel() > 0.5f) {
                weight -= 1f;

                //REALLY high hard flux
                if (ship.getHardFluxLevel() * ship.getFluxLevel() > 0.75f) {
                    weight -= 1f;
                }
            }

            //Somewhat medium hard-flux, but for over 15 seconds in a row
            if (medHardFluxTimer > 15f) {
                weight -= 1f;
            }

			//We haven't fired for 5 seconds
            if (timeWithoutFiring >= 3f) {
                weight -= 1f;
            }

            //Check if we've shut off the system when at high flux
            if (hasShutDownFromHighFlux) {
                weight -= 2f;
            }
            /*-- END OF WEIGHT DECLARATION --*/

            //If the weight is above 0, we activate. Otherwise, we deactivate
            if (weight > 0f) {
                activateSystem();
            } else {
                deactivateSystem();
            }
        }
    }

    //Function for getting the maximum range on the ship
    private float getLongestWeaponRange (ShipAPI target) {
        //Go through all weapons, discard those with too high rate-of-fire (only for the system ship) and missiles, and return the highest range
        float maxRange = 0f;
        for (WeaponAPI wep : target.getAllWeapons()) {
            if (wep.getType() == WeaponAPI.WeaponType.MISSILE) {
                continue;
            }

            if ((wep.getDerivedStats().getRoF() > 20f) && target == ship) {
                continue;
            }

            if (maxRange < wep.getRange()) {
                maxRange = wep.getRange();
            }
        }
        return maxRange;
    }

    //Function for tracking if any weapons on the ship are firing
    private boolean isAnyWeaponFiring (boolean countMissiles, boolean countPD) {
        //Go through all weapons and check if they're firing
        for (WeaponAPI wep : ship.getAllWeapons()) {
            if (wep.isDecorative()) {
                continue;
            }
            if (!countMissiles && wep.getType().equals(WeaponAPI.WeaponType.MISSILE)) {
                continue;
            }
            if (!countPD && wep.getSpec().getAIHints().contains(WeaponAPI.AIHints.PD)) {
                continue;
            }
            if (wep.isFiring() || wep.getChargeLevel() >= 1f) {
                return true;
            }
        }
        return false;
    }

    private void deactivateSystem() {
        if (system.isOn()) {
            ship.useSystem();
        }
    }

    private void activateSystem() {
        if (!system.isOn()) {
            ship.useSystem();
        }
    }
}
