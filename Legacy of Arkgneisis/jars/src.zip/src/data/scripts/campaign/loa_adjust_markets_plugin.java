//By Nicke535, spawns blueprints in a faction's military markets occasionally and removes Alastairs
package data.scripts.campaign;

import com.fs.starfarer.api.EveryFrameScript;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.*;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.campaign.listeners.EconomyTickListener;
import com.fs.starfarer.api.combat.ShipVariantAPI;
import com.fs.starfarer.api.fleet.FleetMemberAPI;
import com.fs.starfarer.api.impl.campaign.ids.Submarkets;
import com.fs.starfarer.api.loading.VariantSource;
import com.fs.starfarer.api.util.IntervalUtil;
import com.fs.starfarer.api.util.Misc;
import org.lazywizard.lazylib.MathUtils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class loa_adjust_markets_plugin implements EveryFrameScript {

    //The ID for the faction that has their markets adjusted
    private static final String FACTION = "al_ars";

    //The percentage chances for each blueprint to be available on the Military market each longTracker period
    //0.001f = 0.1% chance to happen each longTracker update per market
    private static final Map<String, Float> BLUEPRINT_CHANCES = new HashMap<>();
    static {
        BLUEPRINT_CHANCES.put("loa_arkmid1_package", 0.15f);
        BLUEPRINT_CHANCES.put("loa_arkmid2_package", 0.10f);
        BLUEPRINT_CHANCES.put("loa_arkmid3_package", 0.075f);
        BLUEPRINT_CHANCES.put("loa_arkmidw_package", 0.10f);
        BLUEPRINT_CHANCES.put("loa_alastair_package", 0.05f);
        BLUEPRINT_CHANCES.put("loa_osmond_package", 0.05f);
        BLUEPRINT_CHANCES.put("loa_pelletcannon_package", 0.075f);
        BLUEPRINT_CHANCES.put("loa_mk2bigram_package", 0.75f);
    }

    //The percentage of Alastairs that will be removed from military markets
    private static final float ALASTAIR_REMOVAL_PERCENT = 0.8f;

    //Our long tracker, determines how often the script runs some of the more periodic operations. This involves finding
    //all markets owned by our faction, and spawning blueprints. Counts in days
    private IntervalUtil longTracker = new IntervalUtil(29f, 31f);

    //Our listener, for listening for economy events
    private MarketUpdateListener listener;

    @Override
    public void advance( float amount ) {
        //Sanity check
        SectorAPI sector = Global.getSector();
        if (sector == null) {
            return;
        }

        //Ensure we have a listener
        if (listener == null) {
            listener = new MarketUpdateListener();
        }

        //For the Long tracker, we care about pausing, and count in Days
        float longAmount = Misc.getDays(amount);
        if (sector.isPaused()) {
            longAmount = 0f;
        }

        //Advance trackers
        longTracker.advance(longAmount);

        //Only run when our trackers says so
        if (longTracker.intervalElapsed()) {
            FactionAPI anarkasis = sector.getFaction(FACTION);

            //During the long tracker, we get all markets that the faction controls with military markets on them
            List<String> marketsToManipulate = new ArrayList<>();
            for (MarketAPI mrkt : Misc.getFactionMarkets(anarkasis)) {
                if (mrkt.getSubmarket(Submarkets.GENERIC_MILITARY) != null) {
                    marketsToManipulate.add(mrkt.getId());
                }
            }

            //We *also* check for adding blueprints during the long tracker's update, so do that too
            for (String mID : marketsToManipulate) {
                MarketAPI market = sector.getEconomy().getMarket(mID);

                //Failsafe, shouldn't happen unless something drastic happened in the sector
                if (market == null) {
                    continue;
                }

                //Now, we get the cargo for that submarket, and check each blueprint in the list to see if we spawn it
                //We also de-spawn the old ones in the process
                CargoAPI cargo = market.getSubmarket(Submarkets.GENERIC_MILITARY).getCargo();
                for (String s : BLUEPRINT_CHANCES.keySet()) {
                    cargo.removeItems(CargoAPI.CargoItemType.SPECIAL, new SpecialItemData(s, null), 5f);
                    if (Math.random() < BLUEPRINT_CHANCES.get(s)) {
                        cargo.addSpecial(new SpecialItemData(s,null), 1f);
                    }
                }
            }
        }
    }



    @Override
    public boolean isDone() {
        return false;
    }

    @Override
    public boolean runWhilePaused() {
        return false;
    }

    private class MarketUpdateListener extends BaseCampaignEventListener {
        private List<MarketAPI> marketsAlreadyCleaned = new ArrayList<>();

        private MarketUpdateListener() {
            super(true);
        }

        @Override
        public void reportPlayerOpenedMarket(MarketAPI market) {
            if (!marketsAlreadyCleaned.contains(market)) {
                //Only care about military markets
                if (market.getSubmarket(Submarkets.GENERIC_MILITARY) == null) {
                    return;
                }

                //Now, we get the cargo for that submarket, and remove 80% of the alistairs found there
                CargoAPI cargo = market.getSubmarket(Submarkets.GENERIC_MILITARY).getCargo();
                List<FleetMemberAPI> toRemove = new ArrayList<>();
                for (FleetMemberAPI ship : cargo.getMothballedShips().getMembersListCopy()) {
                    if (ship.getHullId().contains("loamt_alastair") && Math.random() < ALASTAIR_REMOVAL_PERCENT) {
                        toRemove.add(ship);
                    }
                }
                for (FleetMemberAPI ship : toRemove) {
                    cargo.getMothballedShips().removeFleetMember(ship);
                }

                Global.getSector().getCampaignUI().addMessage("Cleanup performed!");
                marketsAlreadyCleaned.add(market);
            }
        }

        @Override
        public void reportEconomyMonthEnd() {
            marketsAlreadyCleaned.clear();
        }
    }
}