package data.scripts.campaign.rulecmd;

import com.fs.starfarer.api.campaign.InteractionDialogAPI;
import com.fs.starfarer.api.campaign.rules.MemKeys;
import com.fs.starfarer.api.campaign.rules.MemoryAPI;
import com.fs.starfarer.api.characters.CharacterCreationData;
import com.fs.starfarer.api.impl.campaign.rulecmd.BaseCommandPlugin;
import com.fs.starfarer.api.util.Misc;
import data.scripts.al_ArkgneisisModPlugin;
import java.util.List;
import java.util.Map;

/**
 * Author: SafariJohn
 * Description: This command is used during new game creation to pick up the sector's size and age so we can use them later.
 */
public class LoA_SaveSectorData extends BaseCommandPlugin {

    @Override
	public boolean execute(String ruleId, InteractionDialogAPI dialog, List<Misc.Token> params, Map<String, MemoryAPI> memoryMap) {
		if (dialog == null) return false;

		CharacterCreationData data = (CharacterCreationData) memoryMap.get(MemKeys.LOCAL).get("$characterData");

        al_ArkgneisisModPlugin.setSectorAge(data.getSectorAge());
        al_ArkgneisisModPlugin.setSectorSize(data.getSectorSize());

		return true;
	}
}
