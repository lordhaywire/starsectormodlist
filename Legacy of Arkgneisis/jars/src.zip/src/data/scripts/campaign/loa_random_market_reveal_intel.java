package data.scripts.campaign;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.FactionAPI;
import com.fs.starfarer.api.campaign.RepLevel;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.impl.campaign.intel.BaseIntelPlugin;
import com.fs.starfarer.api.ui.SectorMapAPI;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;

import java.awt.*;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

/**
 * A small intel script for pointing out a market on the map
 * @author Nicke535
 */
public class loa_random_market_reveal_intel extends BaseIntelPlugin {

    //In-script variables
    private MarketAPI target;
    private String intendedFaction;

    public loa_random_market_reveal_intel(MarketAPI target, String intendedFaction) {
        this.target = target;
        this.intendedFaction = intendedFaction;
    }

    @Override
    public void advance(float amount) {
        if (!intendedFaction.equals(target.getFactionId())) {
            endImmediately();
        }
    }

    //Handles the bullet-points on the intel screen. Only adds the title for now, that seems most compact and neat
    @Override
    public void createIntelInfo(TooltipMakerAPI info, ListInfoMode mode) {
        Color c = getTitleColor(mode);
        float opad = 10f;
        info.setParaSmallInsignia();
        info.addPara(getName(), c, 0f);
    }

    // The description shown on the intel screen summary
    @Override
    public void createSmallDescription(TooltipMakerAPI info, float width, float height) {
        Color h = Misc.getHighlightColor();
        Color g = Misc.getGrayColor();
        Color tc = Misc.getTextColor();
        float pad = 3f;
        float opad = 10f;

        info.addPara("Your quartermaster has logged the location of one of the bases belonging to " + target.getFaction().getDisplayNameLongWithArticle() + " for future reference.", pad);
    }

    //Gets the icon to display in the intel screen
    @Override
    public String getIcon() {
        return Global.getSettings().getSpriteName("loa_intel", "loa_raid");
    }


    @Override
    protected void notifyEnded() {
        super.notifyEnded();
        Global.getSector().removeScript(this);
    }

    @Override
    public void endAfterDelay() {
        super.endAfterDelay();
    }

    @Override
    protected void notifyEnding() {
        super.notifyEnding();
    }

    //Tags in the intel screen
    @Override
    public Set<String> getIntelTags(SectorMapAPI map) {
        Set<String> tags = super.getIntelTags(map);
        tags.add(target.getFactionId());
        return tags;
    }

    @Override
    public IntelSortTier getSortTier() {
        return IntelSortTier.TIER_6;
    }

    public String getSortString() {
        return target.getFaction().getDisplayName();
    }

    // What the intel is called
    public String getName() {
        return target.getFaction().getDisplayName()+" Base: "+target.getName();
    }

    @Override
    public FactionAPI getFactionForUIColors() {
        return target.getFaction();
    }

    public String getSmallDescriptionTitle() {
        return getName();
    }

    @Override
    public boolean shouldRemoveIntel() {
        return super.shouldRemoveIntel();
    }

    //The noise to play when a new message shows up
    @Override
    public String getCommMessageSound() {
        return getSoundMinorMessage();
    }

    @Override
    public SectorEntityToken getMapLocation(SectorMapAPI map) {
        return target.getPrimaryEntity();
    }
}
