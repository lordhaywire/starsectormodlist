package data.scripts.campaign.intel.bar.events;

import com.fs.starfarer.api.impl.campaign.intel.bar.PortsideBarEvent;
import com.fs.starfarer.api.impl.campaign.intel.bar.events.BaseBarEventCreator;

/**
 * Bar event creator for the random "reveal a market" events
 * @author Nicke535
 */
public class loa_RevealMarketBarEventCreator extends BaseBarEventCreator {
    private static final boolean DEBUG_MODE = true;

    public PortsideBarEvent createBarEvent() {
        return new loa_RevealMarketBarEvent();
    }

    @Override
    public float getBarEventAcceptedTimeoutDuration() {
        //Appears at most every 20 days... except in debug mode, of course
        if (DEBUG_MODE) {
            return 1f;
        } else {
            return 20f;
        }
    }

    @Override
    public float getBarEventFrequencyWeight() {
        //As common as all other "normal" bar events, except in debug mode
        if (DEBUG_MODE) {
            return 999999999f * super.getBarEventFrequencyWeight();
        } else {
            return super.getBarEventFrequencyWeight();
        }
    }
}