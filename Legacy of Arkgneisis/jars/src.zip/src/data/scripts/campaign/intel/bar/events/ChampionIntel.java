package data.scripts.campaign.intel.bar.events;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.*;
import com.fs.starfarer.api.campaign.listeners.FleetEventListener;
import com.fs.starfarer.api.campaign.rules.MemoryAPI;
import com.fs.starfarer.api.characters.PersonAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.fleet.FleetMemberAPI;
import com.fs.starfarer.api.impl.campaign.fleets.FleetFactoryV3;
import com.fs.starfarer.api.impl.campaign.fleets.FleetParamsV3;
import com.fs.starfarer.api.impl.campaign.ids.Abilities;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.ids.Tags;
import com.fs.starfarer.api.impl.campaign.intel.BaseIntelPlugin;
import com.fs.starfarer.api.ui.SectorMapAPI;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.api.util.Misc.Token;
import org.lwjgl.util.vector.Vector2f;

import java.awt.*;
import java.util.List;
import java.util.Map;
import java.util.Set;

import static com.fs.starfarer.api.impl.campaign.ids.FleetTypes.PATROL_LARGE;

public class ChampionIntel extends BaseIntelPlugin implements FleetEventListener {

    public static enum ChampionStage {
        FIND_CHAMPION,
        FIGHT_FLEET,
        DONE,
        DONE_EXTORTED,
        DONE_DEFEATED,
        DONE_NOFIGHT,
        ;
    }

    // minimum fleet points for pirate fleet
    private static int MIN_PIRATE_FP = 75;
    // pirate fleet FP will be increased or decreased by up to this number
    private static int PIRATE_FP_ADJUSTMENT = 20;

    public static int FINISHED_XP = 20000;

    protected SectorEntityToken champion;
    protected StarSystemAPI system;
    protected ChampionBarEvent event;
    public String icon;

    protected ChampionStage stage;

    // initial task
    public ChampionIntel(SectorEntityToken champion, ChampionBarEvent event) {
        this.champion = champion;
        this.event = event;

        Misc.makeImportant(champion, "champion");
        champion.getMemoryWithoutUpdate().set("$champion_eventRef", this);
        Global.getSector().addScript(this);

        stage = ChampionStage.FIND_CHAMPION;
    }

    @Override
    protected void advanceImpl(float amount) {
        if (stage == ChampionStage.FIGHT_FLEET && Global.getSector().getPlayerFleet().getContainingLocation() != system) {
            stage = ChampionStage.DONE_NOFIGHT;
            endAfterDelay();
            sendUpdateIfPlayerHasIntel(ChampionStage.DONE_NOFIGHT, false);
        }
    }

    @Override
    protected void notifyEnded() {
        super.notifyEnded();
        Global.getSector().removeScript(this);
    }

    // this is triggered by a CallEvent rulecommand in rules.csv
    @Override
    public boolean callEvent(String ruleId, InteractionDialogAPI dialog,
                             List<Token> params, Map<String, MemoryAPI> memoryMap) {
        String action = params.get(0).getString(memoryMap);

        MemoryAPI memory = champion.getMemoryWithoutUpdate();
        system = ChampionBarEvent.getSystem();
        if (action.equals("continue1")) {
            Misc.makeUnimportant(champion, "champion");
            if (Global.getSector().getFaction(Factions.PIRATES).getRelationshipLevel(Factions.PLAYER).isAtBest(RepLevel.NEUTRAL)) {
                stage = ChampionStage.FIGHT_FLEET;
                sendUpdate(ChampionStage.FIGHT_FLEET, dialog.getTextPanel());

                // fleet point calculation: player's FP with some variance, with a minimum floor
                float playerFP = Global.getSector().getPlayerFleet().getFleetPoints();
                double adjust = 0;
                if (Math.random() > 0.5) {
                    adjust = PIRATE_FP_ADJUSTMENT * Math.random();
                } else {
                    adjust = -PIRATE_FP_ADJUSTMENT * Math.random();
                }
                float newAdjust = (float)adjust;
                float fleetFP = playerFP + newAdjust;
                if (fleetFP < MIN_PIRATE_FP) {
                    fleetFP = MIN_PIRATE_FP;
                }

                FleetParamsV3 fleetparams = new FleetParamsV3(
                        null,
                        null,
                        Factions.PIRATES,
                        null,
                        PATROL_LARGE,
                        fleetFP, // combatPts
                        0f, // freighterPts
                        0f, // tankerPts
                        0f, // transportPts
                        0f, // linerPts
                        0f, // utilityPts
                        0.5f // qualityMod
                );
                CampaignFleetAPI fleet = FleetFactoryV3.createFleet(fleetparams);
                PersonAPI commander = fleet.getCommander();
                PersonAPI person = ChampionBarEvent.getPirate();

                commander.setName(person.getName());
                commander.setPortraitSprite(person.getPortraitSprite());
                commander.getMemoryWithoutUpdate().set("$champion_eventRef", this);

                champion.getContainingLocation().addEntity(fleet);
                Vector2f loc = Global.getSector().getPlayerFleet().getLocation();
                Vector2f loc2 = Misc.getPointAtRadius(loc, 50);
                fleet.setLocation(loc2.x, loc2.y);
                fleet.getStats().addTemporaryModPercent(100000f, "champion_sensorbuff", "Infinite sight", 3000f, fleet.getStats().getSensorRangeMod());
                fleet.addAssignment(FleetAssignment.INTERCEPT, Global.getSector().getPlayerFleet(), 10000f, "intercepting your fleet", null);
                fleet.removeAbility(Abilities.INTERDICTION_PULSE);
                fleet.addTag("ChampionFleet");
                fleet.addEventListener(this);
                Misc.makeHostile(fleet);
                if (Global.getSector().getFaction(Factions.PIRATES).getRelationshipLevel(Factions.PLAYER).isAtWorst(RepLevel.INHOSPITABLE)) {
                    Misc.makeNoRepImpact(fleet, "champion");
                }
            } else {
                stage = ChampionStage.DONE_NOFIGHT;
                endAfterDelay();
                sendUpdateIfPlayerHasIntel(ChampionStage.DONE_NOFIGHT, false);
            }
        }
        if (action.equals ("finish")) {
            stage = ChampionStage.DONE_EXTORTED;
            endAfterDelay();
            sendUpdate(ChampionStage.DONE_EXTORTED, dialog.getTextPanel());
        }
        return true;
    }

    @Override
    public void endAfterDelay() {
        //stage = ChampionStage.DONE;
        super.endAfterDelay();
    }

    @Override
    protected void notifyEnding() {
        super.notifyEnding();
    }

    public void reportBattleOccurred(CampaignFleetAPI fleet, CampaignFleetAPI primaryWinner, BattleAPI battle) {
        if (isDone()) return;

        CampaignFleetAPI playerFleet = Global.getSector().getPlayerFleet();
        if (!battle.isPlayerInvolved() || !battle.isInvolved(fleet) || battle.onPlayerSide(fleet)) {
            return;
        }

        if (stage == ChampionStage.FIGHT_FLEET) {
            for (FleetMemberAPI member : playerFleet.getMembersWithFightersCopy()) {
                //Ignore fighters
                if (member.getHullSpec().getHullSize() == ShipAPI.HullSize.FIGHTER) {
                    continue;
                }

                //Then, check the ID. If we've got a Champion, end as done.
                if (member.getHullId().contains("loaht_champion1")) {
                    stage = ChampionStage.DONE;
                    endAfterDelay();
                    sendUpdateIfPlayerHasIntel(ChampionStage.DONE, false);
                    fleet.removeTag("ChampionFleet");
                }
            }
        }

        if (stage == ChampionStage.FIGHT_FLEET) {
            stage = ChampionStage.DONE_DEFEATED;
            endAfterDelay();
            sendUpdateIfPlayerHasIntel(ChampionStage.DONE_DEFEATED, false);
            fleet.removeTag("ChampionFleet");
        }
    }

    public void reportFleetDespawnedToListener(CampaignFleetAPI fleet, CampaignEventListener.FleetDespawnReason reason, Object param) {
        if (isDone()) return;

        return;
    }

    // popup when a new stage begins
    protected void addBulletPoints(TooltipMakerAPI info, ListInfoMode mode) {

        Color h = Misc.getHighlightColor();
        Color g = Misc.getGrayColor();
        float pad = 3f;
        float opad = 10f;

        float initPad = pad;
        if (mode == ListInfoMode.IN_DESC) initPad = opad;

        Color tc = getBulletColorForMode(mode);

        bullet(info);
        boolean isUpdate = getListInfoParam() != null;

        system = ChampionBarEvent.getSystem();

        if (stage == ChampionStage.FIND_CHAMPION) {
            info.addPara("Explore the %s", initPad, h, system.getName());
        }
        if (stage == ChampionStage.FIGHT_FLEET) {
            info.addPara("Leave the %s", initPad, h, system.getName());
        }
        initPad = 0f;

        unindent(info);
    }

    // setup for intel screen
    @Override
    public void createIntelInfo(TooltipMakerAPI info, ListInfoMode mode) {
        Color c = getTitleColor(mode);
        info.setParaSmallInsignia();
        info.addPara(getName(), c, 0f);
        info.setParaFontDefault();
        addBulletPoints(info, mode);

    }

    // intel screen description
    @Override
    public void createSmallDescription(TooltipMakerAPI info, float width, float height) {
        Color h = Misc.getHighlightColor();
        Color g = Misc.getGrayColor();
        Color tc = Misc.getTextColor();
        float pad = 3f;
        float opad = 10f;

        StarSystemAPI system = ChampionBarEvent.getSystem();

        if (stage == ChampionStage.FIND_CHAMPION) {
            info.addPara("Head out and explore the %s . There should " +
                    "be something of note somewhere in orbit around the system's star.", opad, h, system.getName());
        } else if (stage == ChampionStage.FIGHT_FLEET) {
            info.addPara("Leave the %s, spoils in hand.", opad, h, system.getName());
        }
        else  if (stage == ChampionStage.DONE){
            info.addPara("You retrieved the strange cruiser, defeating the treacherous pirate " +
                    "that arrived to rip it from your grasp.", opad);
        }
        else  if (stage == ChampionStage.DONE_EXTORTED){
            info.addPara("You gave up the strange cruiser to the trecherous pirate, " +
                    "but at least you made it out alive.", opad);
        }
        else if (stage == ChampionStage.DONE_NOFIGHT) {
            info.addPara("You retrieved the strange cruiser the veteran spacer informed you of, " +
                    "without any more complications.", opad);
        }
        else {
            info.addPara("Ambushed by a traitorous pirate, you were defeated after recovering " +
                    "the strange cruiser and did not manage to escape with the ship.", opad);
        }

        addBulletPoints(info, ListInfoMode.IN_DESC);

    }

    // gets
    @Override
    public String getIcon() {
        return Global.getSettings().getSpriteName("intel", "red_planet");
    }

    // tags in the intel screen
    @Override
    public Set<String> getIntelTags(SectorMapAPI map) {
        Set<String> tags = super.getIntelTags(map);
        tags.add(Tags.INTEL_STORY);
        tags.add(Tags.INTEL_EXPLORATION);
        return tags;
    }

    @Override
    public IntelSortTier getSortTier() {
        return IntelSortTier.TIER_2;
    }

    public String getSortString() {
        return "Champion";
    }

    // what it's called, with a different name once completed
    public String getName() {
        if (stage == ChampionStage.DONE || stage == ChampionStage.DONE_EXTORTED || stage == ChampionStage.DONE_NOFIGHT) {
            return "A Scent of Adventure - Completed";
        }
        if (stage == ChampionStage.DONE_DEFEATED) {
            return "A Scent of Adventure - Failed";
        }
        return "A Scent of Adventure";
    }

    @Override
    public FactionAPI getFactionForUIColors() {
        return super.getFactionForUIColors();
    }

    public String getSmallDescriptionTitle() {
        return getName();
    }

    // where the intel screen points to
    @Override
    public SectorEntityToken getMapLocation(SectorMapAPI map) {
        if (stage == ChampionStage.FIND_CHAMPION) {
            return champion;
        }
        return system.getStar();
    }

    @Override
    public boolean shouldRemoveIntel() {
        return super.shouldRemoveIntel();
    }

    // what noise is made when a new message shows up. api/util/Misc is where this is from
    @Override
    public String getCommMessageSound() {
        return getSoundMajorPosting();
    }

}