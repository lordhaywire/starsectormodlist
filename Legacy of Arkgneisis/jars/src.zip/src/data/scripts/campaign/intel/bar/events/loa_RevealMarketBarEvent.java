package data.scripts.campaign.intel.bar.events;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.*;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.campaign.rules.MemoryAPI;
import com.fs.starfarer.api.characters.FullName.Gender;
import com.fs.starfarer.api.characters.PersonAPI;
import com.fs.starfarer.api.impl.campaign.DebugFlags;
import com.fs.starfarer.api.impl.campaign.DerelictShipEntityPlugin;
import com.fs.starfarer.api.impl.campaign.ids.*;
import com.fs.starfarer.api.impl.campaign.intel.bar.events.BarEventManager;
import com.fs.starfarer.api.impl.campaign.intel.bar.events.BaseBarEventWithPerson;
import com.fs.starfarer.api.impl.campaign.procgen.DefenderDataOverride;
import com.fs.starfarer.api.impl.campaign.procgen.themes.BaseThemeGenerator;
import com.fs.starfarer.api.impl.campaign.procgen.themes.SalvageSpecialAssigner;
import com.fs.starfarer.api.impl.campaign.rulecmd.salvage.special.ShipRecoverySpecial;
import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.api.util.WeightedRandomPicker;
import data.scripts.campaign.loa_MarketRevealHandler;
import org.jetbrains.annotations.Nullable;
import org.lazywizard.lazylib.MathUtils;

import java.awt.*;
import java.util.List;
import java.util.*;

/**
 * Bar event for the "reveal a market" event
 * @author Nicke535
 */
public class loa_RevealMarketBarEvent extends BaseBarEventWithPerson {

    private enum OptionId {
        INIT,
        CONTINUE_BUY_DRINKS,
        CONTINUE_BRIBE,
        CONTINUE_3,
        CONTINUE_4,
        LEAVE,
    }

    //The sounds to play when buying drinks and starting a bar brawl, respectively
    private static final String BUY_DRINKS_SOUND = "loa_bar_cheers";
    private static final String BAR_FIGHT_SOUND = "loa_bar_fight";

    //Prices for the different dialogue options
    private static final int BUY_DRINKS_PRICE = 5;
    private static final int BRIBE_PRICE = 1000;

    //The chance that a market will be revealed when buying drinks
    private static final float BUY_DRINKS_REVEAL_CHANCE = 0.4f;

    //The chance to reveal 3 markets instead of 2 when bribing
    private static final float BONUS_BRIBERY_REVEAL_CHANCE = 0.5f;

    //The success chance of bribery
    private static final float BRIBERY_SUCCESS_CHANCE = 0.75f;

    //The percentage cost of starting a bar brawl (a percentage of your owned credits)
    private static final float BAR_BRAWL_PERCENTAGE_COST = 0.25f;

    //The flat maximum cost of starting a bar brawl (used as a cap for the cost above)
    private static final int BAR_BRAWL_MAX_COST = 20000;

    /* - These are all configurations for the person in the event - */
    @Override
    protected String getPersonFaction() {
        return Factions.PIRATES;
    }
    @Override
    protected String getPersonRank() {
        return Ranks.SPACE_CAPTAIN;
    }
    @Override
    protected String getPersonPost() {
        return Ranks.POST_MERCENARY;
    }
    @Override
    protected Gender getPersonGender() {
        return Gender.ANY;
    }
    protected String pickMalePortrait() {
        WeightedRandomPicker<String> post = new WeightedRandomPicker<String>();
        post.add("graphics/portraits/portrait_pirate02.png");
        post.add("graphics/portraits/portrait_pirate03.png");
        post.add("graphics/portraits/portrait_mercenary04.png");
        post.add("graphics/portraits/portrait33.png");
        return post.pick();
    }
    protected String pickFemalePortrait() {
        WeightedRandomPicker<String> post = new WeightedRandomPicker<String>();
        post.add("graphics/portraits/portrait14.png");
        post.add("graphics/portraits/portrait21.png");
        post.add("graphics/portraits/portrait29.png");
        post.add("graphics/portraits/portrait_mercenary05.png");
        return post.pick();
    }
    /* - End of person config - */

    //Sets up an NPC to show during the bar event. Picks a suitable portrait from the options listed above
    @Override
    protected void regen(MarketAPI market) {
        if (this.market == market) return;
        super.regen(market);

        if (person.getGender() == Gender.MALE) {
            person.setPortraitSprite(pickMalePortrait());
        } else {
            person.setPortraitSprite(pickFemalePortrait());
        }
    }

    //Prompts for the description and button prompt when entering the bar
    protected String pickDescription() {
        WeightedRandomPicker<String> post = new WeightedRandomPicker<String>();
        post.add("A veteran spacer clad in Society Blue is leaned against a support beam, casting an appraising glance into the throngs of bar patrons.");
        post.add("An unkempt man clad in Society Blue sits slouched over a drink, occasionally tilting their head up to glare into the crowd.");
        post.add("A gritty looking spacer shuffles by, almost running into you. As he forges on you catcha  glimpse of the 'Crooked Compass' of the Anarakis Reparations Society emblazoned on the back of his space suit.");
        return post.pick();
    }
    protected String pickPrompt() {
        WeightedRandomPicker<String> post = new WeightedRandomPicker<String>();
        post.add("Wait until the spacer's eyes meet your own, return a curious glare and move to join them.");
        post.add("Grab a pair of drinks from the bar and try to break the ice with the drunkard.");
        post.add("Try to grab the spacers attention and make your way over to them.");
        return post.pick();
    }

    //The text shown when you enter the bar screen. Picks a random description and prompt from the options listed above
    @Override
    public void addPromptAndOption(InteractionDialogAPI dialog, Map<String, MemoryAPI> memoryMap) {
        super.addPromptAndOption(dialog, memoryMap);

        regen(dialog.getInteractionTarget().getMarket());

        TextPanelAPI text = dialog.getTextPanel();
        text.addPara(pickDescription());

        Color c = Misc.getBasePlayerColor();
        //Color c = Misc.getHighlightColor();

        dialog.getOptionPanel().addOption(pickPrompt(), this,
                c, null);
    }

    //The dialogue itself
    @Override
    public void optionSelected(String optionText, Object optionData) {
        if (!(optionData instanceof OptionId)) {
            return;
        }
        OptionId option = (OptionId) optionData;

        Color t = Misc.getTextColor();
        Color h = Misc.getHighlightColor();
        Color n = Misc.getNegativeHighlightColor();
        float pad = 3f;

        OptionPanelAPI options = dialog.getOptionPanel();
        TextPanelAPI text = dialog.getTextPanel();
        options.clearOptions();

        switch (option) {
            case INIT:

                text.addPara("The spacer seems to be telling tall tales of adventure, you get snippits of their time working for the Society, but they've been careful to exclude any solid intel so far.");

                options.addOption("Hit up the barkeep and buy a round or two for everyone.", OptionId.CONTINUE_BUY_DRINKS);
                if (Global.getSector().getPlayerFleet().getCargo().getCredits().get() <= BUY_DRINKS_PRICE) {
                    options.setEnabled(OptionId.CONTINUE_BUY_DRINKS, false);
                    options.setTooltip(OptionId.CONTINUE_BUY_DRINKS, "HOW can you not afford this?!");
                }
                options.addOption("See if you can't loosen their lips a bit.", OptionId.CONTINUE_BRIBE);
                if (Global.getSector().getPlayerFleet().getCargo().getCredits().get() <= BRIBE_PRICE) {
                    options.setEnabled(OptionId.CONTINUE_BRIBE, false);
                    options.setTooltip(OptionId.CONTINUE_BRIBE, "You don't have enough credits.");
                }
                options.addOption("Leave the adventurer to their tall tales.", OptionId.LEAVE);
                break;
            case CONTINUE_BUY_DRINKS:
                Global.getSoundPlayer().playUISound(BUY_DRINKS_SOUND, 1f, 1f);
                boolean gotInfo = Math.random() < BUY_DRINKS_REVEAL_CHANCE;
                if (gotInfo) {
                    text.addPara("The alcohol and good spirits seems to have loosened the spacer's tongue, and you make discreet notes of a facility they describe and its general location.");
                } else {
                    text.addPara("While the alcohol seems to have made the spacer talkative, they don't reveal anything of particular interest.");
                }

                text.setFontSmallInsignia();
                text.addPara("Lost " + BUY_DRINKS_PRICE + " credits", n, h, "" + BUY_DRINKS_PRICE);
                Global.getSector().getPlayerFleet().getCargo().getCredits().add(-1 * BUY_DRINKS_PRICE);
                text.setFontInsignia();

                if (gotInfo) {
                    loa_MarketRevealHandler.revealRandomMarket(MathUtils.getRandomNumberInRange(3, 5), dialog.getTextPanel());
                }

                BarEventManager.getInstance().notifyWasInteractedWith(this);
                if (gotInfo) {
                    options.addOption("Well that was easy.", OptionId.LEAVE);
                } else {
                    options.addOption("Oh well, at least you had fun.", OptionId.LEAVE);
                }
                break;
            case CONTINUE_BRIBE:
                BarEventManager.getInstance().notifyWasInteractedWith(this);
                boolean causesBarFight = Math.random() > BRIBERY_SUCCESS_CHANCE;
                if (causesBarFight) {
                    Global.getSoundPlayer().playUISound(BAR_FIGHT_SOUND, 1f, 1f);
                    text.addPara("Your ears start ringing as the back of the spacer's hand rakes itself across your face. With your blurred vision you catch a glimpse of the man disappearing into the throng of a developing brawl. The next few minutes are a blur.");
                    text.addPara("After the worst of the commotion dies down, you are left with a thouroghly trashed bar and some non-negligable injuries the barkeep seems insistant on making you pay for.");

                    text.setFontSmallInsignia();
                    int cost = Math.min(BAR_BRAWL_MAX_COST, (int)(Global.getSector().getPlayerFleet().getCargo().getCredits().get()*BAR_BRAWL_PERCENTAGE_COST));
                    text.addPara("Lost " + cost + " credits", n, h, "" + cost);
                    Global.getSector().getPlayerFleet().getCargo().getCredits().add(-1 * cost);
                    text.setFontInsignia();

                    options.addOption("That could have gone smoother...", OptionId.LEAVE);
                } else {
                    text.addPara("After some credit-based 'convincing', the spacer seems willing to share the locations of some Society bases they've worked out of...");

                    text.setFontSmallInsignia();
                    text.addPara("Lost " + BRIBE_PRICE + " credits", n, h, "" + BRIBE_PRICE);
                    Global.getSector().getPlayerFleet().getCargo().getCredits().add(-1 * BRIBE_PRICE);
                    text.setFontInsignia();

                    loa_MarketRevealHandler.revealRandomMarket(6, dialog.getTextPanel());
                    loa_MarketRevealHandler.revealRandomMarket(MathUtils.getRandomNumberInRange(3, 5), dialog.getTextPanel());
                    if (Math.random() < BONUS_BRIBERY_REVEAL_CHANCE) {
                        loa_MarketRevealHandler.revealRandomMarket(MathUtils.getRandomNumberInRange(3, 5), dialog.getTextPanel());
                    }

                    options.addOption("'Pleasure doing business with you'", OptionId.LEAVE);
                }
                break;
            case LEAVE:
                noContinue = true;
                done = true;
                break;
        }
    }

    @Override
    public boolean shouldShowAtMarket(MarketAPI market) {
        if (!super.shouldShowAtMarket(market)) {return false;}

        return loa_MarketRevealHandler.canRevealAMarket(); //We don't want to have the event if the player knows of every single market
    }

    @Override
    public void init(InteractionDialogAPI dialog, Map<String, MemoryAPI> memoryMap) {
        super.init(dialog, memoryMap);
        done = false;
        dialog.getVisualPanel().showPersonInfo(person, true);
        optionSelected(null, OptionId.INIT);
    }
    @Override
    protected String getPersonPortrait() {
        return null;
    }
}
