package data.scripts.campaign;

import com.fs.starfarer.api.EveryFrameScript;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.*;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.campaign.listeners.FleetEventListener;
import com.fs.starfarer.api.fleet.FleetMemberAPI;
import com.fs.starfarer.api.impl.campaign.ids.Abilities;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.util.Misc;
import org.apache.log4j.Logger;
import org.lazywizard.lazylib.MathUtils;
import org.lwjgl.util.vector.Vector2f;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Handles most of the effects of Anargaia "dying"
 * @author Nicke535
 */
public class loa_AnargaiaDeathManager implements FleetEventListener, EveryFrameScript {
    //A debug logger to more easily track what the script is doing
    public static Logger log = Global.getLogger(loa_AnargaiaDeathManager.class);

    /*---------- CONFIGURATION START ----------*/

    //How long it takes until the system's collapse deals CR damage
    private static final float TIME_TO_DANGER = 20f;

    //CR loss as fraction of normal repairs while in the *puts on sunglasses* danger zone
    private static final float CR_LOSS_MULT = 0.5f;

    //How long it takes until the system's collapse deals "real" damage, and forces ships to transverse jump if possible
    private static final float TIME_TO_DAMAGE = 40f;

    //Approximate damage per second to fleets while in the "damage" state of the death event: scales up to higher values over the duration
    private static final float DAMAGE_PER_SECOND_APPROXIMATE = 3000f;

    //How long it takes for the system to completely and utterly be destroyed (in seconds)
    private static final float TOTAL_DEATH_TIME = 60f;

    //The sound to loop while the system is dying
    private static final String DEATH_LOOP_SOUND = "loa_warp_warning";

    //How much the death loop should be pitch-shifter over time (so at 0.5, the pitch will go from 100% to 50% over the death duration)
    private static final float DEATH_LOOP_PITCH_REDUCTION_OVER_TIME = 0f;

    //Death explosion particle config. Anything "Start/End" means at the start and end of the death sequence
    private static final float MINI_EXPLOSIONS_PER_SECOND_START = 0.5f;
    private static final float MINI_EXPLOSIONS_PER_SECOND_END = 5f;
    private static final float MINI_EXPLOSION_MAX_SIZE = 75f;
    private static final float MINI_EXPLOSION_MIN_SIZE = 20f;
    private static final float MINI_EXPLOSION_MAX_DURATION = 1.2f;
    private static final float MINI_EXPLOSION_MIN_DURATION = 0.5f;
    private static final Color MINI_EXPLOSION_COLOR_START = new Color(255, 185, 110);
    private static final Color MINI_EXPLOSION_COLOR_END = new Color(255, 185, 110);
    private static final float MINI_EXPLOSION_SOUND_CHANCE = 1f; //Chance for each mini-explosion to play a sound effect
    private static final String MINI_EXPLOSION_SOUND = "explosion_fleet_member"; //Sound effect for the mini-explosions

    //How far from our death we spawn the "final" death flash that I added without asking you
    //      This is basically a system-wide white-out that grows until we die, and starts this many seconds before the system is annihilated
    //      Set to anything below 0 to disable
    private static final float FINAL_DEATH_FLASH_DURATION = 1f;

    //An extra sound hook for playing a sound at the same time as the final death flash
    private static final String FINAL_DEATH_SOUND = "loa_warp_collapse";

    /*---------- CONFIGURATION END ----------*/

    //The system we are keeping track of
    private StarSystemAPI system;

    //The main entity to track; this corresponds to the station
    private SectorEntityToken stationEntity;

    //The current fleet entity that represents the station
    private CampaignFleetAPI addedListenerTo = null;

    //The market to track (should be Anargaia)
    private MarketAPI market;

    //The bombardment terrain we should remove once shit hits the fan
    private SectorEntityToken bombTerrain;

    //Whether we are finished running the script
    private boolean isDone = false;

    //Whether we are currently in the death sequence, and how far we have progressed in said death sequence
    private boolean isDying = false;
    private float deathProgress = 0f;
    private DEATH_STAGE previousDeathStage = DEATH_STAGE.NOT_STARTED;
    private boolean hasStartedFinalDeathFlash = false;

    //Memory keys to track what stage of death we are in
    public static final String DEATH_STAGE_MEMORY_KEY = "$loa_anargaia_death_memory_key";
    public enum DEATH_STAGE {
        NOT_STARTED,
        FIRST,
        DANGER,
        DAMAGE,
        FINAL
    }


    //Instantiator
    public loa_AnargaiaDeathManager(SectorEntityToken stationEntity, MarketAPI market, SectorEntityToken bombTerrain) {
        this.stationEntity = stationEntity;
        this.market = market;
        this.system = stationEntity.getStarSystem();
        this.bombTerrain = bombTerrain;
        Global.getSector().addScript(this);
    }


    //Main Advance function
    @Override
    public void advance(float amount) {
        SectorAPI sector = Global.getSector();
        //Failsafe, in case we somehow run when paused
        if (sector.isPaused()) {
            amount = 0f;
        }

        //Are we currently dying? In that case, track our death progress and apply appropriate effects
        if (isDying) {
            //No sound or particles if the player isn't around
            if (Global.getSector().getCurrentLocation() == system) {
                //Play a looping sound!
                Global.getSoundPlayer().playUILoop(DEATH_LOOP_SOUND, 1f-(DEATH_LOOP_PITCH_REDUCTION_OVER_TIME*(deathProgress/TOTAL_DEATH_TIME)), 1f);

                //And play fancy particle effects!
                float progress = deathProgress/TOTAL_DEATH_TIME;
                float spawnsThisFrame = Misc.interpolate(MINI_EXPLOSIONS_PER_SECOND_START, MINI_EXPLOSIONS_PER_SECOND_END, progress) * amount;
                while (Math.random() < spawnsThisFrame) {
                    spawnsThisFrame -= 1f;
                    Vector2f targetPoint = MathUtils.getRandomPointInCircle(stationEntity.getLocation(), stationEntity.getRadius());
                    system.addHitParticle(targetPoint, Misc.ZERO, MathUtils.getRandomNumberInRange(MINI_EXPLOSION_MIN_SIZE, MINI_EXPLOSION_MAX_SIZE),
                            1f, MathUtils.getRandomNumberInRange(MINI_EXPLOSION_MIN_DURATION, MINI_EXPLOSION_MAX_DURATION),
                            Misc.interpolateColor(MINI_EXPLOSION_COLOR_START, MINI_EXPLOSION_COLOR_END, progress));
                    if (Math.random() < MINI_EXPLOSION_SOUND_CHANCE) {
                        Global.getSoundPlayer().playUISound(MINI_EXPLOSION_SOUND, 1f, 1f);
                    }
                }

                //If we're in our very last moments, we spawn a massive death flash
                if (TOTAL_DEATH_TIME - deathProgress < FINAL_DEATH_FLASH_DURATION) {
                    if (!hasStartedFinalDeathFlash) {
                        Global.getSoundPlayer().playUISound(FINAL_DEATH_SOUND, 1f, 1f);
                    }
                    hasStartedFinalDeathFlash = true;
                    float finalFlashProgress = (FINAL_DEATH_FLASH_DURATION - (TOTAL_DEATH_TIME - deathProgress)) / FINAL_DEATH_FLASH_DURATION;
                    system.addHitParticle(stationEntity.getLocation(), Misc.ZERO, 5000f*finalFlashProgress,
                            1f, amount*3f, Color.white);
                }
            }


            deathProgress += amount;
            //Register which death stage we are currently in
            DEATH_STAGE currentDeathStage;
            if (deathProgress >= TOTAL_DEATH_TIME) {
                currentDeathStage = DEATH_STAGE.FINAL;
                sector.getMemoryWithoutUpdate().set(DEATH_STAGE_MEMORY_KEY, DEATH_STAGE.FINAL);
            } else if (deathProgress >= TIME_TO_DAMAGE) {
                currentDeathStage = DEATH_STAGE.DAMAGE;
                sector.getMemoryWithoutUpdate().set(DEATH_STAGE_MEMORY_KEY, DEATH_STAGE.DAMAGE);
            } else if (deathProgress >= TIME_TO_DANGER) {
                currentDeathStage = DEATH_STAGE.DANGER;
                sector.getMemoryWithoutUpdate().set(DEATH_STAGE_MEMORY_KEY, DEATH_STAGE.DANGER);
            } else {
                currentDeathStage = DEATH_STAGE.FIRST;
                sector.getMemoryWithoutUpdate().set(DEATH_STAGE_MEMORY_KEY, DEATH_STAGE.FIRST);
            }

            //Then, check if we passed a new stage limit, and if we should do anything about that
            if (currentDeathStage != previousDeathStage) {
                previousDeathStage = currentDeathStage;
                if (currentDeathStage == DEATH_STAGE.FINAL) {
                    log.info("Anargaia's death sequence has moved to the final stage!");

                    //Annihilate the system, and any poor fleets that remain...
                    List<CampaignFleetAPI> toRemove = new ArrayList<>(system.getFleets());
                    for (CampaignFleetAPI fleet : toRemove) {
                        if (!fleet.isPlayerFleet()) {
                            Misc.fadeAndExpire(fleet);
                        } else {
                            //Kill the player by annihilating all their fleet members, one by one...
                            List<FleetMemberAPI> toKill = new ArrayList<>(fleet.getFleetData().getMembersInPriorityOrder());
                            for (FleetMemberAPI member : toKill) {
                                fleet.removeFleetMemberWithDestructionFlash(member);
                            }
                            //As a security thingy, also move us outside the system, since that'll disappear pretty much now
                            fleet.getContainingLocation().removeEntity(fleet);
                            Global.getSector().getHyperspace().addEntity(fleet);
                            Global.getSector().setCurrentLocation(Global.getSector().getHyperspace());
                            fleet.getLocation().set(system.getLocation());
                        }
                    }
                    //Now, we kill the system completely. We also register that we're done with our job
                    sector.removeScript(this);
                    isDone = true;
                    List<SectorEntityToken> jumpPointsToRemove = new ArrayList<>(system.getJumpPoints());
                    for (SectorEntityToken point : Global.getSector().getHyperspace().getJumpPoints()) {
                        if (point instanceof JumpPointAPI) {
                            JumpPointAPI jump = ((JumpPointAPI)point);
                            for (JumpPointAPI.JumpDestination dest : jump.getDestinations()) {
                                if (dest.getDestination() != null &&
                                    system.equals(dest.getDestination().getStarSystem())) {
                                    jumpPointsToRemove.add(point);
                                    break;
                                }
                            }
                        }
                    }
                    for (SectorEntityToken point : jumpPointsToRemove) {
                        point.getContainingLocation().addHitParticle(point.getLocation(), Misc.ZERO, 200f,
                                1f, 2f, Color.white);
                        ((JumpPointAPI)point).clearDestinations();
                        Global.getSector().getHyperspace().removeEntity(point);
                    }
                    sector.removeStarSystem(system);
                } else if (currentDeathStage == DEATH_STAGE.DAMAGE) {
                    log.info("Anargaia's death sequence has moved to the third stage...");

                    //Order all fleets in the system to immediately jump away, if they can...
                    for (CampaignFleetAPI fleet : system.getFleets()) {
                        if (fleet != sector.getPlayerFleet()
                            && fleet.getAbilities().get(Abilities.TRANSVERSE_JUMP) != null) {
                            fleet.getAbilities().get(Abilities.TRANSVERSE_JUMP).activate();
                        }
                    }
                } else if (currentDeathStage == DEATH_STAGE.DANGER) {
                    log.info("Anargaia's death sequence has moved to the second stage...");
                } else if (currentDeathStage == DEATH_STAGE.FIRST) {
                    log.info("Anargaia's death sequence has moved to the first stage...");
                }
            }

            //Then, do the "passive" effects of our current stage
            if (currentDeathStage == DEATH_STAGE.DAMAGE) {
                for (CampaignFleetAPI fleet : system.getFleets()) {
                    if (fleet.getFleetData().getMembersInPriorityOrder().size() > 0) {
                        FleetMemberAPI targetMember = fleet.getFleetData().getMembersInPriorityOrder().get(MathUtils.getRandomNumberInRange(0, fleet.getFleetData().getMembersInPriorityOrder().size()-1));
                        targetMember.getStatus().applyDamage(amount * DAMAGE_PER_SECOND_APPROXIMATE * (deathProgress-TIME_TO_DAMAGE));
                    }
                }
            } else if (currentDeathStage == DEATH_STAGE.DANGER) {
                for (CampaignFleetAPI fleet : system.getFleets()) {
                    for (FleetMemberAPI member : fleet.getFleetData().getMembersListCopy()) {
                        //Gets how fast the ship normally regenerates CR and base CR loss on that
                        float recoveryRate = member.getStats().getBaseCRRecoveryRatePercentPerDay().getModifiedValue();
                        float lossRate = member.getStats().getBaseCRRecoveryRatePercentPerDay().getBaseValue();
                        float loss = (-1f * recoveryRate + -1f * lossRate * CR_LOSS_MULT) * Misc.getDays(amount) * 0.01f;
                        float curr = member.getRepairTracker().getBaseCR();
                        if (loss > curr) loss = curr;

                        member.getRepairTracker().applyCREvent(loss, "loa_anargaia_collapsing_warp_bubble", "Collapsing Warp Bubble");
                    }
                }
            }
        }
        //Otherwise, make sure the correct fleet has our listener
        else if (Misc.getStationFleet(market) != null) {
            CampaignFleetAPI stationFleet = Misc.getStationFleet(market);
            if (stationFleet != addedListenerTo) {
                if (addedListenerTo != null) {
                    addedListenerTo.removeEventListener(this);
                }
                addedListenerTo = stationFleet;
                addedListenerTo.addEventListener(this);
            }
        }
    }

    //Reports that the fleet has despawned; this means we should start the death sequence
    @Override
    public void reportFleetDespawnedToListener(CampaignFleetAPI fleet, CampaignEventListener.FleetDespawnReason reason, Object param) {
        //Only trigger if we aren't dying yet
        if (isDying) {return;}

        //Also, only trigger on our own station fleet
        if (addedListenerTo != null && fleet == addedListenerTo) {
            //Expires the station and its bombardment terrain
            market.setFactionId(Factions.NEUTRAL);
            stationEntity.getStarSystem().removeEntity(bombTerrain);
            Misc.fadeAndExpire(stationEntity, TOTAL_DEATH_TIME);
            addedListenerTo.setFaction(Factions.NEUTRAL);
            Misc.fadeAndExpire(addedListenerTo, TOTAL_DEATH_TIME);

            //Cleanup
            Global.getSector().getEconomy().removeMarket(market);
            Misc.removeRadioChatter(market);
            market.advance(0f);
            market = null;
            addedListenerTo = null;

            //Also indicate that our death sequence has begun...
            isDying = true;

            //Logs that we've been defeated
            log.info("Anargaia's death sequence has begun...");
        }
    }

    //We don't have to report a battle *occurring*, so we do nothing here
    @Override
    public void reportBattleOccurred(CampaignFleetAPI fleet, CampaignFleetAPI primaryWinner, BattleAPI battle) {
        //Do nothing!
    }

    //We are done when we are done (who'd have thought!)
    @Override
    public boolean isDone() {
        return isDone;
    }

    //We don't run when paused
    @Override
    public boolean runWhilePaused() {
        return false;
    }
}
