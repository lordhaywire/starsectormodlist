package data.scripts.campaign;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.*;
import com.fs.starfarer.api.combat.ViewportAPI;
import com.fs.starfarer.api.graphics.SpriteAPI;
import com.fs.starfarer.api.impl.campaign.terrain.AuroraRenderer;
import com.fs.starfarer.api.impl.campaign.terrain.AuroraRenderer.AuroraRendererDelegate;
import com.fs.starfarer.api.impl.campaign.terrain.BaseRingTerrain;
import com.fs.starfarer.api.impl.campaign.terrain.FlareManager;
import com.fs.starfarer.api.impl.campaign.terrain.FlareManager.FlareManagerDelegate;
import com.fs.starfarer.api.impl.campaign.terrain.RangeBlockerUtil;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;
import org.lwjgl.util.vector.Vector2f;

import java.awt.*;
import java.util.ArrayList;
import java.util.EnumSet;
import java.util.List;

/**
 * Handles the extra visual terrain for the Alcubierre Drive Boundary. Has no gameplay effects
 * Fair warning, this file is shock-full of settings I can't quite grasp. They're near the bottom, feel free to change to try and get a better visual look.
 */
public class loa_fake_alcubierre_ring_terrain extends BaseRingTerrain implements loa_AlcubierreRenderer.AlcubierreRendererDelegate, FlareManagerDelegate {

    public static class AlcubierreParams extends RingParams {
        public float windBurnLevel;
        public float flareProbability;
        public float crLossMult;

        public AlcubierreParams(float bandWidthInEngine, float middleRadius,
                                SectorEntityToken relatedEntity,
                                float windBurnLevel, float flareProbability, float crLossMult) {
            super(bandWidthInEngine, middleRadius, relatedEntity);
            this.windBurnLevel = windBurnLevel;
            this.flareProbability = flareProbability;
            this.crLossMult = crLossMult;
        }
    }

    transient protected SpriteAPI texture = null;
    transient protected Color color;

    protected loa_AlcubierreRenderer renderer;
    protected FlareManager flareManager;
    protected AlcubierreParams params;

    public void init(String terrainId, SectorEntityToken entity, Object param) {
        super.init(terrainId, entity, param);
        params = (AlcubierreParams) param;
        name = params.name;
        if (name == null) {
            name = "Alcubierre Drive Boundary";
        }
    }

    @Override
    protected Object readResolve() {
        super.readResolve();
        texture = Global.getSettings().getSprite("terrain", "aurora");
        layers = EnumSet.of(CampaignEngineLayers.TERRAIN_7);
        if (renderer == null) {
            renderer = new loa_AlcubierreRenderer(this);
        }
        if (flareManager == null) {
            flareManager = new FlareManager(this);
        }
        return this;
    }

    Object writeReplace() {
        return this;
    }

    @Override
    protected boolean shouldPlayLoopOne() {
        return false;
    }

    @Override
    protected boolean shouldPlayLoopTwo() {
        return false;
    }



    transient private EnumSet<CampaignEngineLayers> layers = EnumSet.of(CampaignEngineLayers.TERRAIN_7);
    public EnumSet<CampaignEngineLayers> getActiveLayers() {
        return layers;
    }

    public AlcubierreParams getParams() {
        return params;
    }

    public void advance(float amount) {
        super.advance(amount);
        renderer.advance(amount);
        flareManager.advance(amount);

        //New addition: if Anargaia dies, we collapse in size and have different names and descriptions
        if (Global.getSector().getMemoryWithoutUpdate().get(loa_AnargaiaDeathManager.DEATH_STAGE_MEMORY_KEY) instanceof loa_AnargaiaDeathManager.DEATH_STAGE) {
            loa_AnargaiaDeathManager.DEATH_STAGE deathStage = (loa_AnargaiaDeathManager.DEATH_STAGE)Global.getSector().getMemoryWithoutUpdate().get(loa_AnargaiaDeathManager.DEATH_STAGE_MEMORY_KEY);
            if (deathStage == loa_AnargaiaDeathManager.DEATH_STAGE.FIRST) {
                float outerRadius = params.middleRadius+(params.bandWidthInEngine/2f);
                float plannedInnerRadius = (params.middleRadius-(params.bandWidthInEngine/2f)) * (float)Math.pow(0.55f,amount); // Shrinks 45% per second, should be fast but not instant
                this.params.middleRadius = (outerRadius+plannedInnerRadius)/2f;
                this.params.bandWidthInEngine = outerRadius-plannedInnerRadius;
            }
        }
    }

    public void render(CampaignEngineLayers layer, ViewportAPI viewport) {
        renderer.render(viewport.getAlphaMult());
    }

    @Override
    public float getRenderRange() {
        FlareManager.Flare curr = flareManager.getActiveFlare();
        if (curr != null) {
            float outerRadiusWithFlare = computeRadiusWithFlare(flareManager.getActiveFlare());
            return outerRadiusWithFlare + 200f;
        }
        return super.getRenderRange();
    }

    @Override
    public boolean containsPoint(Vector2f point, float radius) {
        if (flareManager.isInActiveFlareArc(point)) {
            float outerRadiusWithFlare = computeRadiusWithFlare(flareManager.getActiveFlare());
            float dist = Misc.getDistance(this.entity.getLocation(), point);
            if (dist > outerRadiusWithFlare + radius) return false;
            if (dist + radius < params.middleRadius - params.bandWidthInEngine / 2f) return false;
            return true;
        }
        return super.containsPoint(point, radius);
    }

    protected float computeRadiusWithFlare(FlareManager.Flare flare) {
        float inner = params.middleRadius - params.bandWidthInEngine * 0.5f;
        float thickness = params.bandWidthInEngine;

        thickness *= flare.extraLengthMult;
        thickness += flare.extraLengthFlat;

        return inner + thickness;
    }

    @Override
    protected float getExtraSoundRadius() {
        float base = super.getExtraSoundRadius();

        float angle = Misc.getAngleInDegrees(params.relatedEntity.getLocation(), Global.getSector().getPlayerFleet().getLocation());
        float extra = 0f;
        if (flareManager.isInActiveFlareArc(angle)) {
            extra = computeRadiusWithFlare(flareManager.getActiveFlare()) - params.bandWidthInEngine;
        }
        //System.out.println("Extra: " + extra);
        return base + extra;
    }


    @Override
    public void applyEffect(SectorEntityToken entity, float days) {
        //Do nothing
    }



    @Override
    public Color getNameColor() {
        Color bad = Misc.getNegativeHighlightColor();
        Color base = super.getNameColor();
        //bad = Color.red;
        return Misc.interpolateColor(base, bad, Global.getSector().getCampaignUI().getSharedFader().getBrightness() * 1f);
    }

    public boolean hasTooltip() {
        return false;
    }

    public void createTooltip(TooltipMakerAPI tooltip, boolean expanded) {
        //Do nothing
    }

    public boolean isTooltipExpandable() {
        return false;
    }

    public float getTooltipWidth() {
        return 350f;
    }

    public String getTerrainName() {
        return "";
    }

    public String getEffectCategory() {
        return null; // to ensure multiple coronas overlapping all take effect
        //return "corona_" + (float) Math.random();
    }

    public float getAuroraAlphaMultForAngle(float angle) {
        return 1f;
    }

    public float getAuroraBandWidthInTexture() {
        return 256f;
        //return 512f;
    }

    public float getAuroraTexPerSegmentMult() {
        return 1f;
        //return 2f;
    }

    public Vector2f getAuroraCenterLoc() {
        return params.relatedEntity.getLocation();
    }

    public Color getAuroraColorForAngle(float angle) {
        if (color == null) {
            if (params.relatedEntity instanceof PlanetAPI) {
                color = ((PlanetAPI)params.relatedEntity).getSpec().getCoronaColor();
                //color = Misc.interpolateColor(color, Color.white, 0.5f);
            } else {
                color = new Color(255, 255, 255);
            }
            color = Misc.setAlpha(color, 255);
        }
        if (flareManager.isInActiveFlareArc(angle)) {
            return flareManager.getColorForAngle(color, angle);
        }
        return color;
    }

    public float getAuroraInnerRadius() {
        return params.middleRadius - params.bandWidthInEngine * 0.5f;
    }

    public float getAuroraOuterRadius() {
        return params.middleRadius + params.bandWidthInEngine * 0.5f;
    }

    public float getAuroraShortenMult(float angle) {
        return 0.85f + flareManager.getShortenMod(angle);
    }

    public float getAuroraInnerOffsetMult(float angle) {
        return flareManager.getInnerOffsetMult(angle);
    }

    public SpriteAPI getAuroraTexture() {
        return texture;
    }

    public RangeBlockerUtil getAuroraBlocker() {
        return null;
    }

    public float getAuroraThicknessFlat(float angle) {
        if (flareManager.isInActiveFlareArc(angle)) {
            return flareManager.getExtraLengthFlat(angle);
        }
        return 300f;
    }

    public float getAuroraThicknessMult(float angle) {
        if (flareManager.isInActiveFlareArc(angle)) {
            return flareManager.getExtraLengthMult(angle);
        }
        return 1f;
    }





    public List<Color> getFlareColorRange() {
        List<Color> result = new ArrayList<Color>();

        result.add(new Color(255, 255, 255));
        result.add(new Color(255, 255, 255));

        return result;
    }

    public float getFlareArcMax() {
        return 60;
    }

    public float getFlareArcMin() {
        return 30;
    }

    public float getFlareExtraLengthFlatMax() {
        return 500;
    }

    public float getFlareExtraLengthFlatMin() {
        return 200;
    }

    public float getFlareExtraLengthMultMax() {
        return 1.5f;
    }

    public float getFlareExtraLengthMultMin() {
        return 1;
    }

    public float getFlareFadeInMax() {
        return 10f;
    }

    public float getFlareFadeInMin() {
        return 3f;
    }

    public float getFlareFadeOutMax() {
        return 10f;
    }

    public float getFlareFadeOutMin() {
        return 3f;
    }

    public float getFlareOccurrenceAngle() {
        return 0;
    }

    public float getFlareOccurrenceArc() {
        return 360f;
    }

    public float getFlareProbability() {
        return params.flareProbability;
    }

    public float getFlareSmallArcMax() {
        return 90;
    }

    public float getFlareSmallArcMin() {
        return 30;
    }

    public float getFlareSmallExtraLengthFlatMax() {
        return this.params.bandWidthInEngine*1f;
    }

    public float getFlareSmallExtraLengthFlatMin() {
        return this.params.bandWidthInEngine*0.5f;
    }

    public float getFlareSmallExtraLengthMultMax() {
        return 1.1f;
    }

    public float getFlareSmallExtraLengthMultMin() {
        return 1;
    }

    public float getFlareSmallFadeInMax() {
        return 4f;
    }

    public float getFlareSmallFadeInMin() {
        return 0.5f;
    }

    public float getFlareSmallFadeOutMax() {
        return 3f;
    }

    public float getFlareSmallFadeOutMin() {
        return 0.5f;
    }

    public float getFlareShortenFlatModMax() {
        return 0.05f;
    }

    public float getFlareShortenFlatModMin() {
        return 0.05f;
    }

    public float getFlareSmallShortenFlatModMax() {
        return 0.05f;
    }

    public float getFlareSmallShortenFlatModMin() {
        return 0.05f;
    }

    public int getFlareMaxSmallCount() {
        return 20;
    }

    public int getFlareMinSmallCount() {
        return 30;
    }

    public float getFlareSkipLargeProbability() {
        return 0f;
    }

    public SectorEntityToken getFlareCenterEntity() {
        return this.entity;
    }

	//These are for AI avoidance: set them to effectively nonexistant
    public boolean hasAIFlag(Object flag) {
        return false;
    }

    public float getMaxEffectRadius(Vector2f locFrom) {
        return 0f;
    }
    public float getMinEffectRadius(Vector2f locFrom) {
        return 0f;
    }

    public float getOptimalEffectRadius(Vector2f locFrom) {
        return 0f;
    }

    public boolean canPlayerHoldStationIn() {
        return false;
    }
}
