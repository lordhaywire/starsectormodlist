package data.scripts.campaign;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.FactionAPI;
import com.fs.starfarer.api.campaign.RepLevel;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.impl.campaign.intel.BaseIntelPlugin;
import com.fs.starfarer.api.ui.SectorMapAPI;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;

import java.awt.*;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

/**
 * A small intel script for pointing out a market on the map. Specifically designed for Anargaia
 * @author Nicke535
 */
public class loa_anargaia_reveal_intel extends BaseIntelPlugin {
    //In-script variables
    private MarketAPI target;
    private String intendedFaction;

    public loa_anargaia_reveal_intel(MarketAPI target, String intendedFaction) {
        this.target = target;
        this.intendedFaction = intendedFaction;
    }

    @Override
    public void advance(float amount) {
        if (!intendedFaction.equals(target.getFactionId())) {
            endImmediately();
        }
    }

    //Handles the bullet-points on the intel screen
    @Override
    public void createIntelInfo(TooltipMakerAPI info, ListInfoMode mode) {
        Color c = getTitleColor(mode);
        float opad = 10f;
        info.setParaSmallInsignia();
        info.addPara(getName(), c, 0f);
        info.setParaFontDefault();

        bullet(info);
        info.addPara( target.getFaction().getDisplayNameWithArticle()+ " is now sending you periodic coordinate updates, apparently tracking a base called 'Anargaia'", opad);
        unindent(info);
    }

    // The description shown on the intel screen summary
    @Override
    public void createSmallDescription(TooltipMakerAPI info, float width, float height) {
        Color h = Misc.getHighlightColor();
        Color g = Misc.getGrayColor();
        Color tc = Misc.getTextColor();
        float pad = 3f;
        float opad = 10f;

        info.addPara("The coordinates of a peculiar moving base is being supplied by " + target.getFaction().getDisplayNameLongWithArticle(), pad);
    }

    //Gets the icon to display in the intel screen
    @Override
    public String getIcon() {
        return Global.getSettings().getSpriteName("loa_intel", "loa_raid");
    }


    @Override
    protected void notifyEnded() {
        super.notifyEnded();
        Global.getSector().removeScript(this);
    }

    @Override
    public void endAfterDelay() {
        super.endAfterDelay();
    }

    @Override
    protected void notifyEnding() {
        super.notifyEnding();
    }

    //Tags in the intel screen
    @Override
    public Set<String> getIntelTags(SectorMapAPI map) {
        Set<String> tags = super.getIntelTags(map);
        tags.add(target.getFactionId());
        return tags;
    }

    @Override
    public IntelSortTier getSortTier() {
        return IntelSortTier.TIER_5;
    }

    public String getSortString() {
        return target.getFaction().getDisplayName();
    }

    // What the intel is called
    public String getName() {
        return "Anargaia Coordinates";
    }

    @Override
    public FactionAPI getFactionForUIColors() {
        return target.getFaction();
    }

    public String getSmallDescriptionTitle() {
        return getName();
    }

    @Override
    public boolean shouldRemoveIntel() {
        return super.shouldRemoveIntel();
    }

    //The noise to play when a new message shows up
    @Override
    public String getCommMessageSound() {
        return getSoundMajorPosting();
    }

    @Override
    public SectorEntityToken getMapLocation(SectorMapAPI map) {
        return target.getPrimaryEntity();
    }
}
