//By Nicke535
//Contains a whole bunch of loose functions for getting everything necessary to create the Champion and its terrain
//
//While many functions have variables as input, some more "advanced" options are directly in this file
package data.scripts.campaign;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.*;
import com.fs.starfarer.api.impl.campaign.DerelictShipEntityPlugin;
import com.fs.starfarer.api.impl.campaign.ids.Entities;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.ids.Terrain;
import com.fs.starfarer.api.impl.campaign.procgen.DefenderDataOverride;
import com.fs.starfarer.api.impl.campaign.procgen.themes.BaseThemeGenerator;
import com.fs.starfarer.api.impl.campaign.procgen.themes.SalvageSpecialAssigner;
import com.fs.starfarer.api.impl.campaign.rulecmd.salvage.special.ShipRecoverySpecial;
import com.fs.starfarer.api.util.Misc;
import org.jetbrains.annotations.Nullable;
import org.lazywizard.lazylib.MathUtils;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class loa_generatechampionscript {
    // --------------These are some constant settings for the entire file, which were deemed unnecessary to put in the functions themselves--------------
    //How many of our randomly-spawned derelicts (for the champion's belt) use Gaussian distribution (more appear closer to the Champion)?
    //0.3f represents 30% of the derelicts. Set to 0f to make derelicts spawn entirely uniformly
    private static final float GAUSSIAN_DERELICT_PERCENTAGE = 0.3f;

    //A list of all the Derelict Variants we're allowed to spawn as debris. Modded ships are allowed even if that mod isn't
    //loaded (though we will of course not spawn their ships as derelicts, then)
    private static final List<String> ALLOWED_DERELICT_WRECKS = new ArrayList<>();
    static {
        ALLOWED_DERELICT_WRECKS.add("picket_Assault");
        ALLOWED_DERELICT_WRECKS.add("sentry_FS");
        ALLOWED_DERELICT_WRECKS.add("defender_PD");
        ALLOWED_DERELICT_WRECKS.add("warden_Defense");
        ALLOWED_DERELICT_WRECKS.add("bastillon_Standard");
    }


    /**
     *  Utility function for getting a random system from a list of systems. Will always return a valid system *unless*
     *  every single system in the input list is invalid
     *
     *  @param inputList A list of all the systems to randomize from
     *  @param sector The SectorAPI to check for systems in
     **/
    public static StarSystemAPI GetRandomSystemFromList (List<String> inputList, SectorAPI sector) {
        //First, get all the valid systems and put them in a separate list
        List<StarSystemAPI> validSystems = new ArrayList<>();
        for (String id : inputList) {
            if (sector.getStarSystem(id) != null) {
                validSystems.add(sector.getStarSystem(id));
            }
        }

        //If that list is empty, return null
        if (validSystems.isEmpty()) {
            return null;
        }

        //Otherwise, get a random element in it and return that
        else {
            int rand = MathUtils.getRandomNumberInRange(0, validSystems.size()-1);
            return validSystems.get(rand);
        }
    }


    /**
     *  Utility function for getting a valid ring orbit between a system's outermost planet and outermost jump point,
     *  with a grace distance to not get too close to the planet. If no planets exist, get a distance outside the
     *  system's outermost jump point, as determined by the grace distance
     *
     *  Will not collide with the outermost planet, but some odd configurations of planets and/or multi-star systems
     *  may cause issues. Use on single-star systems with Fringe jump points for the best results
     *
     *  Returns negative numbers in case of an error occurring (no jump points, for example)
     *
     *  @param system The system to get the ring coordinates in
     *  @param graceDistance The "grace distance" from the outermost planet; we will not get an orbit closer than this
     *                       to that planet (too high values may force us far out of the system, so be careful)
     **/
    public static float GetChampionOrbitRing (StarSystemAPI system, float graceDistance) {
        //First, get all the system's planets and jump points, so we know if either are empty
        List<PlanetAPI> systemPlanets = new ArrayList<>();
        List<JumpPointAPI> jumpPoints = new ArrayList<>();
        for (SectorEntityToken token : system.getAllEntities()) {
            //The center token is ignored (this is most often a star, but either way we can't use it due to math)
            if (token == system.getCenter()) {
                continue;
            }

            //Also, ignore stuff not circling the system center, since their orbits may intersect us
            if (token.getOrbit() == null || token.getOrbit().getFocus() != system.getCenter()) {
                continue;
            }

            //Get the planets
            if (token instanceof PlanetAPI) {
                systemPlanets.add((PlanetAPI) token);
            }

            //...and the jump points
            else if (token instanceof JumpPointAPI) {
                jumpPoints.add((JumpPointAPI)token);
            }
        }

        //Is our jump poin list empty? That shouldn't ever happen, but in case it does return -1f
        if (jumpPoints.isEmpty()) {
            return -1f;
        }

        //Since our jump points weren't empty, we get the outermost jump point for later use
        float outermostJumppointRadius = 0f;
        for (JumpPointAPI point : jumpPoints) {
            float distance = point.getCircularOrbitRadius();
            if (distance > outermostJumppointRadius) {
                outermostJumppointRadius = distance;
            }
        }

        //Is our planet list empty? In that case, we use a simplified algorithm; simply get a distance outside the outermost jump point
        if (systemPlanets.isEmpty()) {
            return (outermostJumppointRadius + graceDistance);
        }

        //If our planet list *isn't* empty, we try and find which planet is furthest out in the system
        else {
            PlanetAPI furthestPlanet = null;
            for (PlanetAPI planet : systemPlanets) {
                if (furthestPlanet == null) {
                    furthestPlanet = planet;
                } else if (planet.getCircularOrbitRadius()+planet.getRadius() > furthestPlanet.getCircularOrbitRadius()+furthestPlanet.getRadius()) {
                    furthestPlanet = planet;
                }
            }

            //Now that we've found the furthest-away planet, we calculate the average orbit between it and the furthermost jump point, and
            //adjusts for our grace distance
            float orbitDistance = (outermostJumppointRadius + furthestPlanet.getCircularOrbitRadius()) / 2f;
            if (orbitDistance < outermostJumppointRadius && orbitDistance < (furthestPlanet.getCircularOrbitRadius() + furthestPlanet.getRadius() + graceDistance)) {
                orbitDistance = (furthestPlanet.getCircularOrbitRadius() + furthestPlanet.getRadius() + graceDistance);
            } else if (orbitDistance > (furthestPlanet.getCircularOrbitRadius() - furthestPlanet.getRadius() - graceDistance)) {
                orbitDistance = (furthestPlanet.getCircularOrbitRadius() - furthestPlanet.getRadius() - graceDistance);
            }

            //Finally, return the orbit
            return orbitDistance;
        }
    }


    /**
     *  Spawns the Champion, a ring terrain and a bunch of derelicts, all in generally the same orbit.
     *  @param system The system to spawn the stuff in
     *  @param customName A custom name for the ring terrain
     *  @param orbitRadius The average orbit radius of the belt and everything in it
     *  @param orbitVariance How far away from the average orbit each derelict is allowed to spawn. Should be less
     *                       than 128f as that's the ring's width
     *  @param amountOfDerelicts The number of derelicts to spawn in the ring (not counting the Champion itself)
     *  @param championDefenderStrengthMin The lowest amount of fleet points the fleet defending the Champion can have
     *  @param championDefenderStrengthMax The highest amount of fleet points the fleet defending the Champion can have
     **/
    public static void SpawnChampionRing (StarSystemAPI system, String customName, float orbitRadius, float orbitVariance,
                                          int amountOfDerelicts, float championDefenderStrengthMin, float championDefenderStrengthMax) {
        //First, calculate our orbit time. This is set so we have a decently slow orbit regardless of radius
        float orbitTime = orbitRadius / 20f;

        //Then, spawn a ring with a custom name
        system.addRingBand(system.getCenter(), "misc", "rings_dust0", 256f, 1, Color.gray,
                128f, orbitRadius, orbitTime, Terrain.RING, customName);


        //After that, we decide an angle for our Champion to spawn; this is important, as the Derelicts in the ring spawn more commonly near the Champion, since we
        //use Gaussian distribution for some derelicts
        float championAngle = MathUtils.getRandomNumberInRange(0f, 360f);

        //Then, we spawn the champion itself, with defenders
        DefenderDataOverride defenders = new DefenderDataOverride(Factions.DERELICT, 1f,championDefenderStrengthMin,championDefenderStrengthMax);
        addDerelict(system, system.getCenter(), "loaht_champion1_d_wreck", ShipRecoverySpecial.ShipCondition.BATTERED, orbitRadius, orbitTime,
                championAngle, true, defenders);

        //And lastly, we add all the non-salvageable derelicts
        for (int i = 0; i <amountOfDerelicts; i++) {
            //First, get an angle
            float angle = championAngle;

            //We have a chance to use gaussian distribution
            if (Math.random() < GAUSSIAN_DERELICT_PERCENTAGE) {
                Random rand = new Random();
                angle += 60f * rand.nextGaussian();
            } else {
                angle += MathUtils.getRandomNumberInRange(-180f, 180f);
            }

            //Then, we get our orbit radius for this specific derelict
            float localRadius = MathUtils.getRandomNumberInRange(orbitRadius-orbitVariance, orbitRadius+orbitVariance);

            //Lastly, spawn the derelict
            addDerelict(system, system.getCenter(), getDerelictVariant(), ShipRecoverySpecial.ShipCondition.WRECKED,
                    localRadius, orbitTime, angle, false, null);
        }
    }


    //Mini-function for generating the derelicts in the system, and for generating the Champion
    private static SectorEntityToken addDerelict(StarSystemAPI system, SectorEntityToken focus, String variantId,
                                                ShipRecoverySpecial.ShipCondition condition, float orbitRadius, float daysToOrbit,
                                                float startOrbitAngle, boolean recoverable, @Nullable DefenderDataOverride defenders) {

        DerelictShipEntityPlugin.DerelictShipData params = new DerelictShipEntityPlugin.DerelictShipData(new ShipRecoverySpecial.PerShipData(variantId, condition), false);
        SectorEntityToken ship = BaseThemeGenerator.addSalvageEntity(system, Entities.WRECK, Factions.NEUTRAL, params);
        ship.setDiscoverable(true);

        ship.setCircularOrbit(focus, startOrbitAngle, orbitRadius, daysToOrbit);

        if (recoverable) {
            SalvageSpecialAssigner.ShipRecoverySpecialCreator creator = new SalvageSpecialAssigner.ShipRecoverySpecialCreator(null, 0, 0, false, null, null);
            Misc.setSalvageSpecial(ship, creator.createSpecial(ship, null));
        }
        if (defenders != null) {
            Misc.setDefenderOverride(ship, defenders);
        }
        return ship;
    }


    //Mini-function for getting a random ship classified as a Derelict in our list at the top of the script.
    // Returns "picket_Assault" if none of the designated variants exist (and returns Null if, somehow, the Picket doesn't exist)
    private static String getDerelictVariant () {
        //Get all variants that can be spawned, and put them in a list
        List<String> validStrings = new ArrayList<>();
        for (String s : ALLOWED_DERELICT_WRECKS) {
            if (Global.getSettings().getVariant(s) != null) {
                validStrings.add(s);
            }
        }

        //If we had *any* valid variants, select one of those at random
        if (!validStrings.isEmpty()) {
            int rand = MathUtils.getRandomNumberInRange(0, validStrings.size()-1);
            return validStrings.get(rand);
        }

        //Backup plan: none of the derelicts we specified exists, so we use the Picket instead
        else {
            if (Global.getSettings().getVariant("picket_Assault") != null) {
                return "picket_Assault";
            }

            //Backup BACKUP plan; return Null if the picket doesn't exist (trying to run this with a total conversion, eh?)
            else {
                return null;
            }
        }
    }
}
