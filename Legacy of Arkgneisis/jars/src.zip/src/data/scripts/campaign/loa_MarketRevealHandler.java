package data.scripts.campaign;

import com.fs.starfarer.api.EveryFrameScript;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.*;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.campaign.listeners.DiscoverEntityListener;
import com.fs.starfarer.api.campaign.listeners.DiscoverEntityPlugin;
import com.fs.starfarer.api.campaign.listeners.FleetEventListener;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.ids.Submarkets;
import com.fs.starfarer.api.util.IntervalUtil;
import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.api.util.WeightedRandomPicker;
import org.apache.log4j.Logger;
import org.jetbrains.annotations.Nullable;

import java.util.*;

/**
 * A script managing all the revealing behaviour of all Anarakis markets
 * @author Nicke535
 */
public class loa_MarketRevealHandler implements EveryFrameScript, DiscoverEntityListener {
    //A debug logger to more easily track what the script is doing
    public static Logger log = Global.getLogger(loa_MarketRevealHandler.class);

    //The reputation needed to get all random markets to be revealed to the player, regardless of where they are
    //      Sorted by market size: anything below or above the listed sizes will use the lowest/highest listed size respectively
    //      Also note that having a commission counts as the highest possible rep level for the purposes of this and the other required reps
    private static final Map<Integer, RepLevel> REQUIRED_REP_FOR_REVEAL_PER_MARKET_SIZE = new HashMap<>();
    static {
        REQUIRED_REP_FOR_REVEAL_PER_MARKET_SIZE.put(3, RepLevel.FAVORABLE);
        REQUIRED_REP_FOR_REVEAL_PER_MARKET_SIZE.put(4, RepLevel.WELCOMING);
        REQUIRED_REP_FOR_REVEAL_PER_MARKET_SIZE.put(5, RepLevel.FRIENDLY);
        REQUIRED_REP_FOR_REVEAL_PER_MARKET_SIZE.put(6, RepLevel.COOPERATIVE);
    }

    //Same as above, but only applies to Anargaia.
    //      Note that unlike the other markets, Anargaia becomes invisible again once you stop having enough rep
    private static final RepLevel REQUIRED_REP_FOR_ANARGAIA = RepLevel.COOPERATIVE;

    //Faction ID for the faction we reveal for
    private static final String FACTION_ID = "al_ars";


    /* - In-script variables - */
    //Keeps track of all markets that have already been revealed [except Anargaia]
    private Set<MarketAPI> revealedMarkets = new HashSet<>();

    //Holds the intel handling anargaia's tracking, if it currently exists
    private loa_anargaia_reveal_intel anargaiaIntel = null;

    //The name of Anargaia's market: make sure it is the actual ID of anargaia's market [at the time of writing, the value I've added is correct]
    private static final String ANARGAIA_ID = "loa_anargaia_station_market";

    //ID for storing the this script in an easy-to-reach location in the sector's memory
    private static final String MEMORY_KEY = "$"+loa_MarketRevealHandler.class.getName()+"_storage_key";

    private IntervalUtil timer = new IntervalUtil(1f, 2f);
    private boolean hasUnrevealedMarket = true;

    //Instantiator
    public loa_MarketRevealHandler() {
        Global.getSector().getListenerManager().addListener(this);
    }

    //New way of revealing their bases: via discovery listener
    @Override
    public void reportEntityDiscovered(SectorEntityToken entity) {
        if (entity.getMarket() != null
            && FACTION_ID.equals(entity.getMarket().getFactionId())
            && !entity.getMarket().getId().equals(ANARGAIA_ID)
            && !revealedMarkets.contains(entity.getMarket())) {
            revealedMarkets.add(entity.getMarket());
            Global.getSector().getIntelManager().addIntel(new loa_random_market_reveal_intel(entity.getMarket(), FACTION_ID));
        }
    }

    //Main Advance function
    @Override
    public void advance(float amount) {
        //Failsafe, in case we somehow run when paused
        if (Global.getSector().isPaused()) {
            amount = 0f;
        }

        //Store our instance in the global memory for static access
        Global.getSector().getMemoryWithoutUpdate().set(MEMORY_KEY, this);

        //Runs once every couple of seconds
        timer.advance(amount);
        if (timer.intervalElapsed()) {
            //Get all markets, and check if they should be revealed
            FactionAPI faction = Global.getSector().getFaction(FACTION_ID);
            hasUnrevealedMarket = false;
            for (MarketAPI market : Misc.getFactionMarkets(faction)) {
                if (revealedMarkets.contains(market)) {
                    continue;
                }
                if (market.getId().equals(ANARGAIA_ID)) {
                    //Anargaia is ONLY revealed if the player has enough reputation for it, or have a commission
                    //It is also "forgotten" due to moving around, so revealing it once isn't enough
                    if (FACTION_ID.equals(Misc.getCommissionFactionId()) || faction.isAtWorst(Factions.PLAYER, REQUIRED_REP_FOR_ANARGAIA)) {
                        if (anargaiaIntel == null) {
                            anargaiaIntel = new loa_anargaia_reveal_intel(market, FACTION_ID);
                            Global.getSector().getIntelManager().addIntel(anargaiaIntel);
                        }
                    } else {
                        if (anargaiaIntel != null) {
                            anargaiaIntel.endImmediately();
                            anargaiaIntel = null;
                        }
                    }
                } else {
                    hasUnrevealedMarket = true;
                    if (FACTION_ID.equals(Misc.getCommissionFactionId())
                        || faction.isAtWorst(Factions.PLAYER, getRequiredRelationsForReveal(market.getSize()))) {
                        revealedMarkets.add(market);
                        Global.getSector().getIntelManager().addIntel(new loa_random_market_reveal_intel(market, FACTION_ID));
                    }
                }
            }

            //After that, we also run quick cleanup of our stored markets, to remove markets that are no longer ours
            Set<MarketAPI> toRemove = new HashSet<>();
            for (MarketAPI market : revealedMarkets) {
                if (!FACTION_ID.equals(market.getFactionId())) {
                    toRemove.add(market);
                }
            }
            revealedMarkets.removeAll(toRemove);
        }
    }

    @Override
    public boolean isDone() {
        return false;
    }

    @Override
    public boolean runWhilePaused() {
        return false;
    }

    //Reveals a random market, of a specific size (or the closest available size if for some reason no market in that size can be revealed)
    //      Also returns the market that was revealed, or null if none was revealed for some reason
    public static MarketAPI revealRandomMarket(int marketSize, @Nullable TextPanelAPI dialogueTextToPrintIn) {
        Object obj = Global.getSector().getMemoryWithoutUpdate().get(MEMORY_KEY);
        if (obj instanceof loa_MarketRevealHandler) {
            loa_MarketRevealHandler handler = (loa_MarketRevealHandler) obj;
            FactionAPI faction = Global.getSector().getFaction(FACTION_ID);
            WeightedRandomPicker<MarketAPI> picker = new WeightedRandomPicker<>();
            int closestMarketSize = -2;
            for (MarketAPI market : Misc.getFactionMarkets(faction)) {
                if (handler.revealedMarkets.contains(market) || market.getId().equals(ANARGAIA_ID)) {
                    continue;
                }
                if (Math.abs(market.getSize()-marketSize) < Math.abs(closestMarketSize-marketSize)) {
                    closestMarketSize = market.getSize();
                }
            }
            for (MarketAPI market : Misc.getFactionMarkets(faction)) {
                if (handler.revealedMarkets.contains(market) || market.getId().equals(ANARGAIA_ID)) {
                    continue;
                }
                if (market.getSize() == closestMarketSize) {
                    picker.add(market);
                }
            }
            if (picker.isEmpty()) {
                return null;
            } else {
                MarketAPI marketToReveal = picker.pick();
                handler.revealedMarkets.add(marketToReveal);
                loa_random_market_reveal_intel intel = new loa_random_market_reveal_intel(marketToReveal, FACTION_ID);
                if (dialogueTextToPrintIn != null) {
                    Global.getSector().getIntelManager().addIntel(intel, false, dialogueTextToPrintIn);
                } else {
                    Global.getSector().getIntelManager().addIntel(intel);
                }
                return marketToReveal;
            }
        } else {
            //Safety check if we haven't been initialized yet
            return null;
        }
    }

    //Checks if there are any markets available to reveal: mostly used to determine whether our random event spawns or not
    public static boolean canRevealAMarket() {
        Object obj = Global.getSector().getMemoryWithoutUpdate().get(MEMORY_KEY);
        if (obj instanceof loa_MarketRevealHandler) {
            return ((loa_MarketRevealHandler) obj).hasUnrevealedMarket;
        } else {
            //Safety check if we haven't been initialized yet
            return false;
        }
    }

    //Checks the reputation level needed to reveal a market
    private static RepLevel getRequiredRelationsForReveal(int marketSize) {
        if (REQUIRED_REP_FOR_REVEAL_PER_MARKET_SIZE.get(marketSize) != null) {
            return REQUIRED_REP_FOR_REVEAL_PER_MARKET_SIZE.get(marketSize);
        } else {
            int highestSize = 0;
            int lowestSize = 10;
            for (Integer key : REQUIRED_REP_FOR_REVEAL_PER_MARKET_SIZE.keySet()) {
                if (highestSize < key) {
                    highestSize = key;
                }
                if (lowestSize > key) {
                    lowestSize = key;
                }
            }
            return REQUIRED_REP_FOR_REVEAL_PER_MARKET_SIZE.get(Math.min(highestSize, Math.max(lowestSize, marketSize)));
        }
    }
}
