package data.scripts.campaign;

import java.awt.Color;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.*;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.combat.ViewportAPI;
import com.fs.starfarer.api.fleet.FleetMemberAPI;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.terrain.*;
import com.fs.starfarer.api.ui.Alignment;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;
import org.lazywizard.lazylib.MathUtils;
import org.lazywizard.lazylib.VectorUtils;
import org.lwjgl.util.vector.Vector2f;

/**
 * Generates a ring terrain that continually drains CR from nearby enemy fleets and logs them for eventual hook-up to another
 * in-combat script. If a fleet gets too close, it also takes intermittent damage
 * @author Nicke535
 *         adapted from the Asteroid Ring Terrain plugin from the base game
 */
public class loa_anargaia_bombardment_terrain extends BaseRingTerrain {

	//How fast ships lose CR, relative to how fast the ship normally regenerates CR. At 0.5f, flying in this area for
	//4 days will take 2 days worth of repair. Specified both at near and far range
	public static final float CR_LOSS_MULT_FAR = 0.15f;
	public static final float CR_LOSS_MULT_NEAR = 0.3f;

	//How large the chance is, each day, that a small explosion is spawned visually on the fleet
	private static final float MINI_EXPLOSION_CHANCE_PER_DAY = 9f;

	//Size of the mini-explosions
	private static final float MINI_EXPLOSION_MAX_SIZE = 35f;
	private static final float MINI_EXPLOSION_MIN_SIZE = 5f;

	//Lifetime of the mini-explosions. Specified in days
	private static final float MINI_EXPLOSION_MAX_DURATION = 1.2f;
	private static final float MINI_EXPLOSION_MIN_DURATION = 0.5f;

	//Color of the mini-explosions
	private static final Color MINI_EXPLOSION_COLOR = new Color(255, 185, 110);

	//How large the chance is, each day, that a small explosion is spawned visually on the fleet
	private static final float DIRECT_HIT_CHANCE_PER_DAY = 5f;

	//Damage of a direct hit
	private static final float DIRECT_HIT_DAMAGE = 100f;

	//How long of a "streak" of explosions triggered by a direct hit are
	private static final float DIRECT_HIT_PARTICLE_STREAM_LENGTH = 100f;

	//How many particles are spawned by a direct hit
	private static final int DIRECT_HIT_PARTICLE_COUNT = 35;

	//How wide the particle stream is from a direct hit
	private static final float DIRECT_HIT_CONE_ANGLE = 15f;

	//How long a direct hit particle stream lasts for. Min and Max are at the beginning/end of the plume, respectively
	private static final float DIRECT_HIT_MIN_DURATION = 1.41f;
	private static final float DIRECT_HIT_MAX_DURATION = 1.84f;
	
	public static class BombardmentAreaParams {
		public MarketAPI relatedMarket;
		public float innerSize;
		public float outerSize;
		public String name;
		public BombardmentAreaParams(MarketAPI relatedMarket, float innerSize, float outerSize, String name) {
			this.relatedMarket = relatedMarket;
			this.innerSize = innerSize;
			this.outerSize = outerSize;
			this.name = name;
		}
	}

	
	@Override
	protected Object readResolve() {
		super.readResolve();
		return this;
	}

	//Function for rendering the terrain on the sector map.
	private transient RingRenderer rr;
	public void renderOnMap(float factor, float alphaMult) {
		if (customParams == null) return;
		if (rr == null) {
			rr = new RingRenderer("systemMap", "map_ring"); //Texture "path" in settings.json
		}
		Color color = customParams.relatedMarket.getFaction().getColor(); //Color to render the map icon with
		float renderWidth = 50f;
		rr.render(entity.getLocation(),
				customParams.outerSize - renderWidth * 0.5f,
				customParams.outerSize + renderWidth * 0.5f,
				  color,
				  false, factor, alphaMult);
	}

	//Main advance function; only calls our superimplementation, since all effects are handled in applyEffect() instead
	public void advance(float amount) {
		super.advance(amount);
	}

	//Intitializer function; handles naming and storing the correct parameters
	public BombardmentAreaParams customParams;
	public void init(String terrainId, SectorEntityToken entity, Object param) {
		if (param instanceof BombardmentAreaParams) {
			customParams = (BombardmentAreaParams) param;
			super.init(terrainId, entity, new RingParams(customParams.outerSize, customParams.outerSize/2f, entity));
			name = customParams.name;
			if (name == null) {
				name = "Bombardment Zone";
			}
		}
	}
	
	//Render function for the effect; we don't actually render anything, so this is currently unused
	public void render(CampaignEngineLayers layer, ViewportAPI viewport) {
		/*-Do nothing-*/
	}

	//Runs once per affected fleet in the area, with "days" being the campaign-days representation of the more ubiquitous "amount"
	@Override
	public void applyEffect(SectorEntityToken entity, float days) {
		if (entity instanceof CampaignFleetAPI) {
			CampaignFleetAPI fleet = (CampaignFleetAPI) entity;

			//If we are in direct-hit range, register that
			boolean isInDirectHitRange = false;
			if (MathUtils.getDistance(this.entity.getLocation(), fleet.getLocation()) - (fleet.getRadius()*0.75f) < this.customParams.innerSize) {
				fleet.getMemoryWithoutUpdate().set("$al_bombardment_near_key", true, days*2f);
				isInDirectHitRange = true;
			}

			//If we are not hostile to the area's owners, the code simply stops after that
			if (!customParams.relatedMarket.getFaction().isAtWorst(fleet.getFaction(), RepLevel.INHOSPITABLE)) {
				//Applies a CR debuff to the fleet's members
				for (FleetMemberAPI member : fleet.getFleetData().getMembersListCopy()) {
					//Gets how fast the ship normally regenerates CR
					float recoveryRate = member.getStats().getBaseCRRecoveryRatePercentPerDay().getModifiedValue();
					float lossRate = member.getStats().getBaseCRRecoveryRatePercentPerDay().getBaseValue();

					//Calculates the member's resistance to this effect. Currently, this is based on HE damage resistance
					float resistance = member.getStats().getHighExplosiveDamageTakenMult().getModifiedValue();

					//Adjusts CR loss to account for both distance and ship resistance to its effects
					float adjustedLossMult = (0f + CR_LOSS_MULT_FAR * resistance);
					if (isInDirectHitRange) {
						adjustedLossMult = (0f + CR_LOSS_MULT_NEAR * resistance);
					}

					float loss = (-1f * recoveryRate + -1f * lossRate * adjustedLossMult) * days * 0.01f;
					float curr = member.getRepairTracker().getBaseCR();
					if (loss > curr) loss = curr;

					member.getRepairTracker().applyCREvent(loss, "al_bombardment_zone", "Bombardment Zone");

					//TODO: try getting the in-combat effect registered via buff management
					//member.getBuffManager().addBuffOnlyUpdateStat(new CRLossPerSecondBuff(buffId + "_2", degradationMult, buffDur));
				}

				//Roll to see if an explosion should be spawned this frame
				LocationAPI containingLocation = fleet.getContainingLocation();
				if (Math.random() < MINI_EXPLOSION_CHANCE_PER_DAY*days) {
					//Gets a random point near the fleet and bombs it
					Vector2f targetPoint = MathUtils.getRandomPointInCircle(fleet.getLocation(), fleet.getRadius()+75f);
					containingLocation.addHitParticle(targetPoint, Misc.ZERO, MathUtils.getRandomNumberInRange(MINI_EXPLOSION_MIN_SIZE, MINI_EXPLOSION_MAX_SIZE),
							1f, MathUtils.getRandomNumberInRange(MINI_EXPLOSION_MIN_DURATION, MINI_EXPLOSION_MAX_DURATION), MINI_EXPLOSION_COLOR);
				}

				//If we're close, we also roll for direct hits
				if (isInDirectHitRange && Math.random() < DIRECT_HIT_CHANCE_PER_DAY*days) {
					//Safety check: empty fleets can't get hit
					if (fleet.getFleetData().getMembersInPriorityOrder().isEmpty()) {
						return;
					}

					//Gets a random fleet member and damages it
					FleetMemberAPI targetMember = fleet.getFleetData().getMembersInPriorityOrder().get(MathUtils.getRandomNumberInRange(0, fleet.getFleetData().getMembersInPriorityOrder().size()-1));
					targetMember.getStatus().applyDamage(DIRECT_HIT_DAMAGE);

					//Spawns a big particle plume representing a direct hit
					Vector2f originPoint = new Vector2f(this.entity.getLocation());
					Vector2f targetStartPoint = MathUtils.getRandomPointInCircle(fleet.getLocation(), fleet.getRadius()*0.8f);
					float angle = VectorUtils.getAngle(originPoint, targetStartPoint);
					for (int i = 0; i < DIRECT_HIT_PARTICLE_COUNT; i++) {
						//Gets a location in the cone, depending on how far we've looped
						float distance = DIRECT_HIT_PARTICLE_STREAM_LENGTH * i / (float)DIRECT_HIT_PARTICLE_COUNT;
						float angleVariance = MathUtils.getRandomNumberInRange(-DIRECT_HIT_CONE_ANGLE, DIRECT_HIT_CONE_ANGLE); //TODO: make this... more spray-ish, less angle-ish
						Vector2f spawnPoint = MathUtils.getPoint(targetStartPoint, distance, angle+angleVariance);

						//Sets a particle size based on how far from the origin we are
						float particleSize = MathUtils.getRandomNumberInRange(MINI_EXPLOSION_MIN_SIZE, MINI_EXPLOSION_MAX_SIZE);
						particleSize *= i / (float)DIRECT_HIT_PARTICLE_COUNT;

						//Sets a particle duration
						float particleDuration = (((float)DIRECT_HIT_PARTICLE_COUNT - i) * DIRECT_HIT_MIN_DURATION + i * (float)DIRECT_HIT_MAX_DURATION) / (float)DIRECT_HIT_PARTICLE_COUNT;

						//Actually spawns the explosion
						containingLocation.addHitParticle(spawnPoint, Misc.ZERO, particleSize,1f,
								particleDuration, MINI_EXPLOSION_COLOR);
					}
				}
			}
		}
	}

	//Determines when loop sounds should play
	@Override
	protected boolean shouldPlayLoopOne() {
		if (customParams.relatedMarket.getFaction().isAtWorst(Global.getSector().getPlayerFleet().getFaction(), RepLevel.INHOSPITABLE)) {
			return false;
		}

		Object mem = Global.getSector().getPlayerFleet().getMemoryWithoutUpdate().get("$al_bombardment_near_key");
		if (!(mem instanceof Boolean)) {
			return super.shouldPlayLoopOne();
		} else {
			boolean isInShortRange = (boolean)mem;
			return super.shouldPlayLoopOne() && !isInShortRange;
		}
	}

	@Override
	protected boolean shouldPlayLoopTwo() {
		if (customParams.relatedMarket.getFaction().isAtWorst(Global.getSector().getPlayerFleet().getFaction(), RepLevel.INHOSPITABLE)) {
			return false;
		}

		Object mem = Global.getSector().getPlayerFleet().getMemoryWithoutUpdate().get("$al_bombardment_near_key");
		if (!(mem instanceof Boolean)) {
			return false;
		} else {
			boolean isInShortRange = (boolean)mem;
			return super.shouldPlayLoopTwo() && isInShortRange;
		}
	}

	//Whether the terrain has a tooltip
	public boolean hasTooltip() {
		return true;
	}

	//The name displayed for the tooltip
	public String getNameForTooltip() {
		//If we are allied to the owner of this terrain, we inform the player of it
		if (customParams.relatedMarket.getFaction().isAtWorst(Factions.PLAYER, RepLevel.INHOSPITABLE)) {
			return name + " - Nonhostile";
		} else {
			return name;
		}
	}

	//Creates the main tooltip for the effect in the campaign view
	public void createTooltip(TooltipMakerAPI tooltip, boolean expanded) {
		float pad = 10f;
		float small = 5f;
		Color gray = Misc.getGrayColor();
		Color highlight = Misc.getHighlightColor();
		Color fuel = Global.getSettings().getColor("progressBarFuelColor");
		Color bad = Misc.getNegativeHighlightColor();
		
		//tooltip.addTitle(params.name);
		tooltip.addTitle(getNameForTooltip());
		//tooltip.addPara(Global.getSettings().getDescription(getTerrainId(), Type.TERRAIN).getText1(), pad);
		
		float nextPad = pad;
		if (expanded) {
			tooltip.addSectionHeading("Travel", Alignment.MID, pad);
			nextPad = small;
		}

		//Changes the tooltip depending on relations to the faction owning the area
		if (customParams.relatedMarket.getFaction().isAtWorst(Factions.PLAYER, RepLevel.INHOSPITABLE)) {
			tooltip.addPara("As you are non-hostile to the faction firing strategic artillery in the area, your ships are relatively unaffected." +
							"Drawing their ire while too close is probably %s, though...", pad,
					highlight,
					"a bad idea"
			);
		} else {
			//Also change tooltip based on if we're in the inner area or not
			if (Global.getSector().getPlayerFleet().getMemoryWithoutUpdate().contains("$al_bombardment_near_key")) {
				tooltip.addPara("Strategic-scale suppression fire %s of your ships, and intermittent direct hits %s to random ships", pad,
						bad,
						"constantly drains the CR",
						"deal massive hull damage"
				);
			} else {
				tooltip.addPara("Strategic-scale suppression fire %s of your ships. You're still far away to not get direct hits, though...", pad,
						bad,
						"constantly drains the CR"
				);
			}
		}

		//The expanded tooltip also explains in-combat effects
		//TODO: actually add in once/if the effects are implemented
		/*
		if (expanded) {
			tooltip.addSectionHeading("Combat", Alignment.MID, pad);
			//These *also* vary depending on if we're allied or not
			if (params.relatedFaction.isAtWorst(Factions.PLAYER, RepLevel.INHOSPITABLE)) {
				tooltip.addPara("Massive cannons will fire at any ships hostile to the suppressing faction. As you are non-hostile to them, your ships will not be directly targeted.", small);
			} else {
				tooltip.addPara("Massive cannons will fire upon your fleet intermittently while in combat, which deal extreme damage if not avoided.", small);
			}
		}
		*/
	}

	//Whether the tooltip can be expanded to show more info or not
	public boolean isTooltipExpandable() {
		return false; //TODO: add this if we want an extended tooltip later
	}

	//The width of the tooltip window
	public float getTooltipWidth() {
		return 350f;
	}

	//The category of effects; determines which effects to stack with. Null means stacking with everything, even itself
	public String getEffectCategory() {
		return null;
	}

	//AI flags for the terrain. This terrain has no flags, since we don't want allies to fear it at all
	public boolean hasAIFlag(Object flag) {
		return false;
	}
}
