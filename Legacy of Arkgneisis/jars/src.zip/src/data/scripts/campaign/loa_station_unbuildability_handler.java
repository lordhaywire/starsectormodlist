package data.scripts.campaign;

import com.fs.starfarer.api.impl.campaign.econ.impl.OrbitalStation;

/**
 * Prevents this orbital station industry from being built normally by the player
 */
public class loa_station_unbuildability_handler extends OrbitalStation {

    @Override
    public boolean isAvailableToBuild() {
        return false;
    }

    @Override
    public String getUnavailableReason() {
        return "Station type unavailable.";
    }

    @Override
    public boolean showWhenUnavailable() {
        return false;
    }
}
