package data.scripts.campaign;

import com.fs.starfarer.api.EveryFrameScript;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.SpecialItemData;
import com.fs.starfarer.api.characters.MutableCharacterStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.fleet.FleetMemberAPI;
import com.fs.starfarer.api.impl.campaign.ids.Skills;
import com.fs.starfarer.api.impl.campaign.skills.AptitudeDesc;
import com.fs.starfarer.api.util.IntervalUtil;
import com.fs.starfarer.api.util.Misc;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class loa_champblueprintscript implements EveryFrameScript {
    //This is the hull ID string the ship has to contain to trigger the script
    private final static String HULL_ID = "loaht_champion1";

    //This denotes whether we have 0: not gotten the ship yet, 1: got the ship in our fleet or 2: got and subsequently lost the ship
    private int stateOfScript = 0;

    //This is set to true once all blueprints in the ship has been discovered
    private boolean isFinished = false;

    //Timer, determines how often the script is run. We check on average every four seconds
    private IntervalUtil timer = new IntervalUtil(3.8f, 4.20f);

    //The unlock speed multiplier we currently have. This is just so we can track if we should inform the user when it increases
    private float currentUnlockMult = 1f;

    //The multipliers on how fast the blueprints are recovered, at max number of skills and minimum number of skills
    //  Max skill count is 10 skills, with Elite skills counting as 2 skills
    private static final float TECH_UNLOCK_MULT_MIN = 1f;
    private static final float TECH_UNLOCK_MULT_MAX = 8f;

    //The strings to describe how long it will take to recover stuff depending on how fast your speed multiplier is
    //  If your unlock speed is higher or equal to the number in the map here, the description will show
    //  Example: You have enough skills for unlock speed to be x3.7. Then, the description with number 3 will show here
    private static final Map<Float, String> LENGTH_DESCRIPTIONS = new HashMap<>();
    static {
        LENGTH_DESCRIPTIONS.put(0f, "will take a very long time");
        LENGTH_DESCRIPTIONS.put(2f, "will take quite some time");
        LENGTH_DESCRIPTIONS.put(4f, "will take some time");
        LENGTH_DESCRIPTIONS.put(6f, "will take a little time");
    }

    //All the weapons that can be unlocked, and how much time it takes to unlock them (in campaign-seconds; 5 seconds or so is a day)
    //Note that the *actual* time until unlock is affected by your Technology skills (see TECH_UNLOCK_MULT above)
    //The string represents the ID for the blueprint package to add
    private static final Map<Float, String> BLUEPRINT_UNLOCKS = new HashMap<>();
    static {
        BLUEPRINT_UNLOCKS.put(1825f, "loa_warpshot_package");
        BLUEPRINT_UNLOCKS.put(3650f, "loa_zapflak_package");
        BLUEPRINT_UNLOCKS.put(5475f, "loa_rupturecannon_package");
        BLUEPRINT_UNLOCKS.put(7300f, "loa_hyperbeam_package");
    }
    
    //The name to display for each blueprint package; should ideally match up with the actual weapon in the package
    private static final Map<String, String> UNLOCK_NAMES = new HashMap<>();
    static {
        UNLOCK_NAMES.put("loa_warpshot_package", "Warpshot Repeater");
        UNLOCK_NAMES.put("loa_zapflak_package", "Electrostatic Autocannon");
        UNLOCK_NAMES.put("loa_rupturecannon_package", "Rupture Cannon");
        UNLOCK_NAMES.put("loa_hyperbeam_package", "Rift Projector");
    }

    //The counter for tracking how far we are along with our discoveries
    private float discoveryCounter = 0f;

    //What is the highest-complexity discovery we've had yet? -UNUSED RIGHT NOW-
    private float alreadyDiscoveredMax = 0f;

    //List of our already-found weapons
    private List<String> alreadyFoundWeapons = new ArrayList<>();

    //Keeps track of our Intel
    private loa_champblueprintintel intel = null;

    @Override
    public void advance(float amount) {
        //Tick our timer
        timer.advance(amount);

        //If our timer isn't done, don't run anything
        if (timer.intervalElapsed()) {
            //First, get some useful data
            boolean hasShip = playerFleetHasShip();
            float newUnlockMult = getUnlockMult();

            //Then, find our current "state"
            switch (stateOfScript) {
                case 0:
                    //Secretly update our unlock speed
                    currentUnlockMult = newUnlockMult;

                    //If we got the ship this execution, run the script for getting the ship the first time
                    if (hasShip) {
                        getShipFirstTime();
                    }
                    break;
                case 1:
                    //If we no longer have the ship, run the appropriate code
                    if (!hasShip) {
                        loseShip();
                    }

                    //If our unlock speed is higher now than it was earlier, alert the player of this and increase the stored unlock speed
                    if (newUnlockMult > currentUnlockMult) {
                        Global.getSector().getCampaignUI().addMessage(
                                "Thanks to your heightened aptitude with Technology, decrypting the Lancer's databanks should now take notably less time.",
                                Global.getSettings().getColor("standardTextColor"),
                                "Technology","notably less time",
                                Global.getSettings().getColor("mountBlueColor"),
                                Global.getSettings().getColor("yellowTextColor"));
                        currentUnlockMult = newUnlockMult;
                    }

                    //Then, tick along our "discovery" counter depending on our tech aptitude
                    discoveryCounter += ((timer.getMinInterval() + timer.getMaxInterval())/2f) * getUnlockMult();

                    //Then, check if we get a new blueprint!
                    for (float wepTime : BLUEPRINT_UNLOCKS.keySet()) {
                        //If we have already found the weapon, we ignore it
                        if (alreadyFoundWeapons.contains(BLUEPRINT_UNLOCKS.get(wepTime))) {
                            continue;
                        }

                        //If we *haven't* already gotten this thing, we check if our progress is high enough to get it. If so, we run the scripts for weapon-getting
                        //Note that we run it slightly different if this is the last weapon we can discover
                        if (discoveryCounter > wepTime) {
                            addBlueprint (BLUEPRINT_UNLOCKS.get(wepTime), (alreadyFoundWeapons.size() >= (BLUEPRINT_UNLOCKS.keySet().size()-1)));
                            alreadyFoundWeapons.add(BLUEPRINT_UNLOCKS.get(wepTime));
                        }
                    }

                    //Lastly, update our Intel with eventual status changes
                    intel.advanceQuestStage(alreadyFoundWeapons.size());

                    //Even *more* lastly, we can end the script completely if we have unlocked all the weapons
                    if (alreadyFoundWeapons.size() >= BLUEPRINT_UNLOCKS.keySet().size()) {
                        isFinished = true;
                    }

                    break;
                case 2:
                    //Secretly update our tech aptitude
                    currentUnlockMult = newUnlockMult;

                    //If we have regained the ship, run the script for getting the ship back
                    if (hasShip) {
                        getShipAgain();
                    }
                    break;
                default:
                    //It should never reach this point; throw a crash errorso we find out why it got here
                    throw new RuntimeException("UNREACHABLE STATE EXCEPTION: An EveryFrameScript has reached a state it should never be able to reach." +
                            " Contact Nicke535 with a modlist and what you were doing at the time of the crash. Error code: LoA-001");
            }
        }
    }


    //Function for checking if the ship is in the player's fleet
    private boolean playerFleetHasShip () {
        CampaignFleetAPI playerFleet = Global.getSector().getPlayerFleet();
        if (playerFleet == null) {
            return false;
        }

        //Go through each fleetMemberAPI and check their hull IDs
        //If we find the correct one, we run our "found the ship" code and finish for this frame
        for (FleetMemberAPI member : playerFleet.getMembersWithFightersCopy()) {
            //Ignore fighters
            if (member.getHullSpec().getHullSize() == ShipAPI.HullSize.FIGHTER) {
                continue;
            }

            //Then, check the ID
            if (member.getHullId().contains(HULL_ID)) {
                return true;
            }
        }
        return false;
    }


    //Function for getting the player's current multiplier on unlock speed
    private float getUnlockMult() {
        float level = Global.getSector().getPlayerStats().getAptitudeLevel(Skills.APT_TECHNOLOGY);
        for (MutableCharacterStatsAPI.SkillLevelAPI skill : Global.getSector().getPlayerStats().getSkillsCopy()) {
            if (skill.getSkill().getGoverningAptitudeId().equals(Skills.APT_TECHNOLOGY)) {
                level += skill.getLevel();
            }
        }
        level = Math.min(level, 10f) / 10f;
        return Misc.interpolate(TECH_UNLOCK_MULT_MIN, TECH_UNLOCK_MULT_MAX, level);
    }


    //Function for doing anything that needs to be done after getting the ship the first time
    private void getShipFirstTime () {
        //Adds our intel
        loa_champblueprintintel intel = new loa_champblueprintintel(this);
        if (!intel.isDone()) {
            this.intel = intel;
            Global.getSector().getIntelManager().addIntel(intel, true);
        }

        //Spawns a message to tell the player all they need to know about the new acquiring
        Global.getSector().getCampaignUI().addMessage(
                "The databanks of the recently recovered Lancer class cruiser are completely foreign to you and seem to be in bad shape, a preliminary analysis suggests you might still be able to piece together some useful data from what is left." +
                        "The software running the Lancer's computer cores is every bit as enigmatic as its hardware. With your current aptitude in Technology, decrypting it " +
                        getCurrentLengthDescription() + ".",
                Global.getSettings().getColor("standardTextColor"),
                "Technology",getCurrentLengthDescription(),
                Global.getSettings().getColor("mountBlueColor"),
                Global.getSettings().getColor("yellowTextColor"));
        stateOfScript = 1;
    }


    //Function for doing anything that needs to be done after getting the ship subsequent times
    private void getShipAgain () {
        Global.getSector().getCampaignUI().addMessage(
                "Having re-accquired the Lancer, you begin anew with working through its databanks, though at your current aptitude in Technology cracking the encryption " +
                        getCurrentLengthDescription() + ".",
                Global.getSettings().getColor("standardTextColor"),
                "Technology",getCurrentLengthDescription(),
                Global.getSettings().getColor("mountBlueColor"),
                Global.getSettings().getColor("yellowTextColor"));
        stateOfScript = 1;
    }


    //Function for applying all effects that happen when you lose the ship
    private void loseShip () {
        Global.getSector().getCampaignUI().addMessage(
        "As the Lancer is no longer in your fleet, all data decryption efforts have halted.",
                Global.getSettings().getColor("standardTextColor"),
                "Lancer","halted",
                Global.getSettings().getColor("textFriendColor"),
                Global.getSettings().getColor("flatRedTextColor"));
        stateOfScript = 2;
    }


    //Function for adding the recovered blueprint to the player's inventory, and alerting them that this has happened
    private void addBlueprint (String blueprintID, boolean wasFinalBlueprint) {
        //First, actually add the blueprint to the player's fleet
        Global.getSector().getPlayerFleet().getCargo().addSpecial(new SpecialItemData(blueprintID, null), 1f);

        //Then, tell the player this has happened, with the "actual" name of the weapon. Have a separate message if this was the last weapon uncovered
        String nameToPrint = UNLOCK_NAMES.get(blueprintID);
        if (wasFinalBlueprint) {
            Global.getSector().getCampaignUI().addMessage(
                    "You have succesfully recovered one last blueprint from the Lancer's databanks and spliced it onto a hacked production chip. The data identifies it as the " + nameToPrint + ".",
                    Global.getSettings().getColor("standardTextColor"),
                    "one last",nameToPrint,
                    Global.getSettings().getColor("flatRedTextColor"),
                    Global.getSettings().getColor("yellowTextColor"));
        } else {
            Global.getSector().getCampaignUI().addMessage(
                    "You have succesfully recovered what seems to be a blueprint from the Lancer's databanks and downloaded it onto a hacked production chip. The data in question identifies the item as a " + nameToPrint + ". Analysis indicates there is still more data to be recovered, however...",
                    Global.getSettings().getColor("standardTextColor"),
                    nameToPrint,"still more blueprints to be recovered",
                    Global.getSettings().getColor("yellowTextColor"),
                    Global.getSettings().getColor("yellowTextColor"));
        }
    }

    //Function for getting the "how long is it going to take" text at our current unlock speed multiplier
    private String getCurrentLengthDescription() {
        float currentMax = 0f;
        String text = "ERROR";
        for (Map.Entry<Float, String> entry : LENGTH_DESCRIPTIONS.entrySet()) {
            if (entry.getKey() >= currentMax && entry.getKey() <= getUnlockMult()) {
                text = entry.getValue();
            }
        }
        return text;
    }


    //No need to run the script when paused
    @Override
    public boolean runWhilePaused() {
        return false;
    }

    //We have no use for the script once we've discovered all the blueprints
    @Override
    public boolean isDone() {
        return isFinished;
    }
}
