package data.scripts;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.*;
import com.fs.starfarer.api.characters.FullName;
import com.fs.starfarer.api.characters.FullName.Gender;
import com.fs.starfarer.api.characters.ImportantPeopleAPI;
import com.fs.starfarer.api.characters.PersonAPI;
import com.fs.starfarer.api.BaseModPlugin;
import com.fs.starfarer.api.impl.campaign.econ.impl.sfc_specialItemsEffectRepo;
import com.fs.starfarer.api.impl.campaign.fleets.FleetFactoryV3;
import com.fs.starfarer.api.impl.campaign.fleets.FleetParamsV3;
import com.fs.starfarer.api.impl.campaign.ids.*;
import com.fs.starfarer.api.campaign.econ.MarketAPI;

import com.fs.starfarer.api.impl.campaign.intel.bar.events.BarEventManager;
import com.fs.starfarer.api.impl.campaign.intel.bar.events.sfc_CompanyFuelBarEventCreator;
import com.fs.starfarer.api.impl.campaign.missions.academy.GADeliverVIP;
import com.fs.starfarer.api.impl.campaign.missions.askonia.TheUsurpers;
import com.fs.starfarer.api.impl.campaign.skills.OfficerTraining;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;

import java.awt.*;
//import exerelin.campaign.SectorManager;

public class sfc_ModPlugin extends BaseModPlugin {

    public static boolean isDE = Global.getSettings().getModManager().isModEnabled("Diktat Enhancement");
    public static boolean isCSP = Global.getSettings().getModManager().isModEnabled("Csp");
    public static boolean isUAF = Global.getSettings().getModManager().isModEnabled("uaf");

    public static String sfckween = "sfckween"; //glorious science
    public static String sfcruni = "sfcruni"; //looks familiar
    public static String sfcruni2 = "sfcruni2"; //you have met a terrible fate haven't you
    public static String sfcyenni = "sfcyenni"; //also looks familiar
    public static String sfcmann = "sfcmann"; //2nd coolest old guy in the Sindrian Fuel Company
    public static String sfcruy = "sfcruy"; //envious of the lion's guard
    public static String sfcdunn = "sfcdunn"; //loves "surprise internship" camps
    public static String sfcfleures = "sfcfleures"; //brightest flower
    public static String sfcjenkins = "sfcjenkins"; //velmarie's sass
    public static String sfcvolturny = "sfcvolturny"; //best mascot
    public static String sfcfakeandrada = "sfcfakeandrada"; //the phillip andrada experience
    public static String sfchero = "sfchero"; //a true hero of the Sindrian Fuel Company
    public static String sfcrhea = "sfcrhea"; //a true hero's assistant of the Sindrian Fuel Company
    public static String sfcfonz = "sfcfonz"; //not the fonz
    public static String sfcarthur = "sfcarthur"; //religious zealot
    public static String dejalecto = "dejalecto"; //preacher for the Lion and DE integration
    public static String cspmongaera = "cspmongaera"; //deathless
    public static String nftpononzi = "nftpononzi"; //does he have an ape?
    public static String nftgimlet = "nftgimlet"; //ol' gimlet eye

    //private static String sfc_OEText = Global.getSettings().getString("sfc_pagsm", "sfc_ordnanceExpertiseText");
    //private static String sfc_OEAuthor = Global.getSettings().getString("sfc_pagsm", "sfc_ordnanceExpertiseAuthor");
    //private static String sfc_lionsguardHQ = Global.getSettings().getString("sfc_pagsm", "sfc_lionsguardHQ");
    //rivate static String sfc_deUnpropagandaTitle = Global.getSettings().getString("sfc_pagsm", "sfc_deUnpropagandaTitle");
    //private static String sfc_deUnpropagandaText = Global.getSettings().getString("sfc_pagsm", "sfc_deUnpropagandaText");


    private static void addGrandFuelFleet() {
        SectorAPI sector = Global.getSector();
        StarSystemAPI system = sector.getStarSystem("Askonia");
        SectorEntityToken sfcvol = system.getEntityById("volturn");

        ImportantPeopleAPI ip = Global.getSector().getImportantPeople();

        PersonAPI sfcyenniPerson = Global.getFactory().createPerson();
        sfcyenniPerson.setId(sfcyenni);
        sfcyenniPerson.setFaction(Factions.DIKTAT);
        sfcyenniPerson.setGender(Gender.FEMALE);
        sfcyenniPerson.setPostId("sfcfleetadmiral");
        sfcyenniPerson.setRankId(Ranks.SPACE_ADMIRAL);
        sfcyenniPerson.setPersonality(Personalities.AGGRESSIVE);
        sfcyenniPerson.setImportance(PersonImportance.HIGH);
        sfcyenniPerson.setVoice(Voices.SOLDIER);
        sfcyenniPerson.getName().setFirst("Ruka");
        sfcyenniPerson.getName().setLast("Yenni");
        sfcyenniPerson.setPortraitSprite(Global.getSettings().getSpriteName("characters", "sfcyenni"));
        sfcyenniPerson.getStats().setLevel(15);
        sfcyenniPerson.getStats().setSkillLevel("sfc_titan", 2);
        sfcyenniPerson.getStats().setSkillLevel(Skills.COMBAT_ENDURANCE, 2);
        sfcyenniPerson.getStats().setSkillLevel(Skills.MISSILE_SPECIALIZATION, 2);
        sfcyenniPerson.getStats().setSkillLevel(Skills.FIELD_MODULATION, 2);
        sfcyenniPerson.getStats().setSkillLevel(Skills.IMPACT_MITIGATION, 2);
        sfcyenniPerson.getStats().setSkillLevel(Skills.POLARIZED_ARMOR, 2);
        sfcyenniPerson.getStats().setSkillLevel(Skills.HELMSMANSHIP, 1);
        sfcyenniPerson.getStats().setSkillLevel(Skills.DAMAGE_CONTROL, 1);
        sfcyenniPerson.getStats().setSkillLevel(Skills.TARGET_ANALYSIS, 1);
        sfcyenniPerson.getStats().setSkillLevel(Skills.ENERGY_WEAPON_MASTERY, 1);
        sfcyenniPerson.getStats().setSkillLevel(Skills.COORDINATED_MANEUVERS, 1);
        sfcyenniPerson.getStats().setSkillLevel(Skills.CREW_TRAINING, 1);
        sfcyenniPerson.getStats().setSkillLevel(Skills.OFFICER_TRAINING, 1);
        sfcyenniPerson.getStats().setSkillLevel(Skills.SUPPORT_DOCTRINE, 1);
        sfcyenniPerson.getStats().setSkillLevel(Skills.TACTICAL_DRILLS, 1);
        sfcyenniPerson.getStats().setSkillLevel(Skills.OFFICER_MANAGEMENT, 1);
        sfcyenniPerson.addTag("coff_forcecapture");
        sfcyenniPerson.addTag("coff_prisonerdialog");
        sfcyenniPerson.getMemoryWithoutUpdate().set("$coff_allowedactions", "talk");
        sfcyenniPerson.getMemoryWithoutUpdate().set("$coff_dialogtrigger", "sfcyenni");
        sfcyenniPerson.getMemoryWithoutUpdate().set("$nex_noOfficerDeath", true);
        sfcyenniPerson.getMemoryWithoutUpdate().set("$chatterChar", "sfcyenni");
        ip.addPerson(sfcyenniPerson);

        PersonAPI person1 = Global.getSector().getFaction("sindrian_diktat").createRandomPerson(FullName.Gender.ANY);
        person1.setId("sfc_generic_officer1");
        person1.setPostId(Ranks.POST_OFFICER);
        person1.setRankId(Ranks.POST_OFFICER);
        person1.setPersonality(Personalities.AGGRESSIVE);
        person1.getStats().setSkillLevel(Skills.COMBAT_ENDURANCE, 2);
        person1.getStats().setSkillLevel(Skills.MISSILE_SPECIALIZATION, 2);
        person1.getStats().setSkillLevel(Skills.TARGET_ANALYSIS, 2);
        person1.getStats().setSkillLevel(Skills.FIELD_MODULATION, 2);
        person1.getStats().setSkillLevel(Skills.IMPACT_MITIGATION, 2);
        person1.getStats().setSkillLevel(Skills.HELMSMANSHIP, 2);
        person1.getStats().setSkillLevel(Skills.DAMAGE_CONTROL, 2);
        person1.addTag("coff_nocapture");
        person1.getStats().setLevel(7);

        PersonAPI person2 = Global.getSector().getFaction("sindrian_diktat").createRandomPerson(FullName.Gender.ANY);
        person2.setId("sfc_generic_officer2");
        person2.setPostId(Ranks.POST_OFFICER);
        person2.setRankId(Ranks.POST_OFFICER);
        person2.setPersonality(Personalities.AGGRESSIVE);
        person2.getStats().setSkillLevel(Skills.COMBAT_ENDURANCE, 2);
        person2.getStats().setSkillLevel(Skills.MISSILE_SPECIALIZATION, 2);
        person2.getStats().setSkillLevel(Skills.TARGET_ANALYSIS, 2);
        person2.getStats().setSkillLevel(Skills.FIELD_MODULATION, 2);
        person2.getStats().setSkillLevel(Skills.IMPACT_MITIGATION, 2);
        person2.getStats().setSkillLevel(Skills.HELMSMANSHIP, 2);
        person2.getStats().setSkillLevel(Skills.DAMAGE_CONTROL, 2);
        person2.addTag("coff_nocapture");
        person2.getStats().setLevel(7);

        PersonAPI person3 = Global.getSector().getFaction("sindrian_diktat").createRandomPerson(FullName.Gender.ANY);
        person3.setId("sfc_generic_officer3");
        person3.setPostId(Ranks.POST_OFFICER);
        person3.setRankId(Ranks.POST_OFFICER);
        person3.setPersonality(Personalities.AGGRESSIVE);
        person3.getStats().setSkillLevel(Skills.COMBAT_ENDURANCE, 2);
        person3.getStats().setSkillLevel(Skills.MISSILE_SPECIALIZATION, 2);
        person3.getStats().setSkillLevel(Skills.TARGET_ANALYSIS, 2);
        person3.getStats().setSkillLevel(Skills.FIELD_MODULATION, 2);
        person3.getStats().setSkillLevel(Skills.IMPACT_MITIGATION, 2);
        person3.getStats().setSkillLevel(Skills.HELMSMANSHIP, 2);
        person3.getStats().setSkillLevel(Skills.DAMAGE_CONTROL, 2);
        person3.addTag("coff_nocapture");
        person3.getStats().setLevel(7);

        PersonAPI person4 = Global.getSector().getFaction("sindrian_diktat").createRandomPerson(FullName.Gender.ANY);
        person4.setId("sfc_generic_officer4");
        person4.setPostId(Ranks.POST_OFFICER);
        person4.setRankId(Ranks.POST_OFFICER);
        person4.setPersonality(Personalities.AGGRESSIVE);
        person4.getStats().setSkillLevel(Skills.COMBAT_ENDURANCE, 2);
        person4.getStats().setSkillLevel(Skills.MISSILE_SPECIALIZATION, 2);
        person4.getStats().setSkillLevel(Skills.TARGET_ANALYSIS, 2);
        person4.getStats().setSkillLevel(Skills.FIELD_MODULATION, 2);
        person4.getStats().setSkillLevel(Skills.IMPACT_MITIGATION, 2);
        person4.getStats().setSkillLevel(Skills.HELMSMANSHIP, 2);
        person4.getStats().setSkillLevel(Skills.DAMAGE_CONTROL, 2);
        person4.addTag("coff_nocapture");
        person4.getStats().setLevel(7);

        PersonAPI person5 = Global.getSector().getFaction("sindrian_diktat").createRandomPerson(FullName.Gender.ANY);
        person5.setId("sfc_generic_officer5");
        person5.setPostId(Ranks.POST_OFFICER);
        person5.setRankId(Ranks.POST_OFFICER);
        person5.setPersonality(Personalities.AGGRESSIVE);
        person5.getStats().setSkillLevel(Skills.COMBAT_ENDURANCE, 2);
        person5.getStats().setSkillLevel(Skills.MISSILE_SPECIALIZATION, 2);
        person5.getStats().setSkillLevel(Skills.TARGET_ANALYSIS, 2);
        person5.getStats().setSkillLevel(Skills.FIELD_MODULATION, 2);
        person5.getStats().setSkillLevel(Skills.IMPACT_MITIGATION, 2);
        person5.getStats().setSkillLevel(Skills.HELMSMANSHIP, 2);
        person5.getStats().setSkillLevel(Skills.DAMAGE_CONTROL, 2);
        person5.addTag("coff_nocapture");
        person5.getStats().setLevel(7);

        PersonAPI person6 = Global.getSector().getFaction("sindrian_diktat").createRandomPerson(FullName.Gender.ANY);
        person6.setId("sfc_generic_officer6");
        person6.setPostId(Ranks.POST_OFFICER);
        person6.setRankId(Ranks.POST_OFFICER);
        person6.setPersonality(Personalities.AGGRESSIVE);
        person6.getStats().setSkillLevel(Skills.COMBAT_ENDURANCE, 2);
        person6.getStats().setSkillLevel(Skills.MISSILE_SPECIALIZATION, 2);
        person6.getStats().setSkillLevel(Skills.TARGET_ANALYSIS, 2);
        person6.getStats().setSkillLevel(Skills.FIELD_MODULATION, 2);
        person6.getStats().setSkillLevel(Skills.IMPACT_MITIGATION, 2);
        person6.getStats().setSkillLevel(Skills.HELMSMANSHIP, 2);
        person6.getStats().setSkillLevel(Skills.DAMAGE_CONTROL, 2);
        person6.addTag("coff_nocapture");
        person6.getStats().setLevel(7);

        PersonAPI reckless1 = Global.getSector().getFaction("sindrian_diktat").createRandomPerson(FullName.Gender.ANY);
        reckless1.setId("sfc_reckless1");
        reckless1.setPostId(Ranks.POST_OFFICER);
        reckless1.setRankId(Ranks.POST_OFFICER);
        reckless1.setPersonality(Personalities.RECKLESS);
        reckless1.getStats().setSkillLevel(Skills.COMBAT_ENDURANCE, 2);
        reckless1.getStats().setSkillLevel(Skills.MISSILE_SPECIALIZATION, 2);
        reckless1.getStats().setSkillLevel(Skills.TARGET_ANALYSIS, 2);
        reckless1.getStats().setSkillLevel(Skills.FIELD_MODULATION, 2);
        reckless1.getStats().setSkillLevel(Skills.IMPACT_MITIGATION, 2);
        reckless1.getStats().setSkillLevel(Skills.HELMSMANSHIP, 2);
        reckless1.getStats().setSkillLevel(Skills.DAMAGE_CONTROL, 2);
        reckless1.addTag("coff_nocapture");
        reckless1.getStats().setLevel(7);

        PersonAPI reckless2 = Global.getSector().getFaction("sindrian_diktat").createRandomPerson(FullName.Gender.ANY);
        reckless2.setId("sfc_reckless2");
        reckless2.setPostId(Ranks.POST_OFFICER);
        reckless2.setRankId(Ranks.POST_OFFICER);
        reckless2.setPersonality(Personalities.RECKLESS);
        reckless2.getStats().setSkillLevel(Skills.COMBAT_ENDURANCE, 2);
        reckless2.getStats().setSkillLevel(Skills.MISSILE_SPECIALIZATION, 2);
        reckless2.getStats().setSkillLevel(Skills.TARGET_ANALYSIS, 2);
        reckless2.getStats().setSkillLevel(Skills.FIELD_MODULATION, 2);
        reckless2.getStats().setSkillLevel(Skills.IMPACT_MITIGATION, 2);
        reckless2.getStats().setSkillLevel(Skills.HELMSMANSHIP, 2);
        reckless2.getStats().setSkillLevel(Skills.DAMAGE_CONTROL, 2);
        reckless2.addTag("coff_nocapture");
        reckless2.getStats().setLevel(7);

        PersonAPI reckless3 = Global.getSector().getFaction("sindrian_diktat").createRandomPerson(FullName.Gender.ANY);
        reckless3.setId("sfc_reckless3");
        reckless3.setPostId(Ranks.POST_OFFICER);
        reckless3.setRankId(Ranks.POST_OFFICER);
        reckless3.setPersonality(Personalities.RECKLESS);
        reckless3.getStats().setSkillLevel(Skills.COMBAT_ENDURANCE, 2);
        reckless3.getStats().setSkillLevel(Skills.MISSILE_SPECIALIZATION, 2);
        reckless3.getStats().setSkillLevel(Skills.TARGET_ANALYSIS, 2);
        reckless3.getStats().setSkillLevel(Skills.FIELD_MODULATION, 2);
        reckless3.getStats().setSkillLevel(Skills.IMPACT_MITIGATION, 2);
        reckless3.getStats().setSkillLevel(Skills.HELMSMANSHIP, 2);
        reckless3.getStats().setSkillLevel(Skills.DAMAGE_CONTROL, 2);
        reckless3.addTag("coff_nocapture");
        reckless3.getStats().setLevel(7);


        FleetParamsV3 sfcParams = new FleetParamsV3(
                sfcvol.getMarket(), // add a source(has to be from a MarketAPI)
                null, // loc in hyper; don't need if have market
                "sindrian_diktat",
                2f, // quality override route.getQualityOverride()
                FleetTypes.PATROL_LARGE,
                1f, // combatPts(minimal so special ships can be added)(1000f otherwise)
                0f, // freighterPts
                0f, // tankerPts
                0f, // transportPts
                0f, // linerPts
                0f, // utilityPts
                0f// qualityMod
        );
        sfcParams.officerNumberMult = 2f;
        sfcParams.officerLevelBonus = 4;
        sfcParams.officerNumberBonus = 4;
        sfcParams.officerLevelLimit = 10; // Global.getSettings().getInt("officerMaxLevel") + (int) OfficerTraining.MAX_LEVEL_BONUS;
        sfcParams.modeOverride = FactionAPI.ShipPickMode.PRIORITY_THEN_ALL;
        sfcParams.averageSMods = 1;
        sfcParams.commander = Global.getSector().getImportantPeople().getPerson(sfcyenni);
        sfcParams.flagshipVariantId = "sfciapetus_Mixed";
        CampaignFleetAPI sfcFuelFleet = FleetFactoryV3.createFleet(sfcParams);
        if (sfcFuelFleet == null || sfcFuelFleet.isEmpty()) return;
        sfcFuelFleet.setFaction("sindrian_diktat", true);
        sfcFuelFleet.getFlagship().setShipName("SFS Fuel Eternal");
        sfcFuelFleet.getFlagship().setId("sfciapetus_Mixed");
        sfcFuelFleet.getFleetData().addFleetMember("sfcskyrend_Barrage").setCaptain(person1);
        sfcFuelFleet.getFleetData().addFleetMember("sfcskyrend_Beamer");
        sfcFuelFleet.getFleetData().addFleetMember("sfcprometheus_vanguard").setCaptain(person2);
        sfcFuelFleet.getFleetData().addFleetMember("sfcprometheus_barrage");
        sfcFuelFleet.getFleetData().addFleetMember("sfcmenoetius_Defense");
        sfcFuelFleet.getFleetData().addFleetMember("sfcepimetheus_Experimental").setCaptain(person3);
        sfcFuelFleet.getFleetData().addFleetMember("sfccrius_Blaster").setCaptain(person4);
        sfcFuelFleet.getFleetData().addFleetMember("sfccrius_Blaster");
        sfcFuelFleet.getFleetData().addFleetMember("sfccrius_Pressure");
        sfcFuelFleet.getFleetData().addFleetMember("sfccrius_Pressure");
        sfcFuelFleet.getFleetData().addFleetMember("sfcphaeton_bombard").setCaptain(person5);
        sfcFuelFleet.getFleetData().addFleetMember("sfcphaeton_bombard");
        sfcFuelFleet.getFleetData().addFleetMember("sfcphaeton_ballistics").setCaptain(person6);
        sfcFuelFleet.getFleetData().addFleetMember("sfcphaeton_ballistics");
        sfcFuelFleet.getFleetData().addFleetMember("sfcarke_Supporter");
        sfcFuelFleet.getFleetData().addFleetMember("sfcarke_Supporter");
        sfcFuelFleet.getFleetData().addFleetMember("sfcarke_Suppression");
        sfcFuelFleet.getFleetData().addFleetMember("sfcarke_Suppression");
        sfcFuelFleet.getFleetData().addFleetMember("sfcclepsydra_Standard");
        sfcFuelFleet.getFleetData().addFleetMember("sfcclepsydra_Standard");
        sfcFuelFleet.getFleetData().addFleetMember("sfcdram_assault");
        sfcFuelFleet.getFleetData().addFleetMember("sfcdram_missile");
        sfcFuelFleet.getFleetData().addFleetMember("sfclelantus_Barrage");
        sfcFuelFleet.getFleetData().addFleetMember("sfclelantus_Vanguard");
        sfcFuelFleet.getFleetData().addFleetMember("sfctahlanbento_Pulser");
        sfcFuelFleet.getFleetData().addFleetMember("sfcbia_Hunter");
        sfcFuelFleet.getFleetData().addFleetMember("sfcbia_Hunter");
        sfcFuelFleet.getFleetData().addFleetMember("sfctalaria_Beamer").setCaptain(reckless1);
        sfcFuelFleet.getFleetData().addFleetMember("sfctalaria_Strike").setCaptain(reckless2);
        sfcFuelFleet.getFleetData().addFleetMember("sfctalaria_Overdriven").setCaptain(reckless3);
        sfcFuelFleet.getFleetData().addFleetMember("sfcslent_Offense");
        sfcFuelFleet.getFleetData().addFleetMember("sfcslent_Offense");
        sfcFuelFleet.getFleetData().addFleetMember("sfcslent_Offense");
        sfcFuelFleet.getFleetData().addFleetMember("sfcslent_Offense");
        sfcFuelFleet.getFleetData().addFleetMember("sfcslent_Offense");
        sfcFuelFleet.getFleetData().addFleetMember("sfcpolus_Torpedo");
        sfcFuelFleet.getFleetData().addFleetMember("sfcpolus_Torpedo");
        sfcFuelFleet.getFleetData().addFleetMember("sfcpolus_Torpedo");
        sfcFuelFleet.getFleetData().addFleetMember("sfccoeus_Patrol");
        sfcFuelFleet.getFleetData().addFleetMember("sfccoeus_Patrol");
        sfcFuelFleet.setNoFactionInName(true);
        sfcFuelFleet.setName("The Grand Fuel Fleet");
        sfcvol.getContainingLocation().addEntity(sfcFuelFleet);
        sfcFuelFleet.setAI(Global.getFactory().createFleetAI(sfcFuelFleet));
        //fleet.setMarket(sfcvol.getMarket());
        sfcFuelFleet.setLocation(sfcvol.getLocation().x, sfcvol.getLocation().y);
        sfcFuelFleet.setFacing((float) Math.random() * 360f);
        sfcFuelFleet.getAI().addAssignment(FleetAssignment.DEFEND_LOCATION, sfcvol, (float) Math.random() * 90000f, null);
        sfcFuelFleet.getMemoryWithoutUpdate().set("$chatter_introSplash_name", sfcFuelFleet.getCommander().getNameString());

        //fleet after defeat
        FleetParamsV3 sfcParams2 = new FleetParamsV3(
                sfcvol.getMarket(), // add a source(has to be from a MarketAPI)
                null, // loc in hyper; don't need if have market
                "sindrian_diktat",
                2f, // quality override route.getQualityOverride()
                FleetTypes.PATROL_LARGE,
                300f, // combatPts(minimal so special ships can be added)(1000f otherwise)
                0f, // freighterPts
                0f, // tankerPts
                0f, // transportPts
                0f, // linerPts
                0f, // utilityPts
                0f// qualityMod
        );

        sfcParams2.officerNumberMult = 2f;
        sfcParams2.officerLevelBonus = 4;
        sfcParams2.officerNumberBonus = 4;
        sfcParams2.officerLevelLimit = 10; // Global.getSettings().getInt("officerMaxLevel") + (int) OfficerTraining.MAX_LEVEL_BONUS;
        sfcParams2.modeOverride = FactionAPI.ShipPickMode.PRIORITY_THEN_ALL;
        sfcParams2.averageSMods = 1;

        data.scripts.listeners.SFCGrandFuelFleetRespawnTracker.register(sfcFuelFleet, sfcParams, sfcParams2, "$sfcGFF_outta_gas");

    }

    private void addNFTMerchantMilitia() {
        SectorAPI sector = Global.getSector();
        StarSystemAPI system = sector.getStarSystem("Naraka");
        SectorEntityToken nachiketa = system.getEntityById("nachiketa");
        FleetParamsV3 nftParams = new FleetParamsV3(
                nachiketa.getMarket(), // add a source(has to be from a MarketAPI)
                null, // loc in hyper; don't need if have market
                "hegemony",
                1f, // quality override route.getQualityOverride()
                FleetTypes.TASK_FORCE,
                50f, // combatPts(minimal so special ships can be added)
                0f, // freighterPts
                0f, // tankerPts
                0f, // transportPts
                0f, // linerPts
                0f, // utilityPts
                0f// qualityMod
        );
        nftParams.officerNumberMult = 1f;
        nftParams.officerLevelBonus = 3;
        nftParams.officerNumberBonus = 3;
        nftParams.officerLevelLimit = Global.getSettings().getInt("officerMaxLevel") + (int) OfficerTraining.MAX_LEVEL_BONUS;
        nftParams.modeOverride = FactionAPI.ShipPickMode.ALL;
        nftParams.averageSMods = 1;
        nftParams.flagshipVariantId = "eagle_xiv_Elite";
        CampaignFleetAPI nftFleet = FleetFactoryV3.createFleet(nftParams);
        if (nftFleet == null || nftFleet.isEmpty()) return;
        nftFleet.setFaction("hegemony", true);
        nftFleet.getFlagship().setShipName("NMS Pyramid");
        nftFleet.getFlagship().setId("eagle_xiv_Elite");
        nftFleet.getFleetData().addFleetMember("condor_Support");
        nftFleet.getFleetData().addFleetMember("condor_Support");
        nftFleet.getFleetData().addFleetMember("hammerhead_Support");
        nftFleet.getFleetData().addFleetMember("hammerhead_Support");
        nftFleet.getFleetData().addFleetMember("hammerhead_Support");
        nftFleet.getFleetData().addFleetMember("enforcer_Balanced");
        nftFleet.getFleetData().addFleetMember("enforcer_Balanced");
        nftFleet.getFleetData().addFleetMember("enforcer_Balanced");
        nftFleet.getFleetData().addFleetMember("manticore_Support");
        nftFleet.getFleetData().addFleetMember("manticore_Support");
        nftFleet.getFleetData().addFleetMember("manticore_Support");
        nftFleet.getFleetData().addFleetMember("mule_Standard");
        nftFleet.getFleetData().addFleetMember("mule_Standard");
        nftFleet.getFleetData().addFleetMember("mule_Standard");
        nftFleet.getFleetData().addFleetMember("mule_Standard");
        nftFleet.getFleetData().addFleetMember("kite_hegemony_Interceptor");
        nftFleet.getFleetData().addFleetMember("kite_hegemony_Interceptor");
        nftFleet.getFleetData().addFleetMember("kite_hegemony_Interceptor");
        nftFleet.getFleetData().addFleetMember("kite_Support");
        nftFleet.getFleetData().addFleetMember("kite_Support");
        nftFleet.getFleetData().addFleetMember("kite_Support");
        nftFleet.setNoFactionInName(true);
        nftFleet.setName("NFT, Inc. Merchant Militia");
        nachiketa.getContainingLocation().addEntity(nftFleet);
        nftFleet.setAI(Global.getFactory().createFleetAI(nftFleet));
        nftFleet.setLocation(nachiketa.getLocation().x, nachiketa.getLocation().y);
        nftFleet.setFacing((float) Math.random() * 360f);
        nftFleet.getAI().addAssignment(FleetAssignment.DEFEND_LOCATION, nachiketa, (float) Math.random() * 90000f, null);

        data.scripts.listeners.SFCRespawningFleetTracker.register(nftFleet, nftParams);
    }

    private void PersonalFleetOxanaHyder(){

    }

    @Override
    public void onApplicationLoad() {
        Global.getSettings().getSkillSpec(Skills.ORDNANCE_EXPERTISE).setDescription(Global.getSettings().getString("sfc_pagsm", "sfc_ordnanceExpertiseText"));
        Global.getSettings().getSkillSpec(Skills.ORDNANCE_EXPERTISE).setAuthor(Global.getSettings().getString("sfc_pagsm", "sfc_ordnanceExpertiseAuthor"));
        //Global.getSettings().getSkillSpec(Skills.ORDNANCE_EXPERTISE).setDescription("There's more to antimatter fuel than simply just fueling starships. Why, with just a bit of ingenuity, you'll find there's plenty of things which can benefit from a bit of antimatter reactions.");
        //Global.getSettings().getSkillSpec(Skills.ORDNANCE_EXPERTISE).setAuthor("Chapter 15 of The Sindrian Fuel Company: From Dreams to Reality");
        Global.getSettings().getIndustrySpec("lionsguard").setDesc(Global.getSettings().getString("sfc_pagsm", "sfc_lionsguardHQ"));
        //Global.getSettings().getIndustrySpec("lionsguard").setDesc("Headquarters of the elite paramilitary branch of the Sindrian Fuel Company, under the direct control of Supreme Overlord Executive Gas Station Manager Phillip Andrada. The Lion's Guard consists of the most devoted employees, who receive top quality training and equipment to protect Sindrian Fuel assets and ensure the continued competitiveness of Sindrian Antimatter Fuel throughout the sector. Many question why a company like Sindrian Fuel would require such a heavily armed paramilitary unit when most duties are handled by regular security forces, but these questions usually are silenced by reminders of how dangerous the Persean Sector is and a note that the Lion's Guard is solely used for private defense purposes only. Any rumors of Lion's Guard operations to destabilize other markets to make way for a Sindrian Fuel franchise are completely unsubstantiated, and clearly they come from jealous rivals intending to tarnish the company's pristine public image. And for Ludd's sake, don't ask why the Guard's named for a Lion.");
        if (Global.getSettings().getIndustrySpec("DE_Unpropaganda") != null) {
            Global.getSettings().getIndustrySpec("DE_Unpropaganda").setDesc(Global.getSettings().getString("sfc_pagsm", "sfc_deUnpropagandaText"));
            Global.getSettings().getIndustrySpec("DE_Unpropaganda").setName(Global.getSettings().getString("sfc_pagsm", "sfc_deUnpropagandaTitle"));
            //Global.getSettings().getIndustrySpec("DE_Unpropaganda").setDesc("A hub for the planet wide advertisement of alternative fuel brands, aimed at slowly weaning off the local populace's deep-rooted reliance on Sindrian Brand antimatter fuel.");
            //Global.getSettings().getIndustrySpec("DE_Unpropaganda").setName("Alternative Brand Advertisers");
        }
        if (Global.getSettings().getIndustrySpec("sindrianfuel") != null) {
            Global.getSettings().getIndustrySpec("sindrianfuel").setDesc(Global.getSettings().getString("sfc_pagsm", "sfc_sindrianfuelText"));
        }
        /*(if (Global.getSettings().getMarketConditionSpec("") != null) {

        }*/
    }


    @Override
    public void onNewGameAfterEconomyLoad() {
        MarketAPI volturn = Global.getSector().getEconomy().getMarket("volturn");
        if (volturn != null) {
            addGrandFuelFleet();
            MarketAPI nachiketa = Global.getSector().getEconomy().getMarket("nachiketa");
            if (nachiketa != null) {
                addNFTMerchantMilitia();
            }
            ImportantPeopleAPI ip = Global.getSector().getImportantPeople();
            SectorAPI sector = Global.getSector();
            StarSystemAPI system = sector.getStarSystem("Askonia");
            MarketAPI market1 = Global.getSector().getEconomy().getMarket("sindria");


            if (market1 != null) {

                SectorEntityToken cnc = Global.getSector().getEntityById("diktat_cnc");
                cnc.setCustomDescriptionId("station_sindria_sindrian_fuel");

                // unrelenting genius
                PersonAPI sfckweenPerson = Global.getFactory().createPerson();
                sfckweenPerson.setId(sfckween);
                sfckweenPerson.setFaction(Factions.DIKTAT);
                sfckweenPerson.setGender(Gender.FEMALE);
                sfckweenPerson.setRankId(Ranks.SPACE_ADMIRAL);
                sfckweenPerson.setPostId("sfcheadresearcher");
                sfckweenPerson.setImportance(PersonImportance.HIGH);
                sfckweenPerson.setVoice(Voices.SCIENTIST);
                sfckweenPerson.getName().setFirst("Yunris");
                sfckweenPerson.getName().setLast("Kween");
                sfckweenPerson.setPortraitSprite(Global.getSettings().getSpriteName("characters", "sfckween"));
                sfckweenPerson.addTag(Tags.CONTACT_UNDERWORLD);
                market1.getCommDirectory().addPerson(sfckweenPerson, 2);
                market1.addPerson(sfckweenPerson);
                ip.addPerson(sfckweenPerson);

                // lobster t-shirt
                PersonAPI sfcmannPerson = Global.getFactory().createPerson();
                sfcmannPerson.setId(sfcmann);
                sfcmannPerson.setFaction(Factions.DIKTAT);
                sfcmannPerson.setGender(Gender.MALE);
                sfcmannPerson.setRankId(Ranks.SPACE_ADMIRAL);
                sfcmannPerson.setPostId("sfcleaddeveloper");
                sfcmannPerson.setImportance(PersonImportance.HIGH);
                sfcmannPerson.setVoice(Voices.SCIENTIST);
                sfcmannPerson.getName().setFirst("Gregory");
                sfcmannPerson.getName().setLast("Mannfred");
                sfcmannPerson.setPortraitSprite(Global.getSettings().getSpriteName("characters", "sfcmann"));
                sfcmannPerson.addTag(Tags.CONTACT_TRADE);
                market1.getCommDirectory().addPerson(sfcmannPerson, 3);
                market1.addPerson(sfcmannPerson);
                ip.addPerson(sfcmannPerson);

                // a regular Yunifer
                PersonAPI sfcruniPerson = Global.getFactory().createPerson();
                sfcruniPerson.setId(sfcruni);
                sfcruniPerson.setFaction(Factions.DIKTAT);
                sfcruniPerson.setGender(Gender.FEMALE);
                sfcruniPerson.setRankId(Ranks.SPACE_CAPTAIN);
                sfcruniPerson.setPostId(Ranks.POST_OFFICER);
                sfcruniPerson.setPersonality(Personalities.TIMID);
                sfcruniPerson.setImportance(PersonImportance.VERY_LOW);
                sfcruniPerson.setVoice(Voices.SOLDIER);
                sfcruniPerson.getName().setFirst("Yunifer");
                sfcruniPerson.getName().setLast("Runi");
                sfcruniPerson.setPortraitSprite(Global.getSettings().getSpriteName("characters", "sfcruni"));
                sfcruniPerson.getStats().setSkillLevel("sfc_iapetus", 2);
                sfcruniPerson.getStats().setSkillLevel(Skills.POINT_DEFENSE, 2);
                sfcruniPerson.getStats().setSkillLevel(Skills.DAMAGE_CONTROL, 2);
                sfcruniPerson.getStats().setSkillLevel(Skills.COMBAT_ENDURANCE, 2);
                sfcruniPerson.getStats().setSkillLevel(Skills.MISSILE_SPECIALIZATION, 2);
                sfcruniPerson.getStats().setSkillLevel(Skills.POLARIZED_ARMOR, 2);
                sfcruniPerson.getStats().setSkillLevel(Skills.SYSTEMS_EXPERTISE, 1);
                sfcruniPerson.getStats().setSkillLevel(Skills.IMPACT_MITIGATION, 1);
                sfcruniPerson.getStats().setSkillLevel(Skills.ENERGY_WEAPON_MASTERY, 1);
                sfcruniPerson.getStats().setSkillLevel(Skills.ORDNANCE_EXPERTISE, 1);
                sfcruniPerson.getStats().setLevel(10);
                sfcruniPerson.getMemoryWithoutUpdate().set("$chatterChar", "sfcruni");
                sfcruniPerson.getMemoryWithoutUpdate().set("$nex_noOfficerDeath", true);
                sfcruniPerson.addTag("coff_nocapture");

                market1.getCommDirectory().addPerson(sfcruniPerson);
                market1.addPerson(sfcruniPerson);
                market1.getCommDirectory().getEntryForPerson(sfcruniPerson).setHidden(true);
                ip.addPerson(sfcruniPerson);


                //a mistake was made
                PersonAPI sfcruni2Person = Global.getFactory().createPerson();
                sfcruni2Person.setId(sfcruni2);
                sfcruni2Person.setFaction(Factions.DIKTAT);
                sfcruni2Person.setGender(Gender.FEMALE);
                sfcruni2Person.setRankId(Ranks.SPACE_CAPTAIN);
                sfcruni2Person.setPostId(Ranks.POST_OFFICER);
                sfcruni2Person.setPersonality(Personalities.STEADY);
                sfcruni2Person.setImportance(PersonImportance.VERY_LOW);
                sfcruni2Person.setVoice(Voices.SOLDIER);
                sfcruni2Person.getName().setFirst("Yunifer");
                sfcruni2Person.getName().setLast("Runi");
                sfcruni2Person.setPortraitSprite(Global.getSettings().getSpriteName("characters", "sfcruni2"));
                sfcruni2Person.getStats().setLevel(1);
                sfcruni2Person.getStats().setSkillLevel(Skills.GUNNERY_IMPLANTS, 1);
                sfcruni2Person.getMemoryWithoutUpdate().set("$chatterChar", "sfcthisofficer");
                sfcruni2Person.getMemoryWithoutUpdate().set("$nex_noOfficerDeath", true);

                market1.getCommDirectory().addPerson(sfcruni2Person);
                market1.addPerson(sfcruni2Person);
                market1.getCommDirectory().getEntryForPerson(sfcruni2Person).setHidden(true);
                ip.addPerson(sfcruni2Person);

                // magic eight ball
                PersonAPI sfcfakeandradaPerson = Global.getFactory().createPerson();
                sfcfakeandradaPerson.setId(sfcfakeandrada);
                sfcfakeandradaPerson.setFaction(Factions.NEUTRAL);
                sfcfakeandradaPerson.setGender(Gender.MALE);
                sfcfakeandradaPerson.setRankId("Hologram");
                sfcfakeandradaPerson.setPostId("Hologram");
                sfcfakeandradaPerson.getName().setFirst("Phillip");
                sfcfakeandradaPerson.getName().setLast("Andrada");
                sfcfakeandradaPerson.setPortraitSprite(Global.getSettings().getSpriteName("characters", "sfcfakeandrada"));
                ip.addPerson(sfcfakeandradaPerson);

                // what kind of name is fuel frontal?
                PersonAPI sfcheroPerson = Global.getFactory().createPerson();
                sfcheroPerson.setId(sfchero);
                sfcheroPerson.setFaction(Factions.DIKTAT);
                sfcheroPerson.setGender(Gender.MALE);
                sfcheroPerson.setRankId(Ranks.SPACE_CAPTAIN);
                sfcheroPerson.setPostId(Ranks.POST_OFFICER);
                sfcheroPerson.setImportance(PersonImportance.VERY_HIGH);
                sfcheroPerson.setVoice(Voices.SOLDIER);
                sfcheroPerson.getName().setFirst("Fuel");
                sfcheroPerson.getName().setLast("Frontal");
                sfcheroPerson.setPortraitSprite(Global.getSettings().getSpriteName("characters", "sfchero"));
                ip.addPerson(sfcheroPerson);

                // short
                PersonAPI sfcrheaPerson = Global.getFactory().createPerson();
                sfcrheaPerson.setId(sfcrhea);
                sfcrheaPerson.setFaction(Factions.DIKTAT);
                sfcrheaPerson.setGender(Gender.FEMALE);
                sfcrheaPerson.setRankId(Ranks.SPACE_LIEUTENANT);
                sfcrheaPerson.setPostId(Ranks.POST_AGENT);
                sfcrheaPerson.setImportance(PersonImportance.MEDIUM);
                sfcrheaPerson.setVoice(Voices.SOLDIER);
                sfcrheaPerson.getName().setFirst("Sindy");
                sfcrheaPerson.getName().setLast("Rhea");
                sfcrheaPerson.setPortraitSprite(Global.getSettings().getSpriteName("characters", "sfcrhea"));
                ip.addPerson(sfcrheaPerson);
            }


            market1 = Global.getSector().getEconomy().getMarket("cruor");
            if (market1 != null) {

                market1.addSubmarket("sfc_bsamarket");

                SectorEntityToken cruor = system.getEntityById("cruor");
                cruor.getMarket().addIndustry(Industries.PATROLHQ);
                cruor.getMarket().addIndustry("sfclionsoutpost");

                // gets it dunn
                PersonAPI sfcdunnPerson = Global.getFactory().createPerson();
                sfcdunnPerson.setId(sfcdunn);
                sfcdunnPerson.setFaction(Factions.DIKTAT);
                sfcdunnPerson.setGender(Gender.MALE);
                sfcdunnPerson.setRankId(Ranks.SPACE_ADMIRAL);
                sfcdunnPerson.setPostId("sfclaborchief");
                sfcdunnPerson.setImportance(PersonImportance.HIGH);
                sfcdunnPerson.getName().setFirst("Meridin");
                sfcdunnPerson.getName().setLast("Dunn");
                sfcdunnPerson.setPortraitSprite(Global.getSettings().getSpriteName("characters", "sfcdunn"));
                sfcdunnPerson.addTag(Tags.CONTACT_TRADE);
                sfcdunnPerson.setVoice(Voices.SPACER);
                sfcdunnPerson.getStats().setSkillLevel("sfc_hardwork", 1);
                sfcdunnPerson.getStats().setSkillLevel("sfc_gilded", 1);
                market1.setAdmin(sfcdunnPerson);
                market1.getCommDirectory().addPerson(sfcdunnPerson, 0);
                market1.addPerson(sfcdunnPerson);
                ip.addPerson(sfcdunnPerson);

                // hates the Lion's Guard, and his job
                PersonAPI sfcruyPerson = Global.getFactory().createPerson();
                sfcruyPerson.setId(sfcruy);
                sfcruyPerson.setFaction(Factions.DIKTAT);
                sfcruyPerson.setGender(Gender.MALE);
                sfcruyPerson.setRankId(Ranks.SPACE_ADMIRAL);
                sfcruyPerson.setPostId("sfcsecchief");
                sfcruyPerson.setImportance(PersonImportance.MEDIUM);
                sfcruyPerson.getName().setFirst("Rudric");
                sfcruyPerson.getName().setLast("Ruy");
                sfcruyPerson.setPortraitSprite(Global.getSettings().getSpriteName("characters", "sfcruy"));
                sfcruyPerson.addTag(Tags.CONTACT_MILITARY);
                sfcruyPerson.setVoice(Voices.SOLDIER);
                market1.getCommDirectory().addPerson(sfcruyPerson, 1);
                market1.addPerson(sfcruyPerson);
                ip.addPerson(sfcruyPerson);

                // CSP reference
                PersonAPI cspmongaeraPerson = Global.getFactory().createPerson();
                cspmongaeraPerson.setId(cspmongaera);
                cspmongaeraPerson.setFaction(Factions.LIONS_GUARD);
                cspmongaeraPerson.setGender(Gender.FEMALE);
                cspmongaeraPerson.setRankId("sfcregmanager");
                cspmongaeraPerson.setPostId("sfcregmanager");
                cspmongaeraPerson.setImportance(PersonImportance.VERY_HIGH);
                cspmongaeraPerson.getName().setFirst("Cayista");
                cspmongaeraPerson.getName().setLast("Mongaera");
                cspmongaeraPerson.setPortraitSprite(Global.getSettings().getSpriteName("characters", "cspmongaera"));
                cspmongaeraPerson.addTag(Tags.CONTACT_MILITARY);
                cspmongaeraPerson.setVoice(Voices.SOLDIER);
                market1.getCommDirectory().addPerson(cspmongaeraPerson, 0);
                market1.addPerson(cspmongaeraPerson);
                market1.getCommDirectory().getEntryForPerson(cspmongaeraPerson).setHidden(true);
                ip.addPerson(cspmongaeraPerson);

                PersonAPI tell = Global.getSector().getImportantPeople().getPerson("tell");
                if (tell != null) {
                    tell.setImportance(PersonImportance.HIGH);
                    tell.setPostId("militaryAdministrator");
                    tell.setPortraitSprite(Global.getSettings().getSpriteName("characters", "sfc_tell"));
                    market1.getCommDirectory().addPerson(tell, 0);
                    market1.addPerson(tell);
                }
            }

            market1 = Global.getSector().getEconomy().getMarket("volturn");
            if (market1 != null) {

                SectorEntityToken volturncolony = system.getEntityById("volturn");
                volturncolony.getMarket().getIndustry(Industries.AQUACULTURE).setSpecialItem(new SpecialItemData("sfc_aquaticstimulator", null));
                volturncolony.getMarket().addIndustry("sfclobsterresort");

                // sunny flower
                PersonAPI sfcfleuresPerson = Global.getFactory().createPerson();
                sfcfleuresPerson.setId(sfcfleures);
                sfcfleuresPerson.setFaction(Factions.DIKTAT);
                sfcfleuresPerson.setGender(Gender.FEMALE);
                sfcfleuresPerson.setRankId(Ranks.SPACE_ADMIRAL);
                sfcfleuresPerson.setPostId("sfcadvertchief");
                sfcfleuresPerson.setImportance(PersonImportance.HIGH);
                sfcfleuresPerson.getName().setFirst("Lumi");
                sfcfleuresPerson.getName().setLast("Fleures");
                sfcfleuresPerson.setPortraitSprite(Global.getSettings().getSpriteName("characters", "sfcfleures"));
                sfcfleuresPerson.addTag(Tags.CONTACT_TRADE);
                sfcfleuresPerson.setVoice(Voices.OFFICIAL);
                sfcfleuresPerson.getStats().setSkillLevel("sfc_hardwork", 1);
                market1.setAdmin(sfcfleuresPerson);
                market1.getCommDirectory().addPerson(sfcfleuresPerson, 0);
                market1.addPerson(sfcfleuresPerson);
                ip.addPerson(sfcfleuresPerson);

                // needs coffee
                PersonAPI sfcjenkinsPerson = Global.getFactory().createPerson();
                sfcjenkinsPerson.setId(sfcjenkins);
                sfcjenkinsPerson.setFaction(Factions.DIKTAT);
                sfcjenkinsPerson.setGender(Gender.FEMALE);
                sfcjenkinsPerson.setRankId(Ranks.SPACE_ADMIRAL);
                sfcjenkinsPerson.setPostId("sfcproductionchief");
                sfcjenkinsPerson.setImportance(PersonImportance.HIGH);
                sfcjenkinsPerson.getName().setFirst("Velmarie");
                sfcjenkinsPerson.getName().setLast("Jenkins");
                sfcjenkinsPerson.setPortraitSprite(Global.getSettings().getSpriteName("characters", "sfcjenkins"));
                sfcjenkinsPerson.addTag(Tags.CONTACT_TRADE);
                sfcjenkinsPerson.setVoice(Voices.OFFICIAL);
                market1.getCommDirectory().addPerson(sfcjenkinsPerson, 1);
                market1.addPerson(sfcjenkinsPerson);
                ip.addPerson(sfcjenkinsPerson);

                // lober
                PersonAPI sfcvolturnyLobster = Global.getFactory().createPerson();
                sfcvolturnyLobster.setId(sfcvolturny);
                sfcvolturnyLobster.setFaction(Factions.DIKTAT);
                sfcvolturnyLobster.setGender(Gender.MALE);
                sfcvolturnyLobster.setRankId(Ranks.CITIZEN);
                sfcvolturnyLobster.setPostId(Ranks.POST_UNKNOWN);
                sfcvolturnyLobster.setImportance(PersonImportance.VERY_HIGH);
                sfcvolturnyLobster.getName().setFirst("Volturny");
                sfcvolturnyLobster.getName().setLast("");
                sfcvolturnyLobster.setPortraitSprite(Global.getSettings().getSpriteName("characters", "sfcvolturny"));


                market1.getCommDirectory().addPerson(sfcvolturnyLobster);
                market1.getCommDirectory().getEntryForPerson(sfcvolturnyLobster).setHidden(true);
                market1.addPerson(sfcvolturnyLobster);
                ip.addPerson(sfcvolturnyLobster);

                // hey fonzi
                PersonAPI sfcfonzPerson = Global.getFactory().createPerson();
                sfcfonzPerson.setId(sfcfonz);
                sfcfonzPerson.setFaction(Factions.LIONS_GUARD);
                sfcfonzPerson.setGender(Gender.MALE);
                sfcfonzPerson.setRankId("sfcregmanager");
                sfcfonzPerson.setPostId("sfcregmanager");
                sfcfonzPerson.setImportance(PersonImportance.VERY_HIGH);
                sfcfonzPerson.getName().setFirst("Albert");
                sfcfonzPerson.getName().setLast("Fonziphone");
                sfcfonzPerson.setPortraitSprite(Global.getSettings().getSpriteName("characters", "sfcfonz"));
                sfcfonzPerson.addTag(Tags.CONTACT_MILITARY);
                sfcfonzPerson.setVoice(Voices.SOLDIER);
                market1.getCommDirectory().addPerson(sfcfonzPerson, 0);
                market1.addPerson(sfcfonzPerson);
                market1.getCommDirectory().getEntryForPerson(sfcfonzPerson).setHidden(true);
                ip.addPerson(sfcfonzPerson);
            }
            //the nft starts here
            market1 = Global.getSector().getEconomy().getMarket("nachiketa");
            if (market1 != null) {
                PersonAPI nftpononziPerson = Global.getFactory().createPerson();
                nftpononziPerson.setId(nftpononzi);
                nftpononziPerson.setFaction(Factions.HEGEMONY);
                nftpononziPerson.setGender(Gender.MALE);
                nftpononziPerson.setRankId("nftexecutive");
                nftpononziPerson.setPostId("nftexecutive");
                nftpononziPerson.setImportance(PersonImportance.VERY_HIGH);
                nftpononziPerson.getName().setFirst("Karlos");
                nftpononziPerson.getName().setLast("Pononzi");
                nftpononziPerson.setPortraitSprite(Global.getSettings().getSpriteName("characters", "nftpononzi"));
                nftpononziPerson.addTag(Tags.CONTACT_TRADE);
                nftpononziPerson.setVoice(Voices.BUSINESS);
                market1.getCommDirectory().addPerson(nftpononziPerson, 1);
                market1.addPerson(nftpononziPerson);
                ip.addPerson(nftpononziPerson);
            }

            market1 = Global.getSector().getEconomy().getMarket("nortia");
            if (market1 != null) {
                PersonAPI nftgimletPerson = Global.getFactory().createPerson();
                nftgimletPerson.setId(nftgimlet);
                nftgimletPerson.setFaction(Factions.HEGEMONY);
                nftgimletPerson.setGender(Gender.MALE);
                nftgimletPerson.setRankId(Ranks.GROUND_GENERAL);
                nftgimletPerson.setPostId(Ranks.POST_SUPPLY_OFFICER);
                nftgimletPerson.setImportance(PersonImportance.HIGH);
                nftgimletPerson.getName().setFirst("Darington");
                nftgimletPerson.getName().setLast("Gimlet");
                nftgimletPerson.setPortraitSprite(Global.getSettings().getSpriteName("characters", "nftgimlet"));
                nftgimletPerson.addTag(Tags.CONTACT_MILITARY);
                nftgimletPerson.setVoice(Voices.SOLDIER);
                market1.getCommDirectory().addPerson(nftgimletPerson, 1);
                market1.addPerson(nftgimletPerson);
                ip.addPerson(nftgimletPerson);
            }

            market1 = Global.getSector().getEconomy().getMarket("umbra");
            if (market1 != null) {

                SectorEntityToken umbra = system.getEntityById("umbra");
                umbra.getMarket().getIndustry(Industries.MINING).setSpecialItem(new SpecialItemData("sfc_motemegacondenser", null));
            }

            market1 =  Global.getSector().getEconomy().getMarket("epiphany");
            if (market1 != null) {
                PersonAPI person = Global.getFactory().createPerson();
                person.setId(sfcarthur);
                person.setFaction(Factions.LUDDIC_PATH);
                person.setGender(Gender.MALE);
                person.setRankId(Ranks.BROTHER);
                person.setPostId(Ranks.POST_TERRORIST);
                person.setPersonality(Personalities.RECKLESS);
                person.setImportance(PersonImportance.HIGH);
                person.getName().setFirst("Beligar");
                person.getName().setLast("Arthur");
                person.setPortraitSprite(Global.getSettings().getSpriteName("characters", "sfcarthur"));
                person.getStats().setLevel(8);
                person.getStats().setSkillLevel("sfc_luddskill", 2);
                person.getStats().setSkillLevel(Skills.COMBAT_ENDURANCE, 2);
                person.getStats().setSkillLevel(Skills.MISSILE_SPECIALIZATION, 2);
                person.getStats().setSkillLevel(Skills.FIELD_MODULATION, 2);
                person.getStats().setSkillLevel(Skills.IMPACT_MITIGATION, 2);
                person.getStats().setSkillLevel(Skills.POLARIZED_ARMOR, 2);
                person.getStats().setSkillLevel(Skills.DAMAGE_CONTROL, 1);
                person.getStats().setSkillLevel(Skills.TARGET_ANALYSIS, 1);
                person.getStats().setSkillLevel(Skills.CREW_TRAINING, 1);
                person.getStats().setSkillLevel(Skills.TACTICAL_DRILLS, 1);
                person.addTag("coff_forcecapture");
                person.addTag("coff_prisonerdialog");
                person.getMemoryWithoutUpdate().set("$coff_allowedactions", "talk");
                person.getMemoryWithoutUpdate().set("$coff_dialogtrigger", "sfcarthur");
                person.getMemoryWithoutUpdate().set("$nex_noOfficerDeath", true);
                person.getMemoryWithoutUpdate().set("$chatterChar", "sfcarthur");

                market1.getCommDirectory().addPerson(person);
                market1.getCommDirectory().getEntryForPerson(person).setHidden(true);
                market1.addPerson(person);
                ip.addPerson(person);
            }


            PersonAPI sec_officer = Global.getSector().getImportantPeople().getPerson("sec_officer");
            if (sec_officer != null) {
                sec_officer.setRankId("sfcjunior");
                sec_officer.setPostId("sfcjunior");
                sec_officer.setPortraitSprite(Global.getSettings().getSpriteName("characters", "sfcbalashi"));
                sec_officer.addTag(Tags.CONTACT_MILITARY);
            }

            PersonAPI andrada = Global.getSector().getImportantPeople().getPerson("andrada");
            if (andrada != null) {
                andrada.setImportance(PersonImportance.VERY_HIGH);
                andrada.setPortraitSprite(Global.getSettings().getSpriteName("characters", "sfcandrada"));
                andrada.getStats().setSkillLevel("sfc_hardwork", 1);
            }

            PersonAPI caden = Global.getSector().getImportantPeople().getPerson("caden");
            if (caden != null) {
                caden.setImportance(PersonImportance.VERY_HIGH);
                caden.setPortraitSprite(Global.getSettings().getSpriteName("characters", "sfc_caden"));
                caden.getStats().setLevel(15);
                caden.getStats().setSkillLevel(Skills.ENERGY_WEAPON_MASTERY, 2);
                caden.getStats().setSkillLevel(Skills.COMBAT_ENDURANCE, 2);
                caden.getStats().setSkillLevel(Skills.MISSILE_SPECIALIZATION, 2);
                caden.getStats().setSkillLevel(Skills.FIELD_MODULATION, 2);
                caden.getStats().setSkillLevel(Skills.IMPACT_MITIGATION, 2);
                caden.getStats().setSkillLevel(Skills.POLARIZED_ARMOR, 2);
                caden.getStats().setSkillLevel(Skills.ORDNANCE_EXPERTISE, 1);
                caden.getStats().setSkillLevel(Skills.HELMSMANSHIP, 1);
                caden.getStats().setSkillLevel(Skills.DAMAGE_CONTROL, 1);
                caden.getStats().setSkillLevel(Skills.TARGET_ANALYSIS, 1);
                caden.getStats().setSkillLevel(Skills.COORDINATED_MANEUVERS, 1);
                caden.getStats().setSkillLevel(Skills.CREW_TRAINING, 1);
                caden.getStats().setSkillLevel(Skills.OFFICER_TRAINING, 1);
                caden.getStats().setSkillLevel(Skills.SUPPORT_DOCTRINE, 1);
                caden.getStats().setSkillLevel(Skills.TACTICAL_DRILLS, 1);
                caden.getStats().setSkillLevel(Skills.OFFICER_MANAGEMENT, 1);
                caden.addTag("coff_nocapture");
            }

            PersonAPI hyder = Global.getSector().getImportantPeople().getPerson("hyder");
            if (hyder != null) {
                hyder.setImportance(PersonImportance.HIGH);
                hyder.setPortraitSprite(Global.getSettings().getSpriteName("characters", "sfc_hyder"));
                hyder.getStats().setLevel(15);
                hyder.getStats().setSkillLevel(Skills.ENERGY_WEAPON_MASTERY, 2);
                hyder.getStats().setSkillLevel(Skills.COMBAT_ENDURANCE, 2);
                hyder.getStats().setSkillLevel(Skills.MISSILE_SPECIALIZATION, 2);
                hyder.getStats().setSkillLevel(Skills.FIELD_MODULATION, 2);
                hyder.getStats().setSkillLevel(Skills.IMPACT_MITIGATION, 2);
                hyder.getStats().setSkillLevel(Skills.POLARIZED_ARMOR, 2);
                hyder.getStats().setSkillLevel(Skills.ORDNANCE_EXPERTISE, 1);
                hyder.getStats().setSkillLevel(Skills.HELMSMANSHIP, 1);
                hyder.getStats().setSkillLevel(Skills.DAMAGE_CONTROL, 1);
                hyder.getStats().setSkillLevel(Skills.TARGET_ANALYSIS, 1);
                hyder.getStats().setSkillLevel(Skills.COORDINATED_MANEUVERS, 1);
                hyder.getStats().setSkillLevel(Skills.CREW_TRAINING, 1);
                hyder.getStats().setSkillLevel(Skills.OFFICER_TRAINING, 1);
                hyder.getStats().setSkillLevel(Skills.SUPPORT_DOCTRINE, 1);
                hyder.getStats().setSkillLevel(Skills.TACTICAL_DRILLS, 1);
                hyder.getStats().setSkillLevel(Skills.OFFICER_MANAGEMENT, 1);
                hyder.addTag("coff_nocapture");
            }
            PersonAPI macario = Global.getSector().getImportantPeople().getPerson("macario");
            if (macario != null) {
                macario.setImportance(PersonImportance.VERY_HIGH);
                macario.setPortraitSprite(Global.getSettings().getSpriteName("characters", "sfc_macario"));
            }

            PersonAPI ram = Global.getSector().getImportantPeople().getPerson("ram");
            if (ram != null) {
                ram.setImportance(PersonImportance.LOW);
                ram.setPostId("sfccompliance");
                ram.setPortraitSprite(Global.getSettings().getSpriteName("characters", "sfc_ram"));
            }

            // DE reference

            if (!isDE) {
                MarketAPI sindriade = null;
                sindriade = Global.getSector().getEconomy().getMarket("sindria");
                if (sindriade != null) {
                    PersonAPI dejalectoPerson = Global.getFactory().createPerson();
                    dejalectoPerson.setId(dejalecto);
                    dejalectoPerson.setFaction(Factions.LIONS_GUARD);
                    dejalectoPerson.setGender(Gender.MALE);
                    dejalectoPerson.setRankId("sfcexecutive");
                    dejalectoPerson.setPostId("sfcexecutive");
                    dejalectoPerson.setImportance(PersonImportance.VERY_HIGH);
                    dejalectoPerson.getName().setFirst("Randall");
                    dejalectoPerson.getName().setLast("Jalecto");
                    dejalectoPerson.setPortraitSprite(Global.getSettings().getSpriteName("characters", "dejalecto"));
                    sindriade.getCommDirectory().addPerson(dejalectoPerson, 1);
                    sindriade.addPerson(dejalectoPerson);
                    sindriade.getCommDirectory().getEntryForPerson(dejalectoPerson).setHidden(true);
                    ip.addPerson(dejalectoPerson);
                }
            }
            if (isDE) {
                boolean DEenablelitemode = Global.getSettings().getBoolean("DEenablelitemode");
                boolean DEenablefortressmode = Global.getSettings().getBoolean("DEenablefortressmode");
                MarketAPI market1de = null;
                MarketAPI market2de = null;
                if (!DEenablelitemode) {
                    if (!DEenablefortressmode) {
                        //market1de = Global.getSector().getEconomy().getMarket("ryzan_supercomplex");
                        market1de = Global.getSector().getStarSystem("Andor").getEntityById("ryzan_supercomplex").getMarket();
                        if (market1de != null) {
                            PersonAPI dejalectoPerson = Global.getFactory().createPerson();
                            dejalectoPerson.setId(dejalecto);
                            dejalectoPerson.setFaction(Factions.LIONS_GUARD);
                            dejalectoPerson.setGender(Gender.MALE);
                            dejalectoPerson.setRankId("sfcexecutive");
                            dejalectoPerson.setPostId("sfcregmanager");
                            dejalectoPerson.setImportance(PersonImportance.VERY_HIGH);
                            dejalectoPerson.getName().setFirst("Randall");
                            dejalectoPerson.getName().setLast("Jalecto");
                            dejalectoPerson.setPortraitSprite(Global.getSettings().getSpriteName("characters", "dejalecto"));
                            dejalectoPerson.getStats().setSkillLevel(Skills.INDUSTRIAL_PLANNING, 1);
                            dejalectoPerson.getStats().setSkillLevel(Skills.TACTICAL_DRILLS, 1);
                            market1de.setAdmin(dejalectoPerson);
                            market1de.getCommDirectory().addPerson(dejalectoPerson, 0);
                            market1de.addPerson(dejalectoPerson);
                            ip.addPerson(dejalectoPerson);
                        }
                    } else {
                        market2de = Global.getSector().getEconomy().getMarket("sindria");
                        if (market2de != null) {
                            PersonAPI dejalectoPerson = Global.getFactory().createPerson();
                            dejalectoPerson.setId(dejalecto);
                            dejalectoPerson.setFaction(Factions.LIONS_GUARD);
                            dejalectoPerson.setGender(Gender.MALE);
                            dejalectoPerson.setRankId("sfcexecutive");
                            dejalectoPerson.setPostId("sfcexecutive");
                            dejalectoPerson.setImportance(PersonImportance.VERY_HIGH);
                            dejalectoPerson.getName().setFirst("Randall");
                            dejalectoPerson.getName().setLast("Jalecto");
                            dejalectoPerson.setPortraitSprite(Global.getSettings().getSpriteName("characters", "dejalecto"));
                            market2de.getCommDirectory().addPerson(dejalectoPerson, 1);
                            market2de.addPerson(dejalectoPerson);
                            market2de.getCommDirectory().getEntryForPerson(dejalectoPerson).setHidden(true);
                            ip.addPerson(dejalectoPerson);
                        }
                    }
                } else {
                    market2de = Global.getSector().getEconomy().getMarket("sindria");
                    if (market2de != null) {
                        PersonAPI dejalectoPerson = Global.getFactory().createPerson();
                        dejalectoPerson.setId(dejalecto);
                        dejalectoPerson.setFaction(Factions.LIONS_GUARD);
                        dejalectoPerson.setGender(Gender.MALE);
                        dejalectoPerson.setRankId("sfcexecutive");
                        dejalectoPerson.setPostId("sfcexecutive");
                        dejalectoPerson.setImportance(PersonImportance.VERY_HIGH);
                        dejalectoPerson.getName().setFirst("Randall");
                        dejalectoPerson.getName().setLast("Jalecto");
                        dejalectoPerson.setPortraitSprite(Global.getSettings().getSpriteName("characters", "dejalecto"));
                        market2de.getCommDirectory().addPerson(dejalectoPerson, 1);
                        market2de.addPerson(dejalectoPerson);
                        market2de.getCommDirectory().getEntryForPerson(dejalectoPerson).setHidden(true);
                        ip.addPerson(dejalectoPerson);
                    }
                }
            }
            // CSP reference
/*           if (isCSP) {
                MarketAPI market4 = Global.getSector().getEconomy().getMarket("cruor");
                if (market4 != null) {
                    PersonAPI cspmongaeraPerson = Global.getFactory().createPerson();
                    cspmongaeraPerson.setId(cspmongaera);
                    cspmongaeraPerson.setFaction(Factions.LIONS_GUARD);
                    cspmongaeraPerson.setGender(Gender.FEMALE);
                    cspmongaeraPerson.setRankId("sfcregmanager");
                    cspmongaeraPerson.setPostId("sfcregmanager");
                    cspmongaeraPerson.setImportance(PersonImportance.VERY_HIGH);
                    cspmongaeraPerson.getName().setFirst("Calista");
                    cspmongaeraPerson.getName().setLast("mongaera");
                    cspmongaeraPerson.setPortraitSprite(Global.getSettings().getSpriteName("characters", "cspmongaera"));
                    cspmongaeraPerson.addTag(Tags.CONTACT_MILITARY);
                    cspmongaeraPerson.setVoice(Voices.SOLDIER);
                    market4.getCommDirectory().addPerson(cspmongaeraPerson, 0);
                    market4.addPerson(cspmongaeraPerson);
                    market4.getCommDirectory().getEntryForPerson(cspmongaeraPerson).setHidden(true);
                    ip.addPerson(cspmongaeraPerson);
                }
            }*/
        }
    }

    public void onGameLoad(final boolean isNewGame) {
        sfc_specialItemsEffectRepo.addItemEffectsToVanillaRepo();
        BarEventManager bar = BarEventManager.getInstance();
        if (!bar.hasEventCreator(sfc_CompanyFuelBarEventCreator.class)) {
            bar.addEventCreator(new sfc_CompanyFuelBarEventCreator());
        }
        //addScriptsIfNeeded();
    }
    /*protected void addScriptsIfNeeded() {
        SectorAPI sector = Global.getSector();

        if (!sector.hasScript(sfc_nftMilitiaFleet.class)) {
            sector.addScript(new sfc_nftMilitiaFleet());
        }
    }*/
}