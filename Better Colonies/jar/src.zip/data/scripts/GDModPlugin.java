package data.scripts;

import com.fs.starfarer.api.BaseModPlugin;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.BaseCampaignEventListener;
import com.fs.starfarer.api.campaign.FactionAPI;
import com.fs.starfarer.api.campaign.econ.Industry;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.ids.Industries;
import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.api.util.WeightedRandomPicker;
import exerelin.ExerelinConstants;
import exerelin.campaign.intel.rebellion.RebellionCreator;
import exerelin.campaign.intel.rebellion.RebellionIntel;
import exerelin.utilities.NexConfig;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class GDModPlugin extends BaseModPlugin {
        public static String[] SupportedFaction = new String[]{
        };
        public static Map<String, Float> SupportedIndustries = new HashMap();
        
    public void onApplicationLoad() throws Exception {
        JSONArray maxIndustries = Global.getSettings().getJSONArray("maxIndustries");
        // Sets sizes 9-10 to 4-5 respectively.
        if (Global.getSettings().getBoolean("BCChangeIndustrySize")) {
            for (int i = 8; i < 10; i++) {
                maxIndustries.put(i, (int) maxIndustries.get(i)+1);
            }
        }
        if (Global.getSettings().getBoolean("BCAutoImproveIndustry")) {
            try {
                List<String> EligibleFactions = new ArrayList<>();
                JSONArray modFactionsCsv = Global.getSettings().getMergedSpreadsheetDataForMod("faction", "data/config/BetterColonyConfig/bc_autospfactions.csv", "timid_admins");
                for(int i = 0; i < modFactionsCsv.length(); i++) {
                    JSONObject row = modFactionsCsv.getJSONObject(i);
                    String factionName = row.getString("faction");
                    if (!factionName.equals("player")) EligibleFactions.add(factionName);
                }
                SupportedFaction = EligibleFactions.toArray(new String[]{});
            } catch (IOException | JSONException sex) {}
            try {
                JSONArray modIndustryCsv = Global.getSettings().getMergedSpreadsheetDataForMod("industry", "data/config/BetterColonyConfig/bc_autospindustries.csv", "timid_admins");
                for(int i = 0; i < modIndustryCsv.length(); i++) {
                    JSONObject row = modIndustryCsv.getJSONObject(i);
                    SupportedIndustries.put(row.getString("industry"), (float) row.getDouble("weight"));
                }
                
            } catch (IOException | JSONException sex) {}
        }
    }
    
    public void onGameLoad(boolean newGame) {
        for (MarketAPI market : Global.getSector().getEconomy().getMarketsCopy()) {
            if (market.hasCondition("bc_luddicfaith")) {market.removeCondition("bc_luddicfaith");market.addCondition("bc_luddicfaith");}
        }
        if (Global.getSector().getEconomy().getMarket("epiphany") != null) {if (Global.getSector().getEconomy().getMarket("epiphany").hasCondition("bc_luddicfaith")) {Global.getSector().getEconomy().getMarket("epiphany").removeCondition("bc_luddicfaith");}Global.getSector().getEconomy().getMarket("epiphany").addCondition("bc_luddicfaith");}
        if (Global.getSector().getEconomy().getMarket("gilead") != null) {if (Global.getSector().getEconomy().getMarket("gilead").hasCondition("bc_luddicfaith")) {Global.getSector().getEconomy().getMarket("gilead").removeCondition("bc_luddicfaith");}Global.getSector().getEconomy().getMarket("gilead").addCondition("bc_luddicfaith");}
        if (Global.getSector().getEconomy().getMarket("jangala") != null) {if (Global.getSector().getEconomy().getMarket("jangala").hasCondition("bc_luddicfaith")) {Global.getSector().getEconomy().getMarket("jangala").removeCondition("bc_luddicfaith");}Global.getSector().getEconomy().getMarket("jangala").addCondition("bc_luddicfaith");}
        if (Global.getSector().getEconomy().getMarket("tartessus") != null) {if (Global.getSector().getEconomy().getMarket("tartessus").hasCondition("bc_luddicfaith")) {Global.getSector().getEconomy().getMarket("tartessus").removeCondition("bc_luddicfaith");}Global.getSector().getEconomy().getMarket("tartessus").addCondition("bc_luddicfaith");}
        if (Global.getSector().getEconomy().getMarket("hesperus") != null) {if (Global.getSector().getEconomy().getMarket("hesperus").hasCondition("bc_luddicfaith")) {Global.getSector().getEconomy().getMarket("hesperus").removeCondition("bc_luddicfaith");}Global.getSector().getEconomy().getMarket("hesperus").addCondition("bc_luddicfaith");}
        if (Global.getSector().getEconomy().getMarket("chalcedon") != null) {if (Global.getSector().getEconomy().getMarket("chalcedon").hasCondition("bc_luddicfaith")) {Global.getSector().getEconomy().getMarket("chalcedon").removeCondition("bc_luddicfaith");}Global.getSector().getEconomy().getMarket("chalcedon").addCondition("bc_luddicfaith");}
        if (Global.getSector().getEconomy().getMarket("mazalot") != null) {if (Global.getSector().getEconomy().getMarket("mazalot").hasCondition("bc_luddicfaith")) {Global.getSector().getEconomy().getMarket("mazalot").removeCondition("bc_luddicfaith");}Global.getSector().getEconomy().getMarket("mazalot").addCondition("bc_luddicfaith");}
        if (Global.getSettings().getModManager().isModEnabled("nexerelin")) {
            if (NexConfig.enableInvasions) {
                Global.getSector().addTransientListener(new LuddicCheck());
            }
            if (Global.getSettings().getBoolean("BCLoseSPImprovements")) {
                Global.getSector().getListenerManager().addListener(new BCLoseSPImprovements(), true);
            }
        }
        if (Global.getSettings().getBoolean("BCAutoImproveIndustry")) {
            Global.getSector().addTransientListener(new LuddicCheck2());
        }
    }
    
    
    public static class LuddicCheck extends BaseCampaignEventListener {
        LuddicCheck() {
            super(false);
        }
        
        @Override
        public void reportEconomyMonthEnd() {
            if (Misc.getRandom(Misc.genRandomSeed(), 1).nextFloat() <= 0.5f) {
                for (MarketAPI market : Global.getSector().getEconomy().getMarketsCopy()) {
                    if (!market.getFaction().getId().equals(Factions.LUDDIC_CHURCH) && market.hasCondition("bc_luddicfaith") && !market.hasIndustry("bc_luddic") && RebellionIntel.getOngoingEvent(market) == null && !Misc.isStoryCritical(market) && !market.getMemoryWithoutUpdate().getBoolean(ExerelinConstants.MEMORY_KEY_NPC_NO_INVADE)) {
                        RebellionCreator.getInstance().createRebellion(market, Factions.LUDDIC_CHURCH, true);
                    }
                }
            }
        }
    }
    
    public static class LuddicCheck2 extends BaseCampaignEventListener {
        LuddicCheck2() {
            super(false);
        }
        
        @Override
        public void reportEconomyMonthEnd() {
            if (SupportedFaction != null) {
                if (Misc.getRandom(Misc.genRandomSeed(), 1).nextFloat() <= 0.2f) {
                    if (Global.getSettings().getBoolean("BCIgnoreFactionWhiteflag")) {
                        for (FactionAPI faction : Global.getSector().getAllFactions()) {
                            for (MarketAPI market : Misc.getFactionMarkets(faction.getId())) {
                                if (market != null && Misc.getRandom(Misc.genRandomSeed(), 1).nextFloat() <= (Global.getSector().getFaction(faction.getId()).getCustomBoolean("decentralized") ? 0.02f : 0.05f)*market.getIndustries().size()) {
                                    if (Misc.getRandom(Misc.genRandomSeed(), 1).nextFloat() <= 1/Math.pow(2, Misc.getNumImprovedIndustries(market))) {
                                        WeightedRandomPicker<String> AmongUs = new WeightedRandomPicker<String>();
                                        for (Industry industry : market.getIndustries()) {
                                            if (industry.isImproved()) continue;
                                            if (industry.canImprove() && industry.isFunctional() && (!industry.isUpgrading() || industry.getId().equals(Industries.POPULATION)) && !industry.isHidden() && !industry.isDisrupted()) {
                                                float weight = 1f;
                                                if (SupportedIndustries != null && SupportedIndustries.get(industry.getId()) != null) {weight = SupportedIndustries.get(industry.getId());}
                                                AmongUs.add(industry.getId(), weight);
                                            }
                                        }
                                        String industryid = AmongUs.pick();
                                        if (industryid != null) {market.getIndustry(industryid).setImproved(true);if (Global.getSettings().getBoolean("BCDebugText")) {Global.getSector().getCampaignUI().addMessage(market.getName()+" improved "+market.getIndustry(industryid).getCurrentName()+"! "+AmongUs.getWeight(industryid), market.getFaction().getColor());}}
                                   }
                                } 
                            }
                        }
                    } else {
                        for (String factionid : SupportedFaction) {
                             for (MarketAPI market : Misc.getFactionMarkets(factionid)) {
                                if (market != null && Misc.getRandom(Misc.genRandomSeed(), 1).nextFloat() <= (Global.getSector().getFaction(factionid).getCustomBoolean("decentralized") ? 0.02f : 0.05f)*market.getIndustries().size()) {
                                    if (Misc.getRandom(Misc.genRandomSeed(), 1).nextFloat() <= 1/Math.pow(2, Misc.getNumImprovedIndustries(market))) {
                                        WeightedRandomPicker<String> AmongUs = new WeightedRandomPicker<String>();
                                        for (Industry industry : market.getIndustries()) {
                                            if (industry.isImproved()) continue;
                                            if (industry.canImprove() && industry.isFunctional() && (!industry.isUpgrading() || industry.getId().equals(Industries.POPULATION)) && !industry.isHidden() && !industry.isDisrupted()) {
                                                float weight = 1f;
                                                if (SupportedIndustries != null && SupportedIndustries.get(industry.getId()) != null) {weight = SupportedIndustries.get(industry.getId());}
                                                AmongUs.add(industry.getId(), weight);
                                            }
                                        }
                                        String industryid = AmongUs.pick();
                                        if (industryid != null) {market.getIndustry(industryid).setImproved(true);if (Global.getSettings().getBoolean("BCDebugText")) {Global.getSector().getCampaignUI().addMessage(market.getName()+" improved "+market.getIndustry(industryid).getCurrentName()+"! "+AmongUs.getWeight(industryid), market.getFaction().getColor());}}
                                   }
                                } 
                            }
                        }
                    }
                }
            }
        }
    }
    
}
