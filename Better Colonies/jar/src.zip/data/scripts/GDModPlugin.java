package data.scripts;


import com.fs.starfarer.api.BaseModPlugin;
//import com.fs.starfarer.api.Global;
//import org.json.JSONArray;

public class GDModPlugin extends BaseModPlugin {
	/*@Override
	public void onApplicationLoad() throws Exception {
        if (!Global.getSettings().getModManager().isModEnabled("lw_lazylib")) {
            throw new RuntimeException("Better Colonies requires LazyLib!" + "\nGet it at http://fractalsoftworks.com/forum/index.php?topic=5444");
        }
        //JSONObject settings = Global.getSettings().loadJSON( "wyv_gd_settings.json" );
        //revertToVanilla = settings.getBoolean( "revertToVanillaIndustryBehavior" );
        JSONArray maxIndustries = Global.getSettings().getJSONArray("maxIndustries");
        // Sets sizes 9-10 to 4-5 respectively.
        for (int i = 8; i < 10; i++) {
            maxIndustries.put(i, (int) maxIndustries.get(i)+1);
        }
    }*/
}
