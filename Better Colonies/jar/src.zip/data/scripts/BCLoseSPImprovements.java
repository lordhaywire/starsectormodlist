package data.scripts;

import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.CargoAPI;
import com.fs.starfarer.api.campaign.FactionAPI;
import com.fs.starfarer.api.campaign.InteractionDialogAPI;
import com.fs.starfarer.api.campaign.econ.Industry;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.impl.campaign.rulecmd.salvage.Nex_MarketCMD;
import exerelin.campaign.InvasionRound;
import exerelin.utilities.InvasionListener;
import java.util.List;

/**
 * Handles changing of market descriptions when a market is captured.
 */
public class BCLoseSPImprovements implements InvasionListener {
        
	public static BCLoseSPImprovements currInstance;
	
	public BCLoseSPImprovements registerInstance() {
		currInstance = this;
		return this;
	}
	
	public static BCLoseSPImprovements getInstance() {
		return currInstance;
	}

	@Override
	public void reportInvadeLoot(InteractionDialogAPI dialog, MarketAPI market, 
			Nex_MarketCMD.TempDataInvasion actionData, CargoAPI cargo) {
	}
	
	@Override
	public void reportInvasionRound(InvasionRound.InvasionRoundResult result, CampaignFleetAPI fleet, 
			MarketAPI defender, float atkStr, float defStr) {
	}
	
	@Override
	public void reportInvasionFinished(CampaignFleetAPI fleet, FactionAPI attackerFaction, 
			MarketAPI market, float numRounds, boolean success) {
            if (success) {
                for (Industry industry : market.getIndustries()) {
                    if (industry.isDisrupted() && !industry.isHidden() && industry.isImproved()) {industry.setImproved(false);}
                }
            }
	}
        @Override
        public void reportMarketTransfered(MarketAPI market, FactionAPI newOwner, FactionAPI oldOwner, boolean playerInvolved, boolean isCapture, List<String> factionsToNotify, float repChangeStrength) {
            for (Industry industry : market.getIndustries()) {
                    if (industry.isDisrupted() && !industry.isHidden() && industry.isImproved()) {industry.setImproved(false);}
                }
        }
}