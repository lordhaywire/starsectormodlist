/*package com.fs.starfarer.api.impl.campaign.missions;

import com.fs.starfarer.api.Global;
import java.util.Map;

import com.fs.starfarer.api.campaign.InteractionDialogAPI;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.campaign.rules.MemoryAPI;
import com.fs.starfarer.api.characters.PersonAPI;
import com.fs.starfarer.api.fleet.FleetMemberAPI;
import com.fs.starfarer.api.impl.campaign.missions.hub.HubMissionWithSearch;
import com.fs.starfarer.api.util.Misc;

public class BCLuddicAmnesty extends HubMissionWithSearch {
	public static float BASE_PRICE_MULT = 0.33f;
	protected FleetMemberAPI member;
	protected int price;
	
	@Override
	protected boolean create(MarketAPI createdAt, boolean barEvent) {
		PersonAPI person = getPerson();
		if (person == null) return false;
		MarketAPI market = person.getMarket();
		if (market == null) return false;
		
		if (!setPersonMissionRef(person, "$bclob_ref")) {
			return false;
		}
                Global.getSector().getAllFactions();
		setRepFactionChangesTiny();
		setRepPersonChangesVeryLow();
		requireMarketFactionHostileTo(createdAt.getFactionId());
		return true;
	}
	
	protected void updateInteractionDataImpl() {
		set("$bclob_ref2", this);
		set("$bclob_faction", member.getHullSpec().getHullNameWithDashClass());
		set("$bclob_price", Misc.getWithDGS(price));
	}

	@Override
	public String getBaseName() {
		return "Luddic Amnesty"; // not used I don't think
	}
	
	@Override
	public void accept(InteractionDialogAPI dialog, Map<String, MemoryAPI> memoryMap) {
		// it's just an transaction immediate transaction handled in rules.csv
		// no intel item etc
		currentStage = new Object(); // so that the abort() assumes the mission was successful
		abort();
	}
}*/




