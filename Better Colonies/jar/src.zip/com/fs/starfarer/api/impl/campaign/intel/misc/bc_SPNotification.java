package com.fs.starfarer.api.impl.campaign.intel.misc;

import java.util.Set;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.impl.campaign.ids.Tags;
import com.fs.starfarer.api.impl.campaign.intel.BaseIntelPlugin;
import com.fs.starfarer.api.ui.SectorMapAPI;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;
import java.awt.Color;
import java.util.List;

public class bc_SPNotification extends BaseIntelPlugin {
        protected String date;    
        protected List<String> text;
        protected String title;
        protected List<Color> factioncolor;
        protected List<String> highlighttext;
        protected List<String> highlighttext2;
	public bc_SPNotification(String title, String date, List<String> text, List<Color> factioncolor, List<String> highlighttext, List<String> highlighttext2) {
                this.date = date;
                this.text = text;
                this.title = title;
                this.factioncolor = factioncolor;
                this.highlighttext = highlighttext;
                this.highlighttext2 = highlighttext2;
	}
        
	@Override
	public void createSmallDescription(TooltipMakerAPI info, float width, float height) {
		float opad = 10f;
                info.addImage("graphics/icons/industry/spaceport.png", width, 128, opad);
                info.addPara(date, opad).italicize();
                for (int i = 0; i < text.size(); i++) {
                    String text2 = text.get(i);
                    Color[] colors = new Color[2];
                    colors[0] = text.size() == factioncolor.size() ? factioncolor.get(i) : Misc.getHighlightColor();
                    colors[1] = Misc.getHighlightColor();
                    info.addPara(text2, 0f, colors, text.size() == highlighttext.size() ? highlighttext.get(i) : "", text.size() == highlighttext2.size() ? highlighttext2.get(i) : "");
                }
                addDeleteButton(info, width);
                if (!Global.getSettings().getBoolean("BCIgnoreFactionWhiteflag")) {info.addPara(Global.getSettings().getString("bettercolonies", "SPNotificationReminder"), 10f).italicize();}
	}
        
        @Override
        public void advanceImpl(float amount) {
            //endAfterDelay();
        }
        
	@Override
	public String getIcon() {
		return Global.getSettings().getSpriteName("intel", "historian_intel_icon");
	}
	
	@Override
	public Set<String> getIntelTags(SectorMapAPI map) {
		Set<String> tags = super.getIntelTags(map);
		tags.add(Tags.INTEL_FLEET_LOG);
		return tags;
	}
	
        @Override
	public String getName() {
		return title;
	}
}







