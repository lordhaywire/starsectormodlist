package com.fs.starfarer.api.impl.campaign.econ;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.BattleAPI;
import com.fs.starfarer.api.campaign.CampaignEventListener.FleetDespawnReason;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.FactionAPI.ShipPickMode;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.campaign.econ.MarketImmigrationModifier;
import com.fs.starfarer.api.campaign.listeners.FleetEventListener;
import com.fs.starfarer.api.impl.campaign.fleets.FleetFactory.PatrolType;
import com.fs.starfarer.api.impl.campaign.fleets.FleetFactoryV3;
import com.fs.starfarer.api.impl.campaign.fleets.FleetParamsV3;
import com.fs.starfarer.api.impl.campaign.fleets.PatrolAssignmentAIV4;
import com.fs.starfarer.api.impl.campaign.econ.impl.MilitaryBase.PatrolFleetData;
import com.fs.starfarer.api.impl.campaign.fleets.RouteManager;
import com.fs.starfarer.api.impl.campaign.fleets.RouteManager.OptionalFleetData;
import com.fs.starfarer.api.impl.campaign.fleets.RouteManager.RouteData;
import com.fs.starfarer.api.impl.campaign.fleets.RouteManager.RouteFleetSpawner;
import com.fs.starfarer.api.impl.campaign.fleets.RouteManager.RouteSegment;
import com.fs.starfarer.api.impl.campaign.ids.Conditions;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.ids.MemFlags;
import com.fs.starfarer.api.impl.campaign.ids.Ranks;
import com.fs.starfarer.api.impl.campaign.ids.Stats;
import static com.fs.starfarer.api.impl.campaign.intel.bases.LuddicPathBaseManager.getLuddicPathMarketInterest;
import com.fs.starfarer.api.impl.campaign.population.PopulationComposition;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.IntervalUtil;
import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.api.util.WeightedRandomPicker;
import java.awt.Color;
import java.util.Random;


public class LuddicFaith extends BaseMarketConditionPlugin implements RouteFleetSpawner, FleetEventListener, MarketImmigrationModifier {
    
        protected void createTooltipAfterDescription(TooltipMakerAPI tooltip, boolean expanded) {
		super.createTooltipAfterDescription(tooltip, expanded);
		Color[] colors = new Color[2];
                colors[0] = Global.getSettings().getDesignTypeColor("Luddic Church");
                colors[1] = Misc.getHighlightColor();
                if (market.getFaction().getId().equals(Factions.LUDDIC_CHURCH) || (GoodFaith() && GooderFaith())) {
                    if (market.isPlayerOwned()) tooltip.addPara("Pilgrimages are made to this shrine, contributing %s to this market's income.", 10f, Misc.getHighlightColor(), ""+Misc.getDGSCredits(market.getIndustry("bc_luddic").getIncome().modified)); else {tooltip.addPara("Pilgrimages are made to this shrine by many Luddic sects.", 10f);}
                    if (!market.isFreePort() || market.getFaction().getId().equals(Factions.LUDDIC_CHURCH)) tooltip.addPara("%s stability (based on Church reputation)", 10f, Misc.getHighlightColor(), "+" + Math.max(1, Math.round(3*market.getFaction().getRelationship(Factions.LUDDIC_CHURCH))));
                    if (!market.isFreePort() || market.getFaction().getId().equals(Factions.LUDDIC_CHURCH)) tooltip.addPara("%s population growth (based on colony size and Church reputation)", 10f, Misc.getHighlightColor(),"+" + (int) getImmigrationBonus());
                    if (market.isPlayerOwned() && !market.isFreePort() && !market.hasCondition(Conditions.POLLUTION)) tooltip.addPara("%s Pather intrigue", 10f, Misc.getHighlightColor(), "-"+Math.max(7, Global.getSettings().getInt("minInterestForPatherCells")));
                    if (market.isPlayerOwned()) tooltip.addPara("A %s garrison have been assigned to patrol %s.", 10f, colors, "Knight of Ludd", market.getName());
                } else {
                    if (GooderFaith()) tooltip.addPara("The shrine of %s has been defiled by the servants of Moloch.", 10f, Misc.getNegativeHighlightColor(), Misc.getHighlightColor(), market.getName()); else {tooltip.addPara("%s has fallen out of grace with the Church.", 10f, Misc.getNegativeHighlightColor(), Misc.getHighlightColor(), market.getName());}
                    tooltip.addPara("%s stability", 10f, Misc.getHighlightColor(), "-" + 3);
                    tooltip.addPara("%s ground defenses", 10f, Misc.getHighlightColor(), "-" + 15 + "%");
                }
	}
        
	public void modifyIncoming(MarketAPI market, PopulationComposition incoming) {
		incoming.add(Factions.LUDDIC_CHURCH, 10f);
		incoming.getWeight().modifyFlat(getModId(), getImmigrationBonus(), Misc.ucFirst(condition.getName().toLowerCase()));
	}
	
	protected float getImmigrationBonus() {
		return Math.max(1, market.getSize()*(market.getFaction().getRelationship(Factions.LUDDIC_CHURCH)));
	}
    
	public void apply(String id) {
                if (market.getFaction().getId().equals(Factions.LUDDIC_CHURCH) || GoodFaith() && GooderFaith()) {
                    if (!market.isFreePort() || market.getFaction().getId().equals(Factions.LUDDIC_CHURCH)) {market.getStability().modifyFlat(id, Math.max(1, Math.round(3*market.getFaction().getRelationship(Factions.LUDDIC_CHURCH))), "Luddic shrine");market.addTransientImmigrationModifier(this);}
                    if (!market.hasIndustry("bc_luddic")) {market.addIndustry("bc_luddic");}} else {market.getStability().modifyFlat(id, -3f, "Luddic unrest");if (market.hasIndustry("bc_luddic")) {market.removeIndustry("bc_luddic", null, false);}
                market.getStats().getDynamic().getMod(Stats.GROUND_DEFENSES_MOD).modifyMult(id, 0.85f, "Luddic unrest");}
                
	}
        
        public boolean GoodFaith() {
            return (market.getAdmin().getAICoreId() == null && getLuddicPathMarketInterest(market) < Global.getSettings().getInt("minInterestForPatherCells")*2);
        }
        
        public boolean GooderFaith() {
            return market.getFaction().getRelationship(Factions.LUDDIC_CHURCH) > -0.5f;
        }

	@Override
	public void unapply(String id) {
                if (market.hasIndustry("bc_luddic")) {market.removeIndustry("bc_luddic", null, false);}
                market.getStability().unmodify(id);
                market.getStats().getDynamic().getMod(Stats.GROUND_DEFENSES_MOD).unmodifyMult(id);
                market.removeTransientImmigrationModifier(this);
	}

	protected IntervalUtil tracker = new IntervalUtil(Global.getSettings().getFloat("averagePatrolSpawnInterval") * 0.7f,
													  Global.getSettings().getFloat("averagePatrolSpawnInterval") * 1.3f);
	
	protected float returningPatrolValue = 0f;


	@Override
	public void advance(float amount) {
		super.advance(amount);
		
		if (Global.getSector().getEconomy().isSimMode()) return;
                
                if (!market.isPlayerOwned()) return;
		
		float days = Global.getSector().getClock().convertToDays(amount);
		
		float spawnRate = 1f;
		float rateMult = market.getStats().getDynamic().getStat(Stats.COMBAT_FLEET_SPAWN_RATE_MULT).getModifiedValue();
		spawnRate *= rateMult;
		
		
		float extraTime = 0f;
		if (returningPatrolValue > 0) {
			// apply "returned patrols" to spawn rate, at a maximum rate of 1 interval per day
			float interval = tracker.getIntervalDuration();
			extraTime = interval * days;
			returningPatrolValue -= days;
			if (returningPatrolValue < 0) returningPatrolValue = 0;
		}
		tracker.advance(days * spawnRate + extraTime);
		
		//tracker.advance(days * spawnRate * 100f);
		
		if (tracker.intervalElapsed()) {
			String sid = getRouteSourceId();
			
			WeightedRandomPicker<PatrolType> picker = new WeightedRandomPicker<PatrolType>();
			picker.add(PatrolType.COMBAT, getMaxPatrols(PatrolType.COMBAT) - getCount(PatrolType.COMBAT)); 
			
			if (picker.isEmpty()) return;
                        
			PatrolType type = PatrolType.COMBAT;
			PatrolFleetData custom = new PatrolFleetData(type);
			
			OptionalFleetData extra = new OptionalFleetData(market);
			extra.fleetType = type.getFleetType();
			
			RouteData route = RouteManager.getInstance().addRoute(sid, market, Misc.genRandomSeed(), extra, this, custom);
			float patrolDays = 35f + (float) Math.random() * 10f;
			
			route.addSegment(new RouteSegment(patrolDays, market.getPrimaryEntity()));
		}
	}
	
	public void reportAboutToBeDespawnedByRouteManager(RouteData route) {
	}
	
	public boolean shouldRepeat(RouteData route) {
		return false;
	}
	
	public int getCount(PatrolType ... types) {
		int count = 0;
		for (RouteData data : RouteManager.getInstance().getRoutesForSource(getRouteSourceId())) {
			if (data.getCustom() instanceof PatrolFleetData) {
				PatrolFleetData custom = (PatrolFleetData) data.getCustom();
				for (PatrolType type : types) {
					if (type == custom.type) {
						count++;
						break;
					}
				}
			}
		}
		return count;
	}

	public int getMaxPatrols(PatrolType type) {
		return 1;
	}
	
	public boolean shouldCancelRouteAfterDelayCheck(RouteData route) {
		return false;
	}

	public void reportBattleOccurred(CampaignFleetAPI fleet, CampaignFleetAPI primaryWinner, BattleAPI battle) {
		
	}

	public void reportFleetDespawnedToListener(CampaignFleetAPI fleet, FleetDespawnReason reason, Object param) {
		if (reason == FleetDespawnReason.REACHED_DESTINATION) {
			RouteData route = RouteManager.getInstance().getRoute(getRouteSourceId(), fleet);
			if (route.getCustom() instanceof PatrolFleetData) {
				PatrolFleetData custom = (PatrolFleetData) route.getCustom();
				if (custom.spawnFP > 0) {
					float fraction  = fleet.getFleetPoints() / custom.spawnFP;
					returningPatrolValue += fraction;
				}
			}
		}
	}
	
	public CampaignFleetAPI spawnFleet(RouteData route) {
		
		PatrolFleetData custom = (PatrolFleetData) route.getCustom();
		PatrolType type = custom.type;
		
		Random random = route.getRandom();
		
		float combat = Math.round(10f + (float) random.nextFloat() * 5f) * 5f;
		float tanker = Math.round((float) random.nextFloat() * 3f);
		float freighter = Math.round((float) random.nextFloat() * 3f);
                
		String fleetType = type.getFleetType();
                
		FleetParamsV3 params = new FleetParamsV3(
				market, 
				null, // loc in hyper; don't need if have market
				(GoodFaith() && GooderFaith()) ? Factions.LUDDIC_CHURCH : Factions.LUDDIC_PATH,
				2f, // quality override
				fleetType,
				combat, // combatPts
				freighter, // freighterPts 
				tanker, // tankerPts
				0f, // transportPts
				0f, // linerPts
				0f, // utilityPts
				0f // qualityMod
				);
		params.timestamp = route.getTimestamp();
		params.random = random;
		params.modeOverride = Misc.getShipPickMode(market);
		params.modeOverride = ShipPickMode.PRIORITY_THEN_ALL;
		CampaignFleetAPI fleet = FleetFactoryV3.createFleet(params);
		
		if (fleet == null || fleet.isEmpty()) return null;
		
		fleet.setFaction(GoodFaith() && GooderFaith() ? Factions.LUDDIC_CHURCH : Factions.LUDDIC_PATH, true);
                fleet.setName(market.getName()+" "+(GoodFaith() && market.getFaction().getRelationship(Factions.LUDDIC_CHURCH) > -0.5f ? (Global.getSector().getFaction(Factions.LUDDIC_CHURCH).getFleetTypeName("patrolSmall")) : (Global.getSector().getFaction(Factions.LUDDIC_PATH).getFleetTypeName("taskForce"))));
		fleet.setNoFactionInName(true);
		
		fleet.addEventListener(this);

		fleet.getMemoryWithoutUpdate().set(MemFlags.FLEET_IGNORES_OTHER_FLEETS, true, 0.3f);

		fleet.getMemoryWithoutUpdate().set(MemFlags.MEMORY_KEY_CUSTOMS_INSPECTOR, true);
		
		fleet.getCommander().setPostId(GoodFaith() && GooderFaith() ? Ranks.POST_PATROL_COMMANDER : Ranks.POST_TERRORIST);
		fleet.getCommander().setRankId(GoodFaith() && GooderFaith() ? Ranks.KNIGHT_CAPTAIN : Ranks.TERRORIST);
		
		market.getContainingLocation().addEntity(fleet);
		fleet.setFacing((float) Math.random() * 360f);
		// this will get overridden by the patrol assignment AI, depending on route-time elapsed etc
		fleet.setLocation(market.getPrimaryEntity().getLocation().x, market.getPrimaryEntity().getLocation().y);
		
		fleet.addScript(new PatrolAssignmentAIV4(fleet, route));
		
		if (custom.spawnFP <= 0) {
			custom.spawnFP = fleet.getFleetPoints();
		}
		
		return fleet;
	}
	
	public String getRouteSourceId() {
		return market.getId() + "_" + "luddicfaith";
	}
}
