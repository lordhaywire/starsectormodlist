package com.fs.starfarer.api.impl.campaign.econ.impl;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.impl.campaign.ids.Conditions;
import com.fs.starfarer.api.impl.campaign.ids.Factions;


public class luddicteachingGD extends BaseIndustry {
    
        @Override
        public boolean canBeDisrupted() {
		return false;
	}
    
        @Override
	public float getPatherInterest() {
		if (getMarket().isFreePort() || !isFunctional() || getMarket().hasCondition(Conditions.POLLUTION)) return super.getPatherInterest();
		return -Math.max(7, Global.getSettings().getInt("minInterestForPatherCells")) + super.getPatherInterest();
	}
        
        @Override
	public boolean isFunctional() {
                return (market.hasCondition("bc_luddicfaith"));
	}
        
        @Override
	public void apply() {
		super.apply(false);
		
                int size = market.getSize();
		
		if (isFunctional()) {
                    applyIncomeAndUpkeep(size+(size*market.getFaction().getRelationship(Factions.LUDDIC_CHURCH)));
		}
                if (!market.hasCondition("bc_luddicfaith")) {market.removeIndustry("bc_luddic", null, false);}
	}
	
	@Override
	public void unapply() {
		super.unapply();
	}
        
	@Override
	protected boolean canImproveToIncreaseProduction() {
		return false;
	}
        
	@Override
	public boolean isAvailableToBuild() {
		return false;
	}

        @Override
	public boolean showWhenUnavailable() {
		return false;
	}
        
        @Override
        public boolean isHidden() {
		return true;
	}
}
