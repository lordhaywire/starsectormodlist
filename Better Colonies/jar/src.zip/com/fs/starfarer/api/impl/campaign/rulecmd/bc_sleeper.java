package com.fs.starfarer.api.impl.campaign.rulecmd;

import java.util.List;
import java.util.Map;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.InteractionDialogAPI;
import com.fs.starfarer.api.campaign.TextPanelAPI;
import com.fs.starfarer.api.campaign.rules.MemoryAPI;
import com.fs.starfarer.api.impl.campaign.events.OfficerManagerEvent;
import com.fs.starfarer.api.impl.campaign.events.OfficerManagerEvent.SkillPickPreference;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.ids.Ranks;
import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.api.util.Misc.Token;
import java.awt.Color;
import java.util.Random;

public class bc_sleeper extends BaseCommandPlugin {

	public boolean execute(String ruleId, InteractionDialogAPI dialog, List<Token> params, final Map<String, MemoryAPI> memoryMap) {
		if (dialog == null) return false;
                if (!params.isEmpty()) {
                    if (params.get(0).getString(memoryMap).equals("printSkills")) {
                        TextPanelAPI text = dialog.getTextPanel();
                        Color hl = Misc.getHighlightColor();
                        text.addSkillPanel(dialog.getInteractionTarget().getActivePerson(), false);
                        text.setFontSmallInsignia();
                        String personality = Misc.lcFirst(dialog.getInteractionTarget().getActivePerson().getPersonalityAPI().getDisplayName());
                        text.addParagraph("Personality: " + personality + ", level: " + dialog.getInteractionTarget().getActivePerson().getStats().getLevel());
                        text.highlightInLastPara(hl, personality, "" + dialog.getInteractionTarget().getActivePerson().getStats().getLevel());
                        text.addParagraph(dialog.getInteractionTarget().getActivePerson().getPersonalityAPI().getDescription());
                        text.setFontInsignia();
                        return true;
                    } else if (params.get(0).getString(memoryMap).equals("atLimit")) {
			return Misc.getNumNonMercOfficers(Global.getSector().getPlayerFleet()) >= Global.getSector().getPlayerFleet().getCommander().getStats().getOfficerNumber().getModifiedInt();
                    } else if (params.get(0).getString(memoryMap).equals("canAfford")) {
                        return Global.getSector().getPlayerFleet().getCargo().getCredits().get() >= (int) (dialog.getInteractionTarget().getActivePerson().getStats().getLevel() * 2000);
                    } else if (params.get(0).getString(memoryMap).equals("hireOfficer")) {
                        dialog.getInteractionTarget().getActivePerson().getMemoryWithoutUpdate().unset("$ome_hiringBonus");		
                        dialog.getInteractionTarget().getActivePerson().getMemoryWithoutUpdate().unset("$ome_salary");
                        dialog.getInteractionTarget().getActivePerson().setPostId(Ranks.POST_OFFICER);
                        Global.getSector().getPlayerFleet().getFleetData().addOfficer(dialog.getInteractionTarget().getActivePerson());
                        AddRemoveCommodity.addCreditsLossText((int) (dialog.getInteractionTarget().getActivePerson().getStats().getLevel() * 2000), dialog.getTextPanel());
                        AddRemoveCommodity.addOfficerGainText(dialog.getInteractionTarget().getActivePerson(), dialog.getTextPanel());
                        Global.getSector().getPlayerFleet().getCargo().getCredits().subtract((int) (dialog.getInteractionTarget().getActivePerson().getStats().getLevel() * 2000));
			if (Global.getSector().getPlayerFleet().getCargo().getCredits().get() <= 0) {
                            Global.getSector().getPlayerFleet().getCargo().getCredits().set(0);
			}
                    }
                }
                dialog.getInteractionTarget().setActivePerson(OfficerManagerEvent.createOfficer(Global.getSector().getFaction(Factions.PLAYER), Math.min(dialog.getInteractionTarget().getMarket().getSize(), 7), SkillPickPreference.ANY, true, null, true, true, 3, new Random()));
		dialog.getInteractionTarget().getActivePerson().getMemoryWithoutUpdate().set("$ome_hiringBonus", Misc.getWithDGS((int) (dialog.getInteractionTarget().getActivePerson().getStats().getLevel() * 2000)));		
		dialog.getInteractionTarget().getActivePerson().getMemoryWithoutUpdate().set("$ome_salary", Misc.getWithDGS((int) Misc.getOfficerSalary(dialog.getInteractionTarget().getActivePerson())));
                return true;
	}
}

