package com.fs.starfarer.api.impl.campaign.rulecmd;

import java.util.List;
import java.util.Map;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.InteractionDialogAPI;
import com.fs.starfarer.api.campaign.ResourceCostPanelAPI;
import com.fs.starfarer.api.campaign.rules.MemoryAPI;
import com.fs.starfarer.api.impl.campaign.ids.Commodities;
import com.fs.starfarer.api.impl.campaign.ids.Conditions;
import com.fs.starfarer.api.impl.campaign.ids.Stats;
import static com.fs.starfarer.api.impl.campaign.rulecmd.salvage.SalvageEntity.COST_HEIGHT;
import com.fs.starfarer.api.ui.Alignment;
import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.api.util.Misc.Token;
import com.fs.starfarer.api.impl.PlayerFleetPersonnelTracker;

public class bc_techmine extends BaseCommandPlugin {

	public boolean execute(String ruleId, InteractionDialogAPI dialog, List<Token> params, final Map<String, MemoryAPI> memoryMap) {
		if (dialog == null || dialog.getInteractionTarget() == null || dialog.getInteractionTarget().getMarket() == null) return false;
                if (params.size() == 3) {
                    if (dialog.getInteractionTarget().getMemoryWithoutUpdate().get("$bc_crews") != null) {
                        float crewloss = Misc.getRounded(dialog.getInteractionTarget().getMemoryWithoutUpdate().getInt("$bc_crews")*Misc.getRandom(Misc.genRandomSeed(), 1).nextFloat()*0.5f*Global.getSector().getPlayerFleet().getStats().getDynamic().getValue(Stats.NON_COMBAT_CREW_LOSS_MULT));
                        Global.getSector().getPlayerFleet().getCargo().addCommodity(Commodities.CREW, dialog.getInteractionTarget().getMemoryWithoutUpdate().getInt("$bc_crews")-crewloss);
                        AddRemoveCommodity.addCommodityGainText(Commodities.CREW, Math.min(dialog.getInteractionTarget().getMemoryWithoutUpdate().getInt("$bc_crews"), dialog.getInteractionTarget().getMemoryWithoutUpdate().getInt("$bc_crews")-(int)crewloss), dialog.getTextPanel());
                    }
                    if (dialog.getInteractionTarget().getMemoryWithoutUpdate().get("$bc_heavymachinery") != null) {
                        float machinerylost = Misc.getRounded(dialog.getInteractionTarget().getMemoryWithoutUpdate().getInt("$bc_heavymachinery")*Misc.getRandom(Misc.genRandomSeed(), 1).nextFloat()*0.5f);
                        Global.getSector().getPlayerFleet().getCargo().addCommodity(Commodities.HEAVY_MACHINERY, dialog.getInteractionTarget().getMemoryWithoutUpdate().getInt("$bc_heavymachinery")-machinerylost);
                        AddRemoveCommodity.addCommodityGainText(Commodities.HEAVY_MACHINERY, Math.min(dialog.getInteractionTarget().getMemoryWithoutUpdate().getInt("$bc_heavymachinery"), dialog.getInteractionTarget().getMemoryWithoutUpdate().getInt("$bc_heavymachinery")-(int)machinerylost), dialog.getTextPanel());
                    }
                    if (dialog.getInteractionTarget().getMemoryWithoutUpdate().get("$bc_marines") != null) {
                        float marineloss = Misc.getRounded(dialog.getInteractionTarget().getMemoryWithoutUpdate().getInt("$bc_marines")*Misc.getRandom(Misc.genRandomSeed(), 1).nextFloat()*0.5f*Global.getSector().getPlayerFleet().getStats().getDynamic().getValue(Stats.PLANETARY_OPERATIONS_CASUALTIES_MULT));
                        Global.getSector().getPlayerFleet().getCargo().addCommodity(Commodities.MARINES, dialog.getInteractionTarget().getMemoryWithoutUpdate().getInt("$bc_marines")-marineloss);
                        AddRemoveCommodity.addCommodityGainText(Commodities.MARINES, Math.min(dialog.getInteractionTarget().getMemoryWithoutUpdate().getInt("$bc_marines"), dialog.getInteractionTarget().getMemoryWithoutUpdate().getInt("$bc_marines")-(int)marineloss), dialog.getTextPanel());
                        PlayerFleetPersonnelTracker.getInstance().getMarineData().addXP(marineloss);
                    }
                    return true;
                }
                if (params.size() < 2) {dialog.getInteractionTarget().getMarket().removeCondition(params.get(0).getString(memoryMap));dialog.getInteractionTarget().getMarket().getMemoryWithoutUpdate().getKeys().remove("$mc:"+params.get(0).getString(memoryMap));return true;}
                ResourceCostPanelAPI cost = dialog.getTextPanel().addCostPanel(Global.getSettings().getString("bettercolonies", "Techmine1"), COST_HEIGHT,Global.getSector().getPlayerFaction().getColor(), Global.getSector().getPlayerFaction().getDarkUIColor());
		cost.setNumberOnlyMode(true);
		cost.setWithBorder(false);
		cost.setAlignment(Alignment.LMID);
		cost.addCost(Commodities.CREW, "" + params.get(0).getInt(memoryMap) + " (" + (int) Global.getSector().getPlayerFleet().getCargo().getCommodityQuantity(Commodities.CREW) + ")", params.get(0).getInt(memoryMap) <= (int) Global.getSector().getPlayerFleet().getCargo().getCommodityQuantity(Commodities.CREW) ? Global.getSector().getPlayerFaction().getColor() : Misc.getHighlightColor());
		cost.addCost(Commodities.HEAVY_MACHINERY, "" + params.get(1).getInt(memoryMap) + " (" + (int) Global.getSector().getPlayerFleet().getCargo().getCommodityQuantity(Commodities.HEAVY_MACHINERY) + ")", params.get(1).getInt(memoryMap) <= (int) Global.getSector().getPlayerFleet().getCargo().getCommodityQuantity(Commodities.HEAVY_MACHINERY) ? Global.getSector().getPlayerFaction().getColor() : Misc.getHighlightColor());
                cost.update();
                dialog.getInteractionTarget().getMemoryWithoutUpdate().set("$bc_crews", params.get(0).getInt(memoryMap));
                dialog.getInteractionTarget().getMemoryWithoutUpdate().set("$bc_heavymachinery", params.get(1).getInt(memoryMap));
                if (dialog.getInteractionTarget().getMarket().hasCondition(Conditions.DECIVILIZED) || dialog.getInteractionTarget().getMarket().hasCondition(Conditions.DECIVILIZED_SUBPOP)) {
                    ResourceCostPanelAPI cost2 = dialog.getTextPanel().addCostPanel(Global.getSettings().getString("bettercolonies", "Techmine2"), COST_HEIGHT,Global.getSector().getPlayerFaction().getColor(), Global.getSector().getPlayerFaction().getDarkUIColor());
                    cost2.setNumberOnlyMode(true);
                    cost2.setWithBorder(false);
                    cost2.setAlignment(Alignment.LMID);
                    cost2.addCost(Commodities.MARINES, "" +  Misc.getRoundedValue((float) (params.get(0).getInt(memoryMap)*0.4)) + " (" + (int) Global.getSector().getPlayerFleet().getCargo().getCommodityQuantity(Commodities.MARINES) + ")", (int) params.get(0).getInt(memoryMap) * 0.4 <= (int) Global.getSector().getPlayerFleet().getCargo().getCommodityQuantity(Commodities.MARINES) ? Global.getSector().getPlayerFaction().getColor() : Misc.getNegativeHighlightColor());
                    cost2.update();
                    dialog.getInteractionTarget().getMemoryWithoutUpdate().set("$bc_marines", Misc.getRoundedValue((float) (params.get(0).getInt(memoryMap)*0.4)));
                }
                if (Misc.getClaimingFaction(dialog.getInteractionTarget()) != null) {
                    dialog.getInteractionTarget().getMemoryWithoutUpdate().set("$bc_factioncolor", Misc.getClaimingFaction(dialog.getInteractionTarget()).getColor(), 0f);
                    dialog.getInteractionTarget().getMemoryWithoutUpdate().set("$bc_factionstring", Misc.getClaimingFaction(dialog.getInteractionTarget()).getDisplayName(), 0f);
                    dialog.getInteractionTarget().getMemoryWithoutUpdate().set("$bc_factionid", Misc.getClaimingFaction(dialog.getInteractionTarget()).getId(), 0f);
                }
		return true;
	}
}

